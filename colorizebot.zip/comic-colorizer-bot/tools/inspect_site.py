"""
inspect_site.py
================
Bantuan untuk menemukan CSS selector yang BENAR ketika bot gagal
("SelectorNotFoundError") karena tampilan website (palette.fm / deepai /
dll) berubah.

Cara pakai (dari folder project):

    # Lihat elemen yang ada di halaman awal
    python3 tools/inspect_site.py "https://palette.fm/color/filters"

    # Upload gambar dulu, supaya elemen yang baru muncul SETELAH upload
    # (misal galeri filter) ikut terdeteksi
    python3 tools/inspect_site.py "https://palette.fm/color/filters" \\
        --upload /path/ke/contoh.png

    # Setelah upload, klik salah satu elemen (misal salah satu filter)
    # lalu inspect lagi untuk melihat elemen hasil yang muncul
    python3 tools/inspect_site.py "https://palette.fm/color/filters" \\
        --upload /path/ke/contoh.png --click ".filter-card"

Output:
    - Screenshot full halaman -> data/debug_screenshots/inspect_<timestamp>.png
    - Daftar <input type="file">, elemen dengan atribut data-*, tombol/link,
      dan <img> beserta CSS selector yang bisa langsung dicoba di
      selectors.yaml.
"""

from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path

from playwright.async_api import async_playwright

BASE = Path(__file__).resolve().parent.parent
SCREENSHOT_DIR = BASE / "data" / "debug_screenshots"

COLLECT_JS = r"""
() => {
  function shortText(el) {
    const t = (el.innerText || el.textContent || '').trim().replace(/\s+/g, ' ');
    return t.slice(0, 40);
  }
  function cssSelector(el) {
    if (el.id) return '#' + el.id;
    if (el.className && typeof el.className === 'string') {
      const cls = el.className.trim().split(/\s+/).filter(Boolean);
      if (cls.length) return el.tagName.toLowerCase() + '.' + cls.join('.');
    }
    return el.tagName.toLowerCase();
  }
  function dataAttrs(el) {
    return Object.fromEntries(
      [...el.attributes].filter(a => a.name.startsWith('data-')).map(a => [a.name, a.value])
    );
  }

  const fileInputs = [...document.querySelectorAll("input[type='file']")].map(el => ({
    selector: cssSelector(el),
    id: el.id, class: el.className, name: el.name, accept: el.accept,
  }));

  const clickables = [...document.querySelectorAll(
    "button, a, [role='button'], input[type='submit'], [onclick]"
  )]
    .filter(el => el.offsetParent !== null || el.tagName === 'BUTTON')
    .slice(0, 60)
    .map(el => ({
      tag: el.tagName.toLowerCase(),
      selector: cssSelector(el),
      text: shortText(el),
      id: el.id, class: el.className,
      dataAttrs: dataAttrs(el),
    }));

  const images = [...document.querySelectorAll('img')]
    .slice(0, 40)
    .map(el => ({
      selector: cssSelector(el),
      id: el.id, class: el.className,
      src: (el.getAttribute('src') || '').slice(0, 90),
      alt: el.alt,
      visible: el.offsetParent !== null,
    }));

  // Heuristik: elemen dgn data-name/data-filter/data-id sering dipakai
  // utk galeri pilihan (filter, style, dll).
  const dataNamed = [...document.querySelectorAll(
    '[data-name], [data-filter], [data-filter-name], [data-id], [data-value]'
  )]
    .slice(0, 60)
    .map(el => ({
      tag: el.tagName.toLowerCase(),
      selector: cssSelector(el),
      text: shortText(el),
      dataAttrs: dataAttrs(el),
    }));

  return { fileInputs, clickables, images, dataNamed, title: document.title, url: location.href };
}
"""


async def main() -> None:
    if len(sys.argv) < 2:
        print("Pakai: python3 tools/inspect_site.py <URL> [--upload <path_gambar>] [--click '<selector>']")
        sys.exit(1)

    url = sys.argv[1]
    upload_path: str | None = None
    click_selector: str | None = None

    args = sys.argv[2:]
    for i, a in enumerate(args):
        if a == "--upload" and i + 1 < len(args):
            upload_path = args[i + 1]
        if a == "--click" and i + 1 < len(args):
            click_selector = args[i + 1]

    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True, args=["--no-sandbox"])
        page = await browser.new_page(viewport={"width": 1366, "height": 900})

        print(f"-> Membuka {url} ...")
        await page.goto(url, wait_until="domcontentloaded", timeout=60000)
        await page.wait_for_timeout(2000)

        if upload_path:
            print(f"-> Upload {upload_path} ke input[type='file'] pertama...")
            try:
                el = await page.wait_for_selector("input[type='file']", state="attached", timeout=10000)
                await el.set_input_files(upload_path)
                await page.wait_for_timeout(3000)
            except Exception as e:
                print(f"   (gagal upload otomatis: {e})")

        if click_selector:
            print(f"-> Klik elemen: {click_selector}")
            try:
                el = await page.wait_for_selector(click_selector, timeout=10000)
                await el.click()
                await page.wait_for_timeout(2000)
            except Exception as e:
                print(f"   (gagal klik: {e})")

        ts = int(time.time())
        shot = SCREENSHOT_DIR / f"inspect_{ts}.png"
        await page.screenshot(path=str(shot), full_page=True)

        data = await page.evaluate(COLLECT_JS)
        await browser.close()

    print(f"\nScreenshot disimpan: {shot}")
    print(f"Title: {data['title']}")
    print(f"URL  : {data['url']}")

    print("\n--- <input type='file'> ---")
    for f in data["fileInputs"]:
        print(f"  selector={f['selector']!r}  id={f['id']!r} class={f['class']!r} accept={f['accept']!r}")
    if not data["fileInputs"]:
        print("  (tidak ada — mungkin tersembunyi di belakang tombol upload custom, "
              "cek bagian 'Tombol/Link' di bawah lalu pakai --click)")

    print("\n--- Elemen dengan atribut data-* (kandidat galeri filter/style) ---")
    for d in data["dataNamed"]:
        extra = f" data={d['dataAttrs']}" if d["dataAttrs"] else ""
        print(f"  <{d['tag']}> selector={d['selector']!r} text={d['text']!r}{extra}")
    if not data["dataNamed"]:
        print("  (tidak ada elemen dgn data-name / data-filter / data-id / data-value)")

    print("\n--- Tombol / Link yang terlihat (maks 60) ---")
    for c in data["clickables"]:
        extra = f" data={c['dataAttrs']}" if c["dataAttrs"] else ""
        print(f"  <{c['tag']}> selector={c['selector']!r} text={c['text']!r}{extra}")

    print("\n--- <img> (maks 40) ---")
    for im in data["images"]:
        print(f"  selector={im['selector']!r} visible={im['visible']} src={im['src']!r} alt={im['alt']!r}")

    print(
        "\nSelesai. Salin selector yang relevan ke selectors.yaml.\n"
        "Tips:\n"
        "  - 'selector' di atas adalah TEBAKAN AWAL (#id atau tag.class).\n"
        "    Kalau class-nya panjang/acak (umum di website modern, misal "
        "'btn_a8x91'), coba selector berbasis TEKS, contoh:\n"
        "      button:has-text('Run Model')\n"
        "      text=Download\n"
        "  - Untuk galeri filter, cek bagian 'data-*' dulu — biasanya nama "
        "filter ada di salah satu atribut data-xxx atau di teks elemen."
    )


if __name__ == "__main__":
    asyncio.run(main())
