#!/usr/bin/env bash
# =============================================================================
# install.sh — Instalasi otomatis Comic Colorizer Telegram Bot
#
# Jalankan dari DALAM folder project ini, di VPS (Ubuntu/Debian):
#   bash install.sh
#
# Script ini akan:
#   1. Install paket sistem (python3, venv, pip)
#   2. Buat virtual environment Python (./venv)
#   3. Install dependency Python (requirements.txt)
#   4. Install Playwright + browser Chromium + dependency sistemnya
#   5. Siapkan file .env (dari .env.example, jika belum ada)
#   6. (opsional) Setup systemd service supaya bot auto-start & auto-restart
# =============================================================================
set -euo pipefail

if [ "$(id -u)" -eq 0 ]; then
  SUDO=""
else
  SUDO="sudo"
fi

echo "================================================================"
echo " Comic Colorizer Telegram Bot - Installer"
echo "================================================================"

# -----------------------------------------------------------------------
echo ""
echo "[1/6] Update apt & install paket sistem (python3, venv, pip)..."
$SUDO apt-get update -y
$SUDO apt-get install -y python3 python3-venv python3-pip

# -----------------------------------------------------------------------
echo ""
echo "[2/6] Membuat virtual environment Python di ./venv ..."
if [ ! -d venv ]; then
  python3 -m venv venv
fi
# shellcheck disable=SC1091
source venv/bin/activate

# -----------------------------------------------------------------------
echo ""
echo "[3/6] Install dependency Python dari requirements.txt ..."
pip install --upgrade pip
pip install -r requirements.txt

# -----------------------------------------------------------------------
echo ""
echo "[4/6] Install Playwright + Chromium + dependency sistemnya"
echo "      (ini bisa makan waktu beberapa menit, mengunduh browser)..."
python -m playwright install --with-deps chromium

# -----------------------------------------------------------------------
echo ""
echo "[5/6] Menyiapkan file .env ..."
if [ ! -f .env ]; then
  cp .env.example .env
  echo "      -> .env dibuat dari .env.example."
  echo "      -> WAJIB diisi sebelum bot dijalankan (lihat langkah terakhir)."
else
  echo "      -> .env sudah ada, tidak ditimpa."
fi

mkdir -p data/jobs data/output data/debug_screenshots

# -----------------------------------------------------------------------
echo ""
echo "[6/6] Setup systemd service (auto-start & auto-restart saat crash/reboot)?"
read -r -p "      Setup sekarang? [Y/n]: " setup_systemd
setup_systemd=${setup_systemd:-Y}

if [[ "$setup_systemd" =~ ^[Yy]$ ]]; then
  CURRENT_USER=$(whoami)
  PROJECT_DIR=$(pwd)

  sed \
    -e "s|/home/botuser/comic-colorizer-bot|${PROJECT_DIR}|g" \
    -e "s|User=botuser|User=${CURRENT_USER}|g" \
    -e "s|Group=botuser|Group=${CURRENT_USER}|g" \
    comic-colorizer-bot.service | $SUDO tee /etc/systemd/system/comic-colorizer-bot.service > /dev/null

  $SUDO systemctl daemon-reload
  echo "      -> Service 'comic-colorizer-bot' terdaftar di systemd."
  echo "      -> BELUM di-enable/start (isi .env dulu!)."
  USE_SYSTEMD=1
else
  echo "      -> Dilewati."
  USE_SYSTEMD=0
fi

# -----------------------------------------------------------------------
echo ""
echo "================================================================"
echo " INSTALASI SELESAI"
echo "================================================================"
echo ""
echo "LANGKAH TERAKHIR (WAJIB):"
echo "  1. Edit .env dan isi TELEGRAM_BOT_TOKEN & ALLOWED_USER_IDS:"
echo "       nano .env"
echo ""
if [ "$USE_SYSTEMD" -eq 1 ]; then
echo "  2. Jalankan bot sebagai service:"
echo "       sudo systemctl enable --now comic-colorizer-bot"
echo ""
echo "  3. Lihat log realtime:"
echo "       sudo journalctl -u comic-colorizer-bot -f"
echo ""
echo "  4. Perintah lain:"
echo "       sudo systemctl restart comic-colorizer-bot   # restart"
echo "       sudo systemctl stop comic-colorizer-bot      # stop"
else
echo "  2. Jalankan bot secara manual:"
echo "       source venv/bin/activate"
echo "       python3 bot.py"
echo ""
echo "     (Untuk tetap jalan setelah SSH ditutup, gunakan 'tmux' atau"
echo "      'screen', atau jalankan ulang install.sh dan pilih 'Y' di"
echo "      langkah systemd.)"
fi
echo ""
echo "================================================================"
