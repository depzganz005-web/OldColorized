"""
test_preview.py
================
Unit test untuk preview.RollingPreview — TANPA Telegram asli, pakai
FakeBot yang mencatat semua pemanggilan method.

Skenario:
1. update() pertama -> send_photo (pesan baru), message_id disimpan.
2. update() kedua   -> edit_message_media dgn message_id YANG SAMA,
   media/caption baru (mengganti foto halaman 1 -> 2 di pesan yg sama).
   send_photo TIDAK dipanggil lagi.
3. Jika edit_message_media RAISE (mis. pesan terlalu lama / tidak ada
   foto) -> fallback: delete_message(message_id lama) lalu send_photo
   baru, message_id diperbarui ke pesan baru.

Jalankan: python3 test_preview.py
"""

from __future__ import annotations

import asyncio
import sys

sys.path.insert(0, "/home/claude/stub_pkgs")

from telegram import InputMediaPhoto  # noqa: E402

from preview import RollingPreview  # noqa: E402


class FakeMessage:
    _next_id = 100

    def __init__(self):
        FakeMessage._next_id += 1
        self.message_id = FakeMessage._next_id


class FakeBot:
    def __init__(self, fail_edit: bool = False):
        self.fail_edit = fail_edit
        self.calls: list[tuple] = []

    async def send_photo(self, chat_id, photo, caption):
        self.calls.append(("send_photo", chat_id, photo, caption))
        return FakeMessage()

    async def edit_message_media(self, chat_id, message_id, media):
        self.calls.append(("edit_message_media", chat_id, message_id, media))
        if self.fail_edit:
            raise RuntimeError("simulated: message too old to edit")

    async def delete_message(self, chat_id, message_id):
        self.calls.append(("delete_message", chat_id, message_id))


async def test_basic_edit_flow() -> None:
    print("=== RollingPreview: edit pesan yang sama utk halaman berikutnya ===")
    bot = FakeBot(fail_edit=False)
    rp = RollingPreview(bot, chat_id=999)

    await rp.update(b"PAGE1-BYTES", "Halaman 1/3 selesai")
    await rp.update(b"PAGE2-BYTES", "Halaman 2/3 selesai")
    await rp.update(b"PAGE3-BYTES", "Halaman 3/3 selesai")

    kinds = [c[0] for c in bot.calls]
    print("urutan panggilan:", kinds)

    # HANYA SATU send_photo (pesan awal); sisanya edit_message_media.
    assert kinds.count("send_photo") == 1, kinds
    assert kinds.count("edit_message_media") == 2, kinds
    assert kinds.count("delete_message") == 0, kinds

    first_msg_id = bot.calls[0][1] if False else None
    # ambil message_id dari hasil send_photo pertama via rp.message_id
    edit_calls = [c for c in bot.calls if c[0] == "edit_message_media"]
    for _, chat_id, message_id, media in edit_calls:
        assert chat_id == 999
        assert message_id == rp.message_id, "edit harus pakai message_id pesan PERTAMA"
        assert isinstance(media, InputMediaPhoto)

    # Pastikan media/caption tiap edit sesuai urutan halaman (loncat 1->2->3
    # di PESAN YANG SAMA, sesuai permintaan: "langsung ganti gambar dari
    # halaman 1 ke 2 menggunakan edit").
    assert edit_calls[0][3].media == b"PAGE2-BYTES"
    assert edit_calls[0][3].caption == "Halaman 2/3 selesai"
    assert edit_calls[1][3].media == b"PAGE3-BYTES"
    assert edit_calls[1][3].caption == "Halaman 3/3 selesai"

    print("  send_photo: 1x (pesan awal, halaman 1)")
    print("  edit_message_media: 2x (halaman 1->2, lalu 2->3), message_id tetap sama")
    print("OK\n")


async def test_fallback_delete_and_resend() -> None:
    print("=== RollingPreview: fallback delete+resend jika edit gagal ===")
    bot = FakeBot(fail_edit=True)
    rp = RollingPreview(bot, chat_id=999)

    await rp.update(b"PAGE1-BYTES", "Halaman 1/2 selesai")
    first_id = rp.message_id

    await rp.update(b"PAGE2-BYTES", "Halaman 2/2 selesai")
    second_id = rp.message_id

    kinds = [c[0] for c in bot.calls]
    print("urutan panggilan:", kinds)

    assert kinds == ["send_photo", "edit_message_media", "delete_message", "send_photo"], kinds

    # delete_message harus menghapus pesan PERTAMA (halaman 1)
    delete_call = bot.calls[2]
    assert delete_call[2] == first_id

    # pesan KEDUA (hasil send_photo kedua) jadi message_id baru, BEDA dari pertama
    assert second_id != first_id

    # isi pesan kedua = halaman 2 (foto lama halaman 1 sudah DIHAPUS,
    # bukan menumpuk di chat)
    second_send = bot.calls[3]
    assert second_send[0] == "send_photo"
    assert second_send[2] == b"PAGE2-BYTES"
    assert second_send[3] == "Halaman 2/2 selesai"

    print("  halaman1: send_photo -> edit_message_media (GAGAL, simulasi)")
    print("  -> delete_message(pesan halaman1) -> send_photo(halaman2)")
    print("  pesan halaman 1 terhapus, hanya pesan halaman 2 yang tersisa: OK\n")


async def main() -> None:
    await test_basic_edit_flow()
    await test_fallback_delete_and_resend()
    print("SEMUA TEST RollingPreview LULUS ✅")


if __name__ == "__main__":
    asyncio.run(main())
