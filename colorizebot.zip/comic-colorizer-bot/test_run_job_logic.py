"""
test_run_job_logic.py
======================
Mereplikasi logika INTI dari run_job() di bot.py (tanpa Telegram asli):
- loop per halaman dgn progress "Memproses halaman X/N..."
- retry 2x lalu fallback ke gambar asli jika gagal
- PREVIEW: pakai preview.RollingPreview (SATU pesan, di-edit tiap
  halaman selesai — bukan kirim pesan baru tiap kali)
- gabung hasil jadi PDF (dgn images_to_pdf_parts)

Tujuannya memverifikasi flow yg dipakai bot.py benar2 jalan end-to-end
terhadap automasi browser asli (mock site) + rolling-preview, termasuk
skenario GAGAL (filter tidak ditemukan -> fallback ke gambar asli, tapi
preview TETAP terupdate dgn caption "gagal").

PENTING: PALETTE_CFG diambil LANGSUNG dari selectors.yaml (hanya `url`
& wait_*_ms dipercepat) — sama seperti test_pipeline.py.
"""

from __future__ import annotations

import asyncio
import shutil
import sys
from pathlib import Path

import yaml
from PIL import Image, ImageChops

# Stub python-telegram-bot (tidak terpasang di sandbox) — harus didahulukan
# SEBELUM import preview, karena preview.py mengimpor `telegram.InputMediaPhoto`.
sys.path.insert(0, "/home/claude/stub_pkgs")

import config
import image_utils
import pdf_utils
from colorizers.browser_manager import browser_manager
from colorizers.errors import ColorizeError, NotSupportedError
from colorizers.palette_fm import PaletteFMColorizer
from preview import RollingPreview

BASE = Path(__file__).resolve().parent
MOCK_URL = "http://127.0.0.1:8123"
JOB_DIR = BASE / "test" / "job_sim"
PAGES_DIR = JOB_DIR / "pages"
COLORIZED_DIR = JOB_DIR / "colorized"


def load_palette_cfg() -> dict:
    with open(config.SELECTORS_FILE, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    cfg = dict(data["palette_fm"])
    cfg["url"] = f"{MOCK_URL}/palette_fm.html"
    cfg["wait_after_upload_ms"] = 400
    cfg["wait_after_filter_click_ms"] = 300
    return cfg


def make_pages(n: int) -> list[Path]:
    PAGES_DIR.mkdir(parents=True, exist_ok=True)
    paths = []
    for i in range(n):
        img = Image.new("RGB", (300, 400), (30 * i, 100, 200 - 20 * i))
        p = PAGES_DIR / f"page_{i + 1:04d}.png"
        img.save(p)
        paths.append(p)
    return paths


class FakeMessage:
    _next_id = 0

    def __init__(self):
        FakeMessage._next_id += 1
        self.message_id = FakeMessage._next_id


class FakeBot:
    """Mencatat send_photo / edit_message_media / delete_message untuk
    diverifikasi (lihat juga test_preview.py)."""

    def __init__(self):
        self.calls: list[tuple] = []

    async def send_photo(self, chat_id, photo, caption):
        self.calls.append(("send_photo", chat_id, photo, caption))
        return FakeMessage()

    async def edit_message_media(self, chat_id, message_id, media):
        self.calls.append(("edit_message_media", chat_id, message_id, media))

    async def delete_message(self, chat_id, message_id):
        self.calls.append(("delete_message", chat_id, message_id))


async def run_simulated_job(option: str, n_pages: int, palette_cfg: dict) -> dict:
    """Replika ringkas dari process_one-loop + rolling preview di bot.py."""
    COLORIZED_DIR.mkdir(parents=True, exist_ok=True)
    pages = make_pages(n_pages)
    colorizer = PaletteFMColorizer(palette_cfg)

    completed = 0
    failed_pages: list[str] = []
    not_supported: NotSupportedError | None = None
    progress_log: list[str] = []

    fake_bot = FakeBot()
    rolling_preview = RollingPreview(fake_bot, chat_id=999)
    preview_lock = asyncio.Lock()

    async def update_progress(current_page):
        line = (
            f"Memproses {current_page}/{n_pages}"
            if current_page and current_page <= n_pages
            else "Selesai semua"
        )
        line += f" | done={completed} | failed={len(failed_pages)}"
        progress_log.append(line)

    async def send_preview(page_num, out_path, ok):
        data = await asyncio.to_thread(image_utils.make_preview_bytes, out_path, 1280)
        if ok:
            caption = f"✅ Halaman {page_num}/{n_pages} selesai di-colorize"
        else:
            caption = f"⚠️ Halaman {page_num}/{n_pages} gagal di-colorize — memakai gambar asli"
        async with preview_lock:
            await rolling_preview.update(data, caption)

    async def process_one(page_num, src_path):
        nonlocal completed, not_supported
        out_path = COLORIZED_DIR / src_path.name
        await update_progress(page_num)

        last_err = None
        for attempt in range(2):
            try:
                await colorizer.colorize(src_path, out_path, option)
                last_err = None
                break
            except NotSupportedError as e:
                not_supported = e
                return
            except ColorizeError as e:
                last_err = e
                await asyncio.sleep(0.2)  # dipercepat utk test (asli: 2s)

        ok = last_err is None
        if not ok:
            shutil.copy(src_path, out_path)
            failed_pages.append(src_path.name)

        completed += 1
        await send_preview(page_num, out_path, ok)
        await update_progress(page_num + 1)

    for i, p in enumerate(pages):
        await process_one(i + 1, p)

    return {
        "pages": pages,
        "completed": completed,
        "failed_pages": failed_pages,
        "not_supported": not_supported,
        "progress_log": progress_log,
        "fake_bot": fake_bot,
        "rolling_preview": rolling_preview,
    }


def images_differ(path_a: Path, path_b: Path) -> bool:
    a = Image.open(path_a).convert("RGB")
    b = Image.open(path_b).convert("RGB")
    if a.size != b.size:
        return True
    return ImageChops.difference(a, b).getbbox() is not None


async def main() -> None:
    config.BROWSER_TIMEOUT_MS = 8000  # mock site cepat, hindari timeout 180s default
    shutil.rmtree(JOB_DIR, ignore_errors=True)
    palette_cfg = load_palette_cfg()

    await browser_manager.start()
    try:
        # ---------------- Skenario 1: filter VALID, semua sukses ----------------
        print("=== Skenario 1: filter valid (Vibrant), 3 halaman ===")
        result = await run_simulated_job(option="Vibrant", n_pages=3, palette_cfg=palette_cfg)
        for line in result["progress_log"]:
            print(" ", line)
        assert result["completed"] == 3
        assert result["failed_pages"] == []
        assert result["not_supported"] is None

        # --- Verifikasi ROLLING PREVIEW: 1 pesan dibuat, 2x di-EDIT ---
        calls = result["fake_bot"].calls
        kinds = [c[0] for c in calls]
        print("  rolling preview calls:", kinds)
        assert kinds == ["send_photo", "edit_message_media", "edit_message_media"], kinds

        # message_id pesan preview HARUS SAMA dari awal sampai akhir
        # (gambar halaman 1 "diganti" jadi halaman 2 lalu 3 di pesan yg sama).
        preview_msg_id = result["rolling_preview"].message_id
        for call in calls[1:]:
            assert call[2] == preview_msg_id, "edit harus selalu ke message_id yg sama"

        # caption tiap edit harus "✅ Halaman 2/3 ..." lalu "✅ Halaman 3/3 ..."
        edit_captions = [c[3].caption for c in calls if c[0] == "edit_message_media"]
        print("  edit captions:", edit_captions)
        assert edit_captions[0] == "✅ Halaman 2/3 selesai di-colorize"
        assert edit_captions[1] == "✅ Halaman 3/3 selesai di-colorize"

        # Setiap edit membawa GAMBAR BERBEDA (bukan gambar halaman 1 yg sama
        # dikirim ulang) -> validasi bytes tiap update beda satu sama lain.
        edit_media_bytes = [c[3].media for c in calls if c[0] == "edit_message_media"]
        first_photo_bytes = calls[0][2]
        assert first_photo_bytes != edit_media_bytes[0] != edit_media_bytes[1]
        print("  setiap update preview membawa gambar halaman yang berbeda: OK")

        # hasil colorize harus beda dari gambar asli (filter Vibrant diterapkan
        # & diambil via klik tombol Download)
        for src in result["pages"]:
            out = COLORIZED_DIR / src.name
            assert images_differ(src, out), f"{src.name}: hasil harus beda dari asli"

        # gabung jadi PDF (kasus normal, 1 file)
        colorized = sorted(COLORIZED_DIR.glob("page_*.png"))
        parts = pdf_utils.images_to_pdf_parts(
            colorized, JOB_DIR / "out", max_bytes=50_000_000, base_name="hasil"
        )
        print("  PDF parts:", [(p.name, a, b) for p, a, b in parts])
        assert len(parts) == 1
        assert pdf_utils.get_page_count(parts[0][0]) == 3
        print("Skenario 1: OK\n")

        # ---------------- Skenario 2: filter TIDAK ADA -> fallback ----------------
        print("=== Skenario 2: filter tidak ditemukan -> fallback ke gambar asli ===")
        shutil.rmtree(COLORIZED_DIR, ignore_errors=True)
        result2 = await run_simulated_job(
            option="FilterTidakAda", n_pages=2, palette_cfg=palette_cfg
        )
        for line in result2["progress_log"]:
            print(" ", line)
        assert result2["completed"] == 2
        assert len(result2["failed_pages"]) == 2, result2["failed_pages"]
        assert result2["not_supported"] is None

        # fallback image harus identik dgn source (copy asli)
        for src in result2["pages"]:
            out = COLORIZED_DIR / src.name
            assert out.read_bytes() == src.read_bytes(), "fallback harus copy file asli"

        # Preview TETAP terupdate (1 pesan, di-edit), tapi caption-nya "gagal"
        calls2 = result2["fake_bot"].calls
        kinds2 = [c[0] for c in calls2]
        assert kinds2 == ["send_photo", "edit_message_media"], kinds2
        edit_caption2 = calls2[1][3].caption
        print("  caption edit (halaman gagal):", edit_caption2)
        assert "gagal" in edit_caption2 and "gambar asli" in edit_caption2
        print("Skenario 2: OK (fallback ke gambar asli + preview tetap terupdate)\n")

        # ---------------- Skenario 3: split PDF jadi multi-part ----------------
        print("=== Skenario 3: paksa split PDF (max_bytes kecil) ===")
        shutil.rmtree(COLORIZED_DIR, ignore_errors=True)
        result3 = await run_simulated_job(
            option="Cool Blue", n_pages=4, palette_cfg=palette_cfg
        )
        assert result3["completed"] == 4
        colorized3 = sorted(COLORIZED_DIR.glob("page_*.png"))
        # 4 halaman: 1 send_photo + 3 edit, semua ke message_id yg sama
        kinds3 = [c[0] for c in result3["fake_bot"].calls]
        assert kinds3 == [
            "send_photo", "edit_message_media", "edit_message_media", "edit_message_media"
        ], kinds3

        # max_bytes sangat kecil -> pasti dipecah per halaman
        parts3 = pdf_utils.images_to_pdf_parts(
            colorized3, JOB_DIR / "out3", max_bytes=5_000, base_name="hasil"
        )
        print("  PDF parts:", [(p.name, a, b, p.stat().st_size) for p, a, b in parts3])
        assert len(parts3) == 4
        total_pages_in_parts = sum(pdf_utils.get_page_count(p) for p, _, _ in parts3)
        assert total_pages_in_parts == 4
        for p, _, _ in parts3:
            assert p.stat().st_size <= 5_000
        print("Skenario 3: OK (split bekerja, total halaman tetap 4)\n")

    finally:
        await browser_manager.stop()

    print("SEMUA SKENARIO run_job LOGIC LULUS ✅")


if __name__ == "__main__":
    asyncio.run(main())
