"""
test_run_job_logic.py
======================
Mereplikasi logika INTI dari run_job() di bot.py (tanpa Telegram):
- loop per halaman dgn progress "Memproses halaman X/N..."
- retry 2x lalu fallback ke gambar asli jika gagal
- kirim "preview" (cek bytes JPEG valid) tiap halaman selesai
- gabung hasil jadi PDF (dgn images_to_pdf_parts)

Tujuannya memverifikasi flow yg dipakai bot.py benar2 jalan end-to-end
terhadap automasi browser asli (mock site), termasuk skenario GAGAL
(filter tidak ditemukan -> fallback ke gambar asli).
"""

from __future__ import annotations

import asyncio
import shutil
from pathlib import Path

from PIL import Image

import config
import image_utils
import pdf_utils
from colorizers.browser_manager import browser_manager
from colorizers.errors import ColorizeError, NotSupportedError
from colorizers.palette_fm import PaletteFMColorizer

BASE = Path(__file__).resolve().parent
MOCK_URL = "http://127.0.0.1:8123"
JOB_DIR = BASE / "test" / "job_sim"
PAGES_DIR = JOB_DIR / "pages"
COLORIZED_DIR = JOB_DIR / "colorized"

PALETTE_CFG = {
    "url": f"{MOCK_URL}/palette_fm.html",
    "file_input_selector": "input[type='file']",
    "upload_trigger_selector": "",
    "upload_ready_selector": "",
    "wait_after_upload_ms": 400,
    "filter_item_selector": "[data-filter-name], .filter-card, .filter-thumb",
    "filter_name_source": "text",
    "wait_after_filter_click_ms": 800,
    "result_image_selector": "img.result, .preview-after img, .after img",
    "cookies_file": "",
}


def make_pages(n: int) -> list[Path]:
    PAGES_DIR.mkdir(parents=True, exist_ok=True)
    paths = []
    for i in range(n):
        img = Image.new("RGB", (300, 400), (30 * i, 100, 200 - 20 * i))
        p = PAGES_DIR / f"page_{i + 1:04d}.png"
        img.save(p)
        paths.append(p)
    return paths


async def run_simulated_job(option: str, n_pages: int = 3) -> dict:
    """Replika ringkas dari process_one-loop di bot.py."""
    COLORIZED_DIR.mkdir(parents=True, exist_ok=True)
    pages = make_pages(n_pages)
    colorizer = PaletteFMColorizer(PALETTE_CFG)

    completed = 0
    failed_pages: list[str] = []
    not_supported: NotSupportedError | None = None
    progress_log: list[str] = []
    previews: dict[int, bytes] = {}

    async def update_progress(current_page):
        line = f"Memproses {current_page}/{n_pages}" if current_page and current_page <= n_pages else "Selesai semua"
        line += f" | done={completed} | failed={len(failed_pages)}"
        progress_log.append(line)

    async def send_preview(page_num, out_path, ok):
        data = await asyncio.to_thread(image_utils.make_preview_bytes, out_path, 1280)
        previews[page_num] = data

    async def process_one(page_num, src_path):
        nonlocal completed, not_supported
        out_path = COLORIZED_DIR / src_path.name
        await update_progress(page_num)

        last_err = None
        for attempt in range(2):
            try:
                await colorizer.colorize(src_path, out_path, option)
                last_err = None
                break
            except NotSupportedError as e:
                not_supported = e
                return
            except ColorizeError as e:
                last_err = e
                await asyncio.sleep(0.2)  # dipercepat utk test (asli: 2s)

        ok = last_err is None
        if not ok:
            shutil.copy(src_path, out_path)
            failed_pages.append(src_path.name)

        completed += 1
        await send_preview(page_num, out_path, ok)
        await update_progress(page_num + 1)

    for i, p in enumerate(pages):
        await process_one(i + 1, p)

    return {
        "pages": pages,
        "completed": completed,
        "failed_pages": failed_pages,
        "not_supported": not_supported,
        "progress_log": progress_log,
        "previews": previews,
    }


async def main() -> None:
    config.BROWSER_TIMEOUT_MS = 8000  # mock site cepat, hindari timeout 180s default
    shutil.rmtree(JOB_DIR, ignore_errors=True)
    await browser_manager.start()
    try:
        # ---------------- Skenario 1: filter VALID, semua sukses ----------------
        print("=== Skenario 1: filter valid (Vibrant), 3 halaman ===")
        result = await run_simulated_job(option="Vibrant", n_pages=3)
        for line in result["progress_log"]:
            print(" ", line)
        assert result["completed"] == 3
        assert result["failed_pages"] == []
        assert result["not_supported"] is None
        assert set(result["previews"].keys()) == {1, 2, 3}
        for pg, data in result["previews"].items():
            from io import BytesIO
            im = Image.open(BytesIO(data))
            assert im.format == "JPEG"
            print(f"  preview hal {pg}: {im.size}, {len(data)} bytes")

        # gabung jadi PDF (kasus normal, 1 file)
        colorized = sorted(COLORIZED_DIR.glob("page_*.png"))
        parts = pdf_utils.images_to_pdf_parts(colorized, JOB_DIR / "out", max_bytes=50_000_000, base_name="hasil")
        print("  PDF parts:", [(p.name, a, b) for p, a, b in parts])
        assert len(parts) == 1
        assert pdf_utils.get_page_count(parts[0][0]) == 3
        print("Skenario 1: OK\n")

        # ---------------- Skenario 2: filter TIDAK ADA -> fallback ----------------
        print("=== Skenario 2: filter tidak ditemukan -> fallback ke gambar asli ===")
        shutil.rmtree(COLORIZED_DIR, ignore_errors=True)
        result2 = await run_simulated_job(option="FilterTidakAda", n_pages=2)
        for line in result2["progress_log"]:
            print(" ", line)
        assert result2["completed"] == 2
        assert len(result2["failed_pages"]) == 2, result2["failed_pages"]
        assert result2["not_supported"] is None
        # fallback image harus identik dgn source (copy asli)
        for src in result2["pages"]:
            out = COLORIZED_DIR / src.name
            assert out.read_bytes() == src.read_bytes(), "fallback harus copy file asli"
        print("Skenario 2: OK (fallback ke gambar asli terverifikasi)\n")

        # ---------------- Skenario 3: split PDF jadi multi-part ----------------
        print("=== Skenario 3: paksa split PDF (max_bytes kecil) ===")
        shutil.rmtree(COLORIZED_DIR, ignore_errors=True)
        result3 = await run_simulated_job(option="Cool Blue", n_pages=4)
        assert result3["completed"] == 4
        colorized3 = sorted(COLORIZED_DIR.glob("page_*.png"))
        # max_bytes sangat kecil -> pasti dipecah per halaman
        parts3 = pdf_utils.images_to_pdf_parts(colorized3, JOB_DIR / "out3", max_bytes=5_000, base_name="hasil")
        print("  PDF parts:", [(p.name, a, b, p.stat().st_size) for p, a, b in parts3])
        assert len(parts3) == 4
        total_pages_in_parts = sum(pdf_utils.get_page_count(p) for p, _, _ in parts3)
        assert total_pages_in_parts == 4
        for p, _, _ in parts3:
            assert p.stat().st_size <= 5_000
        print("Skenario 3: OK (split bekerja, total halaman tetap 4)\n")

    finally:
        await browser_manager.stop()

    print("SEMUA SKENARIO run_job LOGIC LULUS ✅")


if __name__ == "__main__":
    asyncio.run(main())
