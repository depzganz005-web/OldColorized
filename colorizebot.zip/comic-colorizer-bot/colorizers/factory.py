"""
factory.py
==========
Memuat selectors.yaml dan menyediakan instance colorizer sesuai
metode yang dipilih user lewat menu Telegram.
"""

from __future__ import annotations

import functools

import yaml

import config
from .generic import GenericColorizer
from .palette_fm import PaletteFMColorizer
from .style2paints import Style2PaintsColorizer


@functools.lru_cache(maxsize=1)
def _load_selectors() -> dict:
    with open(config.SELECTORS_FILE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def reload_selectors() -> None:
    """Panggil ini kalau selectors.yaml baru diedit tanpa restart bot."""
    _load_selectors.cache_clear()


def get_palette_fm() -> PaletteFMColorizer:
    cfg = _load_selectors()["palette_fm"]
    return PaletteFMColorizer(cfg)


def get_deepai() -> GenericColorizer:
    cfg = _load_selectors()["deepai"]
    gc = GenericColorizer(cfg)
    gc.name = "deepai"
    return gc


def get_style2paints(version_key: str) -> Style2PaintsColorizer:
    cfg = _load_selectors()["style2paints"][version_key]
    return Style2PaintsColorizer(cfg, version_key)


def style2paints_versions() -> dict:
    """Dict {version_key: cfg} untuk membangun menu Telegram."""
    return _load_selectors()["style2paints"]
