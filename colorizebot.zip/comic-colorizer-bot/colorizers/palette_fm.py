"""
palette_fm.py
=============
Automasi untuk https://palette.fm/color/filters

Beda dengan colorizer lain, Palette.fm punya GALERI FILTER (21+ pilihan)
yang baru muncul SETELAH gambar di-upload. Jadi:

1. list_filters(sample_image)
   -> upload 1 gambar contoh (biasanya halaman pertama komik),
      lalu baca semua nama filter yang muncul di galeri.
      Hasil ini ditampilkan sebagai tombol pilihan di Telegram.

2. colorize(image_path, output_path, option=<nama_filter>)
   -> upload gambar, KLIK filter yang user pilih, tunggu hasil, download.

CATATAN PENTING — BACA INI:
Tanpa login / akun berbayar, hasil yang bisa diambil dari Palette.fm
biasanya:
  - mengandung watermark
  - dibatasi resolusi (sekitar 500x500px untuk preview)
Untuk komik, watermark + resolusi rendah akan sangat mengurangi kualitas.
Jika kamu punya akun berbayar Palette.fm, login manual sekali di browser
biasa, export cookies ke JSON, lalu isi `cookies_file` di selectors.yaml
(bagian palette_fm) supaya bot login otomatis dan dapat hasil resolusi
penuh tanpa watermark.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from playwright.async_api import Page

import config
from .browser_manager import browser_manager
from .errors import ColorizeError, SelectorNotFoundError
from .generic import GenericColorizer
from . import web_helpers as wh

log = logging.getLogger(__name__)


class PaletteFMColorizer(GenericColorizer):
    name = "palette_fm"

    async def _read_name(self, element) -> Optional[str]:
        source = self.cfg.get("filter_name_source", "text")
        if source == "text":
            text = await element.inner_text()
            return text.strip() if text else None
        attr = await element.get_attribute(source)
        return attr.strip() if attr else None

    async def _find_filter_element(self, page: Page, name: str):
        items = await page.query_selector_all(self.cfg["filter_item_selector"])
        for item in items:
            item_name = await self._read_name(item)
            if item_name and item_name == name:
                return item
        return None

    async def list_filters(self, sample_image_path: Path) -> list[str]:
        """Upload satu gambar contoh dan kembalikan daftar nama filter
        yang tersedia di galeri Palette.fm."""
        cfg = self.cfg
        context = await browser_manager.new_context(
            cookies_file=cfg.get("cookies_file") or None
        )
        page = await context.new_page()
        try:
            await page.goto(
                cfg["url"], wait_until="domcontentloaded", timeout=config.BROWSER_TIMEOUT_MS
            )
            await wh.upload_image(
                page,
                sample_image_path,
                cfg["file_input_selector"],
                cfg.get("upload_trigger_selector", ""),
            )
            wait_ms = cfg.get("wait_after_upload_ms", 0)
            if wait_ms:
                await page.wait_for_timeout(wait_ms)

            items = await page.query_selector_all(cfg["filter_item_selector"])
            names: list[str] = []
            for item in items:
                n = await self._read_name(item)
                if n and n not in names:
                    names.append(n)

            if not names:
                raise SelectorNotFoundError(
                    "Tidak menemukan elemen filter apa pun di halaman Palette.fm. "
                    "Kemungkinan tampilan website berubah — cek & perbarui "
                    "'filter_item_selector' di selectors.yaml "
                    "(gunakan tools/inspect_site.py untuk bantu cari selector)."
                )
            return names

        except ColorizeError:
            await wh.debug_screenshot(page, "palette_fm_list_filters")
            raise
        except Exception as e:
            await wh.debug_screenshot(page, "palette_fm_list_filters")
            raise ColorizeError(f"[palette_fm] Gagal mengambil daftar filter: {e}") from e
        finally:
            await context.close()

    async def _after_upload(self, page: Page, option: Optional[str]) -> None:
        if not option:
            return
        el = await self._find_filter_element(page, option)
        if el is None:
            raise SelectorNotFoundError(
                f"Filter '{option}' tidak ditemukan di halaman Palette.fm "
                f"(mungkin nama filter berubah - jalankan ulang pemilihan filter)."
            )
        await el.click()
        wait_ms = self.cfg.get("wait_after_filter_click_ms", 0)
        if wait_ms:
            await page.wait_for_timeout(wait_ms)
