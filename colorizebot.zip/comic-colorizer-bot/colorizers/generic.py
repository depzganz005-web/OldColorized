"""
generic.py
==========
GenericColorizer: implementasi default untuk pola umum
"upload gambar -> (klik submit/Generate) -> tunggu hasil BARU muncul
-> (klik Download) -> simpan file" yang dipakai banyak website AI
image-to-image (DeepAI Colorizer, dll).

PaletteFMColorizer (di palette_fm.py) extend class ini untuk menambahkan
logika "daftar & pilih filter" sebagai langkah `_after_upload`.

DETEKSI "HASIL SUDAH SIAP":
Daripada bergantung pada selector spesifik yang mudah berubah, dipakai
pendekatan "diffing": ambil snapshot src semua <img> SEBELUM aksi (klik
filter / klik Generate), lalu polling sampai ada <img> dgn src yang BELUM
ADA di snapshot itu. Src baru = hasil AI siap. Lihat web_helpers.py.

MENGAMBIL HASIL:
1. Jika `download_button_selector` diisi -> coba klik tombol itu &
   tangkap file lewat event `download` browser asli (mis. tombol
   "DOWNLOAD" di Palette.fm, sesuai instruksi: SETELAH hasil siap,
   klik Download).
2. Jika langkah 1 tidak menghasilkan file (selector kosong / tombol
   tidak memicu download) -> ambil langsung dari elemen <img> hasil
   yang ditemukan via diffing (data:/blob:/http).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from playwright.async_api import Page

import config
from .browser_manager import browser_manager
from .errors import ColorizeError, QuotaBlockedError
from . import web_helpers as wh

log = logging.getLogger(__name__)


class GenericColorizer:
    """Colorizer generik berbasis konfigurasi dari selectors.yaml."""

    name = "generic"

    def __init__(self, cfg: dict):
        self.cfg = cfg

    # ------------------------------------------------------------------
    # Hook yang bisa di-override subclass
    # ------------------------------------------------------------------
    async def _after_upload(self, page: Page, option: Optional[str]) -> None:
        """Dipanggil setelah upload selesai & snapshot src diambil, SEBELUM
        klik submit/Generate. PaletteFM override ini untuk klik nama
        filter pilihan user (yang JUGA memicu hasil baru, tanpa tombol
        submit terpisah)."""
        return None

    async def _click_submit_if_any(self, page: Page) -> None:
        submit_sel = self.cfg.get("submit_button_selector")
        if not submit_sel:
            return
        btn = await page.wait_for_selector(
            submit_sel, state="visible", timeout=config.BROWSER_TIMEOUT_MS
        )
        await btn.click()

    async def _check_quota_block(self, page: Page) -> None:
        quota_sel = self.cfg.get("quota_blocked_selector")
        if quota_sel and await wh.element_exists(page, quota_sel, timeout=2500):
            raise QuotaBlockedError(
                f"Website '{self.name}' meminta login / kuota gratis sudah habis. "
                f"Cek selectors.yaml -> {self.name} -> cookies_file jika kamu "
                f"punya akun untuk login otomatis."
            )

    # ------------------------------------------------------------------
    # Flow utama
    # ------------------------------------------------------------------
    async def colorize(
        self, image_path: Path, output_path: Path, option: Optional[str] = None
    ) -> Path:
        cfg = self.cfg
        context = await browser_manager.new_context(
            cookies_file=cfg.get("cookies_file") or None
        )
        page = await context.new_page()
        try:
            await page.goto(
                cfg["url"], wait_until="domcontentloaded", timeout=config.BROWSER_TIMEOUT_MS
            )

            await wh.upload_image(
                page,
                image_path,
                cfg["file_input_selector"],
                cfg.get("upload_trigger_selector", ""),
            )

            wait_ms = cfg.get("wait_after_upload_ms", 0)
            if wait_ms:
                await page.wait_for_timeout(wait_ms)

            # Snapshot SEBELUM aksi (klik filter / klik Generate) — semua
            # src yang sudah ada di sini (termasuk preview hasil upload,
            # thumbnail galeri filter, gambar contoh statis di halaman)
            # akan diabaikan saat mencari "hasil baru" nanti.
            scan_selector = cfg.get("result_image_selector") or "img"
            before_srcs = await wh.snapshot_image_srcs(page, scan_selector)

            await self._after_upload(page, option)
            await self._click_submit_if_any(page)
            await self._check_quota_block(page)

            # Jeda kecil opsional sebelum mulai polling (beri waktu UI
            # mulai transisi ke state "loading" sebelum src berubah).
            settle_ms = cfg.get("settle_before_poll_ms", 0)
            if settle_ms:
                await page.wait_for_timeout(settle_ms)

            result_el, _src = await wh.wait_for_new_image(
                page, before_srcs, scan_selector, timeout=config.BROWSER_TIMEOUT_MS
            )

            # 1) Coba klik tombol Download (jika dikonfigurasi) — sesuai
            #    instruksi: setelah hasil siap, klik Download saja.
            download_sel = cfg.get("download_button_selector", "")
            download_timeout = cfg.get("download_timeout_ms", 15000)
            got_download = await wh.try_download_via_button(
                page, download_sel, output_path, timeout_ms=download_timeout
            )

            # 2) Fallback: ambil langsung dari <img> hasil yang ditemukan.
            if not got_download:
                await wh.download_image_element(page, result_el, output_path)

            return output_path

        except ColorizeError:
            await wh.debug_screenshot(page, self.name)
            raise
        except Exception as e:
            await wh.debug_screenshot(page, self.name)
            raise ColorizeError(f"[{self.name}] {e}") from e
        finally:
            await context.close()
