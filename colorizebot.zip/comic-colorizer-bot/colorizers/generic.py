"""
generic.py
==========
GenericColorizer: implementasi default untuk pola umum
"upload gambar -> (klik submit) -> tunggu hasil -> download hasil"
yang dipakai banyak website AI image-to-image.

DeepAI Colorizer memakai class ini langsung. PaletteFMColorizer
(di palette_fm.py) extend class ini untuk menambahkan logika
"daftar & pilih filter".
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from playwright.async_api import Page

import config
from .browser_manager import browser_manager
from .errors import ColorizeError, QuotaBlockedError
from . import web_helpers as wh

log = logging.getLogger(__name__)


class GenericColorizer:
    """Colorizer generik berbasis konfigurasi dari selectors.yaml."""

    name = "generic"

    def __init__(self, cfg: dict):
        self.cfg = cfg

    # ------------------------------------------------------------------
    # Hook yang bisa di-override subclass
    # ------------------------------------------------------------------
    async def _after_upload(self, page: Page, option: Optional[str]) -> None:
        """Dipanggil setelah upload selesai, sebelum klik submit.
        PaletteFM override ini untuk klik filter pilihan user."""
        return None

    async def _click_submit_if_any(self, page: Page) -> None:
        submit_sel = self.cfg.get("submit_button_selector")
        if not submit_sel:
            return
        btn = await page.wait_for_selector(
            submit_sel, state="visible", timeout=config.BROWSER_TIMEOUT_MS
        )
        await btn.click()

    async def _check_quota_block(self, page: Page) -> None:
        quota_sel = self.cfg.get("quota_blocked_selector")
        if quota_sel and await wh.element_exists(page, quota_sel, timeout=2500):
            raise QuotaBlockedError(
                f"Website '{self.name}' meminta login / kuota gratis sudah habis. "
                f"Cek selectors.yaml -> {self.name} -> cookies_file jika kamu "
                f"punya akun untuk login otomatis."
            )

    async def _wait_loading_done(self, page: Page) -> None:
        loading_sel = self.cfg.get("loading_indicator_selector")
        if not loading_sel:
            return
        try:
            await page.wait_for_selector(
                loading_sel, state="hidden", timeout=config.BROWSER_TIMEOUT_MS
            )
        except Exception:
            # Tidak fatal — lanjut ke wait_for_result_image yang punya
            # timeout & polling sendiri.
            pass

    # ------------------------------------------------------------------
    # Flow utama
    # ------------------------------------------------------------------
    async def colorize(
        self, image_path: Path, output_path: Path, option: Optional[str] = None
    ) -> Path:
        cfg = self.cfg
        context = await browser_manager.new_context(
            cookies_file=cfg.get("cookies_file") or None
        )
        page = await context.new_page()
        try:
            await page.goto(
                cfg["url"], wait_until="domcontentloaded", timeout=config.BROWSER_TIMEOUT_MS
            )

            await wh.upload_image(
                page,
                image_path,
                cfg["file_input_selector"],
                cfg.get("upload_trigger_selector", ""),
            )

            wait_ms = cfg.get("wait_after_upload_ms", 0)
            if wait_ms:
                await page.wait_for_timeout(wait_ms)

            await self._after_upload(page, option)
            await self._click_submit_if_any(page)
            await self._check_quota_block(page)
            await self._wait_loading_done(page)

            el = await wh.wait_for_result_image(
                page, cfg["result_image_selector"], timeout=config.BROWSER_TIMEOUT_MS
            )
            await wh.download_image_element(page, el, output_path)
            return output_path

        except ColorizeError:
            await wh.debug_screenshot(page, self.name)
            raise
        except Exception as e:
            await wh.debug_screenshot(page, self.name)
            raise ColorizeError(f"[{self.name}] {e}") from e
        finally:
            await context.close()
