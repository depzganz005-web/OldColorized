"""
style2paints.py
================
Style2Paints punya 5 "versi" dengan status sangat berbeda:

- v4 & v4.5 : APLIKASI DESKTOP WINDOWS (.exe), didownload manual oleh
              pembuatnya dari Google Drive/Baidu. TIDAK ADA versi web.
              -> tidak bisa diotomasi browser di VPS Linux.

- v3        : menurut repo resminya, versi publiknya "hanya untuk
              programmer" (perlu menjalankan server sendiri dari
              source code, bukan website siap pakai).

- v1 / v2   : versi publiknya adalah "PaintsChainer" (Preferred Networks,
              paintschainer.preferred.tech). Status online layanan ini
              TIDAK DIPASTIKAN aktif terus.

Karena itu, v1/v2/v3 di-set `enabled: false` secara default di
selectors.yaml. Bot tetap menampilkan ke-5 versi di menu Telegram
(transparan ke user), tapi:

- Pilih v4 / v4.5  -> tampil pesan penjelasan (tidak ada proses gambar).
- Pilih v1/v2/v3 yang belum enabled -> tampil instruksi cara
  mengaktifkan via selectors.yaml.
- Pilih v1/v2/v3 yang sudah enabled+dikonfigurasi -> jalan seperti
  colorizer lain (upload -> proses -> download), pakai GenericColorizer.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from .errors import NotSupportedError
from .generic import GenericColorizer

DESKTOP_ONLY_NOTE = (
    "{label} hanya tersedia sebagai APLIKASI DESKTOP WINDOWS (.exe) yang "
    "didownload manual dari Google Drive/Baidu oleh pembuatnya "
    "(lihat github.com/lllyasviel/style2paints). Tidak ada versi website, "
    "sehingga TIDAK BISA diotomasi lewat browser di VPS Linux ini.\n\n"
    "Silakan pilih Palette.fm atau DeepAI Colorizer, atau jalankan "
    "Style2Paints versi ini secara manual di PC Windows kamu."
)

NOT_CONFIGURED_NOTE = (
    "{label} belum aktif di bot ini.\n\n"
    "Versi publik untuk v1/v2/v3 (PaintsChainer / server komunitas) "
    "statusnya tidak selalu pasti online. Cara mengaktifkan:\n"
    "1. Dari VPS, cek apakah URL layanan masih hidup.\n"
    "2. Edit selectors.yaml -> style2paints -> {key}: set enabled: true "
    "dan isi 'url'.\n"
    "3. Jalankan: python3 tools/inspect_site.py \"<url>\" untuk dapat "
    "selector yang akurat.\n"
    "4. Isi file_input_selector, submit_button_selector, dan "
    "result_image_selector di selectors.yaml.\n"
    "5. Restart bot (sudah otomatis baca ulang selectors.yaml saat job baru)."
)


class Style2PaintsColorizer(GenericColorizer):
    name = "style2paints"

    def __init__(self, cfg: dict, version_key: str):
        super().__init__(cfg)
        self.version_key = version_key
        self.label = cfg.get("label", f"Style2Paints {version_key}")

    async def colorize(
        self, image_path: Path, output_path: Path, option: Optional[str] = None
    ) -> Path:
        if self.version_key in ("v4", "v45"):
            raise NotSupportedError(DESKTOP_ONLY_NOTE.format(label=self.label))

        if not self.cfg.get("enabled", False) or not self.cfg.get("url"):
            raise NotSupportedError(
                NOT_CONFIGURED_NOTE.format(label=self.label, key=self.version_key)
            )

        return await super().colorize(image_path, output_path, option)
