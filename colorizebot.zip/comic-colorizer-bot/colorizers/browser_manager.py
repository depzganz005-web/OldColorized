"""
browser_manager.py
===================
Mengelola satu instance Chromium (Playwright) yang dipakai berulang
untuk semua job, supaya tidak perlu start/stop browser tiap halaman
(start browser itu "berat" — bisa 1-2 detik tiap kali).

Tiap halaman komik diproses dalam BrowserContext baru (sesi bersih,
tanpa cookie/cache nyangkut dari proses sebelumnya), lalu context
ditutup setelah selesai.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional

from playwright.async_api import Browser, BrowserContext, Playwright, async_playwright

import config

log = logging.getLogger(__name__)

# User-Agent "normal" supaya tidak terlalu mencolok sebagai headless bot.
DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)


class BrowserManager:
    """Singleton sederhana untuk Playwright + Chromium."""

    def __init__(self) -> None:
        self._playwright: Optional[Playwright] = None
        self._browser: Optional[Browser] = None

    async def start(self) -> None:
        if self._browser is not None:
            return
        log.info("Memulai Playwright + Chromium (headless=%s)...", config.BROWSER_HEADLESS)
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(
            headless=config.BROWSER_HEADLESS,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-dev-shm-usage",
            ],
        )

    async def stop(self) -> None:
        if self._browser:
            await self._browser.close()
            self._browser = None
        if self._playwright:
            await self._playwright.stop()
            self._playwright = None
        log.info("Browser dimatikan.")

    async def new_context(self, cookies_file: str | Path | None = None) -> BrowserContext:
        """
        Buat BrowserContext baru (= sesi browser bersih: cookies/localStorage
        terpisah). Jika cookies_file diisi dan filenya ada, cookies akan
        di-load (berguna untuk akun berbayar / login tersimpan).
        """
        if self._browser is None:
            await self.start()
        assert self._browser is not None

        context = await self._browser.new_context(
            user_agent=DEFAULT_USER_AGENT,
            viewport={"width": 1366, "height": 900},
            accept_downloads=True,
        )

        if cookies_file:
            path = Path(cookies_file)
            if path.is_file():
                try:
                    cookies = json.loads(path.read_text())
                    await context.add_cookies(cookies)
                    log.info("Cookies dimuat dari %s", path)
                except Exception:
                    log.exception("Gagal memuat cookies dari %s", path)

        return context


# Instance global yang dipakai seluruh aplikasi
browser_manager = BrowserManager()
