"""Exception khusus supaya bot.py bisa memberi pesan yang jelas ke user."""


class ColorizeError(Exception):
    """Error umum saat proses colorize satu halaman gagal."""


class SelectorNotFoundError(ColorizeError):
    """
    Elemen yang dicari (tombol/input/hasil) tidak ditemukan di halaman.
    Biasanya artinya tampilan website berubah -> selector di
    selectors.yaml perlu diperbarui (jalankan tools/inspect_site.py).
    """


class QuotaBlockedError(ColorizeError):
    """Website meminta login / quota gratis habis."""


class NotSupportedError(ColorizeError):
    """Metode/versi yang dipilih tidak didukung (misal style2paints v4.5)."""
