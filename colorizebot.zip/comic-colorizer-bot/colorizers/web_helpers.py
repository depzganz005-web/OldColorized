"""
web_helpers.py
==============
Fungsi-fungsi bantu yang dipakai berulang oleh semua modul colorizer:

- upload_image()          : isi <input type="file"> dengan gambar
- snapshot_image_srcs()   : ambil daftar src semua <img> SAAT INI (sebelum aksi)
- wait_for_new_image()    : tunggu sampai ada <img> dgn src BARU (hasil AI)
                             dibandingkan snapshot sebelumnya
- try_download_via_button(): klik tombol "Download" & tangkap file via
                             event download asli browser (jika ada)
- download_image_element(): simpan <img> (src http / data: / blob:) ke disk
- debug_screenshot()      : simpan screenshot saat error, untuk debugging

Pendekatan "diffing src" dipakai karena banyak website AI modern TIDAK
mengganti elemen <img> yang sama / tidak punya selector hasil yang stabil —
tapi SELALU memunculkan src BARU (data:/blob:/URL CDN) begitu hasil siap,
baik untuk Palette.fm (klik filter) maupun DeepAI (klik "Generate").
"""

from __future__ import annotations

import base64
import logging
import time
from pathlib import Path
from urllib.parse import urljoin

from playwright.async_api import Page, TimeoutError as PWTimeoutError

import config
from .errors import SelectorNotFoundError

log = logging.getLogger(__name__)

# src yang dianggap "placeholder/kosong", diabaikan saat snapshot & diffing.
_PLACEHOLDER_PREFIXES = (
    "data:image/gif",  # umum dipakai sbg 1x1 transparent placeholder
    "data:,",
)


async def debug_screenshot(page: Page, name: str) -> Path:
    """Simpan screenshot halaman saat ini ke folder debug_screenshots."""
    ts = int(time.time())
    out = config.SCREENSHOTS_DIR / f"{name}_{ts}.png"
    try:
        await page.screenshot(path=str(out), full_page=True)
        log.warning("Debug screenshot disimpan: %s", out)
    except Exception:
        log.exception("Gagal mengambil screenshot debug")
    return out


async def upload_image(
    page: Page,
    image_path: Path,
    file_input_selector: str,
    upload_trigger_selector: str = "",
    timeout: int | None = None,
) -> None:
    """
    Upload gambar lewat <input type="file">.

    Jika `upload_trigger_selector` diisi, klik elemen itu dulu
    (beberapa website hanya menyuntikkan <input type="file"> ke DOM
    setelah tombol "Upload"/"Choose file" diklik).
    """
    timeout = timeout or config.BROWSER_TIMEOUT_MS

    if upload_trigger_selector:
        try:
            trigger = await page.wait_for_selector(
                upload_trigger_selector, state="visible", timeout=timeout
            )
            await trigger.click()
        except Exception as e:
            raise SelectorNotFoundError(
                f"Tombol upload tidak ditemukan: {upload_trigger_selector!r}"
            ) from e

    try:
        file_input = await page.wait_for_selector(
            file_input_selector, state="attached", timeout=timeout
        )
    except Exception as e:
        raise SelectorNotFoundError(
            f"Input file tidak ditemukan: {file_input_selector!r}"
        ) from e

    await file_input.set_input_files(str(image_path))


def _is_placeholder_src(src: str | None) -> bool:
    if not src or not src.strip():
        return True
    return any(src.startswith(p) for p in _PLACEHOLDER_PREFIXES)


async def snapshot_image_srcs(page: Page, selector: str = "img") -> set[str]:
    """
    Ambil "potret" src semua elemen yang match `selector` SAAT INI.

    Dipanggil SEBELUM aksi yang memicu hasil baru (klik filter / klik
    Generate), supaya nanti bisa dibandingkan dgn kondisi SESUDAH aksi
    -> src yang BARU MUNCUL = hasil AI.
    """
    srcs: set[str] = set()
    try:
        elements = await page.query_selector_all(selector)
    except Exception:
        return srcs
    for el in elements:
        try:
            src = await el.get_attribute("src")
        except Exception:
            continue
        if not _is_placeholder_src(src):
            srcs.add(src)
    return srcs


async def wait_for_new_image(
    page: Page,
    before_srcs: set[str],
    selector: str = "img",
    timeout: int | None = None,
    poll_interval_ms: int = 800,
):
    """
    Polling sampai ada elemen `selector` dengan `src` yang TIDAK ADA di
    `before_srcs` (= belum pernah terlihat sebelum aksi dilakukan).

    Ini adalah sinyal "hasil AI sudah siap" yang generik — bekerja baik
    untuk:
    - Palette.fm: klik nama filter -> src gambar preview berubah jadi
      hasil filter itu (data:image/... base64 baru).
    - DeepAI: klik "Generate" -> muncul <img> BARU (elemen baru di DOM)
      berisi hasil colorize, terpisah dari <img> preview upload.

    Returns: (ElementHandle, src_baru)
    """
    timeout = timeout or config.BROWSER_TIMEOUT_MS
    deadline = time.monotonic() + (timeout / 1000)

    last_err: Exception | None = None
    while time.monotonic() < deadline:
        try:
            elements = await page.query_selector_all(selector)
            for el in elements:
                src = await el.get_attribute("src")
                if _is_placeholder_src(src):
                    continue
                if src not in before_srcs:
                    return el, src
        except Exception as e:
            last_err = e
        await page.wait_for_timeout(poll_interval_ms)

    raise SelectorNotFoundError(
        f"Hasil gambar baru tidak muncul dalam {timeout}ms "
        f"(selector: {selector!r}). Kemungkinan tampilan website berubah "
        f"atau proses AI gagal/lambat. Error terakhir: {last_err}"
    )


async def try_download_via_button(
    page: Page,
    download_button_selector: str,
    out_path: Path,
    timeout_ms: int = 15000,
) -> bool:
    """
    Coba klik tombol "Download" dan tangkap file via event `download`
    BAWAAN BROWSER (Playwright `expect_download`). Ini menangkap apapun
    yang dipicu tombol — <a download>, blob URL, redirect server
    dengan header Content-Disposition, dll — TANPA perlu tahu detail
    implementasinya.

    Returns True jika berhasil & file tersimpan ke `out_path`.
    Returns False (TANPA exception) jika:
    - `download_button_selector` kosong / tombolnya tidak ditemukan, atau
    - klik tidak memicu event download dalam `timeout_ms`
      (misal tombol hanya mengganti tampilan <img>, bukan file download).

    Caller HARUS punya fallback (mis. download_image_element dari <img>
    hasil yang sudah ditemukan via wait_for_new_image) jika ini False.
    """
    if not download_button_selector:
        return False

    try:
        btn = await page.wait_for_selector(
            download_button_selector, state="visible", timeout=3000
        )
    except Exception:
        log.info("Tombol download tidak ditemukan (selector: %r) — skip, pakai fallback.",
                 download_button_selector)
        return False

    try:
        async with page.expect_download(timeout=timeout_ms) as download_info:
            await btn.click()
        download = await download_info.value
    except PWTimeoutError:
        log.info("Klik tombol download tidak memicu event download dalam %dms — "
                 "pakai fallback (ambil <img> hasil langsung).", timeout_ms)
        return False
    except Exception:
        log.exception("Error saat mencoba download via tombol — pakai fallback.")
        return False

    out_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        await download.save_as(str(out_path))
    except Exception:
        log.exception("Gagal menyimpan hasil download tombol — pakai fallback.")
        return False

    if not out_path.exists() or out_path.stat().st_size == 0:
        return False
    return True


async def _src_to_dataurl_via_canvas(element) -> str | None:
    """
    Konversi <img> dengan src blob:/same-origin menjadi data-URL lewat
    <canvas>.drawImage + toDataURL. Dipakai untuk src yang berupa
    `blob:...` (tidak bisa di-fetch via HTTP biasa).

    Bisa gagal dengan SecurityError ("tainted canvas") jika gambar
    cross-origin tanpa header CORS yang sesuai — di kasus itu return None
    dan caller harus coba cara lain.
    """
    try:
        return await element.evaluate(
            """
            (img) => {
                const canvas = document.createElement('canvas');
                canvas.width = img.naturalWidth || img.width;
                canvas.height = img.naturalHeight || img.height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0);
                return canvas.toDataURL('image/png');
            }
            """
        )
    except Exception:
        return None


async def download_image_element(page: Page, element, out_path: Path) -> Path:
    """
    Simpan elemen <img> ke file. Menangani tiga kasus src:
    1. "data:image/...;base64,xxxx" -> decode langsung.
    2. "blob:..."                    -> convert via <canvas> (same-origin,
                                         biasanya aman dari masalah CORS).
    3. "https://..." / "//..." / "/..." -> fetch lewat session browser
                                            (ikut cookies & header yang sama).
       Jika fetch HTTP gagal (mis. CORS/hotlink-protection), coba fallback
       ke <canvas> juga.
    """
    src = await element.get_attribute("src")
    if not src:
        raise SelectorNotFoundError("Elemen <img> hasil tidak punya atribut src")

    out_path.parent.mkdir(parents=True, exist_ok=True)

    if src.startswith("data:image"):
        header, b64data = src.split(",", 1)
        data = base64.b64decode(b64data)
        out_path.write_bytes(data)
        return out_path

    if src.startswith("blob:"):
        data_url = await _src_to_dataurl_via_canvas(element)
        if data_url and data_url.startswith("data:image"):
            header, b64data = data_url.split(",", 1)
            out_path.write_bytes(base64.b64decode(b64data))
            return out_path
        raise SelectorNotFoundError(
            "Src hasil berupa blob: tapi gagal dikonversi via canvas "
            "(kemungkinan tainted-canvas/CORS). Coba aktifkan "
            "download_button_selector di selectors.yaml untuk website ini."
        )

    # http(s) / protocol-relative / root-relative -> URL absolut
    abs_src = urljoin(page.url, src)

    resp = await page.context.request.get(abs_src)
    if resp.ok:
        out_path.write_bytes(await resp.body())
        return out_path

    # Fallback terakhir: coba canvas (kalau same-origin & tidak tainted)
    data_url = await _src_to_dataurl_via_canvas(element)
    if data_url and data_url.startswith("data:image"):
        header, b64data = data_url.split(",", 1)
        out_path.write_bytes(base64.b64decode(b64data))
        return out_path

    raise SelectorNotFoundError(
        f"Gagal download hasil gambar dari {abs_src} (HTTP {resp.status})"
    )


async def element_exists(page: Page, selector: str, timeout: int = 1500) -> bool:
    """Cek cepat apakah sebuah elemen ada (untuk deteksi quota-block, dll)."""
    if not selector:
        return False
    try:
        await page.wait_for_selector(selector, state="visible", timeout=timeout)
        return True
    except Exception:
        return False
