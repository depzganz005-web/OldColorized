"""
web_helpers.py
==============
Fungsi-fungsi bantu yang dipakai berulang oleh semua modul colorizer:

- upload_image()        : isi <input type="file"> dengan gambar
- wait_for_result_image(): tunggu sampai elemen <img> hasil muncul & "matang"
- download_image_element(): simpan <img> (src http / data-uri) ke disk
- debug_screenshot()    : simpan screenshot saat error, untuk debugging
"""

from __future__ import annotations

import base64
import logging
import time
from pathlib import Path
from urllib.parse import urljoin

from playwright.async_api import Page

import config
from .errors import SelectorNotFoundError

log = logging.getLogger(__name__)


async def debug_screenshot(page: Page, name: str) -> Path:
    """Simpan screenshot halaman saat ini ke folder debug_screenshots."""
    ts = int(time.time())
    out = config.SCREENSHOTS_DIR / f"{name}_{ts}.png"
    try:
        await page.screenshot(path=str(out), full_page=True)
        log.warning("Debug screenshot disimpan: %s", out)
    except Exception:
        log.exception("Gagal mengambil screenshot debug")
    return out


async def upload_image(
    page: Page,
    image_path: Path,
    file_input_selector: str,
    upload_trigger_selector: str = "",
    timeout: int | None = None,
) -> None:
    """
    Upload gambar lewat <input type="file">.

    Jika `upload_trigger_selector` diisi, klik elemen itu dulu
    (beberapa website hanya menyuntikkan <input type="file"> ke DOM
    setelah tombol "Upload"/"Choose file" diklik).
    """
    timeout = timeout or config.BROWSER_TIMEOUT_MS

    if upload_trigger_selector:
        try:
            trigger = await page.wait_for_selector(
                upload_trigger_selector, state="visible", timeout=timeout
            )
            await trigger.click()
        except Exception as e:
            raise SelectorNotFoundError(
                f"Tombol upload tidak ditemukan: {upload_trigger_selector!r}"
            ) from e

    try:
        file_input = await page.wait_for_selector(
            file_input_selector, state="attached", timeout=timeout
        )
    except Exception as e:
        raise SelectorNotFoundError(
            f"Input file tidak ditemukan: {file_input_selector!r}"
        ) from e

    await file_input.set_input_files(str(image_path))


async def wait_for_result_image(
    page: Page,
    result_selector: str,
    timeout: int | None = None,
    poll_interval_ms: int = 1000,
):
    """
    Tunggu sampai elemen <img> hasil muncul DAN punya `src` yang valid
    (banyak website me-render elemen <img> lebih dulu lalu mengisi
    `src` setelah AI selesai memproses).

    Returns: ElementHandle dari <img> hasil.
    """
    timeout = timeout or config.BROWSER_TIMEOUT_MS
    deadline = time.monotonic() + (timeout / 1000)

    last_err: Exception | None = None
    while time.monotonic() < deadline:
        try:
            el = await page.wait_for_selector(
                result_selector, state="visible", timeout=poll_interval_ms
            )
            src = await el.get_attribute("src")
            if src and src.strip() and not src.startswith("data:image/gif"):
                # data:image/gif biasanya placeholder loading 1x1
                return el
        except Exception as e:  # timeout pendek tiap poll, lanjut loop
            last_err = e
        await page.wait_for_timeout(poll_interval_ms)

    raise SelectorNotFoundError(
        f"Hasil gambar tidak muncul dalam {timeout}ms "
        f"(selector: {result_selector!r}). Error terakhir: {last_err}"
    )


async def download_image_element(page: Page, element, out_path: Path) -> Path:
    """
    Simpan elemen <img> ke file. Menangani dua kasus:
    1. src="data:image/...;base64,xxxx"  -> decode langsung
    2. src="https://..."                  -> fetch lewat session browser
                                              (ikut cookies & header yang sama)
    """
    src = await element.get_attribute("src")
    if not src:
        raise SelectorNotFoundError("Elemen <img> hasil tidak punya atribut src")

    out_path.parent.mkdir(parents=True, exist_ok=True)

    if src.startswith("data:image"):
        header, b64data = src.split(",", 1)
        data = base64.b64decode(b64data)
        out_path.write_bytes(data)
        return out_path

    # Pastikan URL absolut
    src = urljoin(page.url, src)

    resp = await page.context.request.get(src)
    if not resp.ok:
        raise SelectorNotFoundError(
            f"Gagal download hasil gambar dari {src} (HTTP {resp.status})"
        )
    out_path.write_bytes(await resp.body())
    return out_path


async def element_exists(page: Page, selector: str, timeout: int = 1500) -> bool:
    """Cek cepat apakah sebuah elemen ada (untuk deteksi quota-block, dll)."""
    try:
        await page.wait_for_selector(selector, state="visible", timeout=timeout)
        return True
    except Exception:
        return False
