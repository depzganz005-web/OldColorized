"""Package berisi modul-modul automasi browser untuk tiap website colorizer."""
