"""
test_bot_structure.py
======================
Memverifikasi bot.py bisa di-import & berfungsi secara STRUKTURAL
menggunakan stub minimal untuk python-telegram-bot (yang tidak
terpasang di sandbox ini). Ini menangkap bug seperti NameError,
AttributeError, callback_data > 64 byte, dsb — yang tidak ketahuan
dari py_compile (cek syntax saja).

Tidak menguji jaringan/Telegram API sungguhan — itu sudah dicover oleh
test_pipeline.py & test_run_job_logic.py.
"""

from __future__ import annotations

import os
import sys

# Stub python-telegram-bot harus didahulukan di sys.path
sys.path.insert(0, "/home/claude/stub_pkgs")

# config.validate() butuh env ini -> isi dummy sebelum import bot
os.environ["TELEGRAM_BOT_TOKEN"] = "dummy:token"
os.environ["ALLOWED_USER_IDS"] = "12345"

import bot  # noqa: E402
from colorizers import factory  # noqa: E402
from colorizers.generic import GenericColorizer  # noqa: E402
from colorizers.palette_fm import PaletteFMColorizer  # noqa: E402
from colorizers.style2paints import Style2PaintsColorizer  # noqa: E402


def check_callback_lengths(markup) -> None:
    for row in markup.inline_keyboard:
        for btn in row:
            cb = btn.callback_data
            assert cb is not None, f"Button '{btn.text}' tanpa callback_data"
            assert len(cb.encode()) <= 64, f"callback_data terlalu panjang: {cb!r}"


def test_kb_method():
    print("=== kb_method ===")
    m = bot.kb_method()
    check_callback_lengths(m)
    cbs = [b.callback_data for row in m.inline_keyboard for b in row]
    print(" callback_data:", cbs)
    assert cbs == ["m:palette_fm", "m:style2paints", "m:deepai"]


def test_kb_filters_pagination():
    print("=== kb_filters (pagination) ===")
    names = [f"Filter {i}" for i in range(22)]  # > FILTERS_PER_PAGE

    m0 = bot.kb_filters(names, 0)
    check_callback_lengths(m0)
    flat0 = [b.callback_data for row in m0.inline_keyboard for b in row]
    print(" page0:", flat0)
    assert "fp:1" in flat0
    assert "back" in flat0
    assert "f:0" in flat0 and "f:7" in flat0
    assert "f:8" not in flat0

    m1 = bot.kb_filters(names, 1)
    flat1 = [b.callback_data for row in m1.inline_keyboard for b in row]
    print(" page1:", flat1)
    assert "fp:0" in flat1 and "fp:2" in flat1
    assert "f:8" in flat1 and "f:15" in flat1

    m2 = bot.kb_filters(names, 2)
    flat2 = [b.callback_data for row in m2.inline_keyboard for b in row]
    print(" page2:", flat2)
    assert "fp:1" in flat2
    assert "fp:3" not in flat2
    assert "f:21" in flat2

    long_names = ["X" * 40]
    m = bot.kb_filters(long_names, 0)
    label = m.inline_keyboard[0][0].text
    print(" label panjang dipotong jadi:", repr(label), "len=", len(label))
    assert len(label) == 24
    assert label.endswith("…")


def test_kb_style2paints():
    print("=== kb_style2paints ===")
    m = bot.kb_style2paints()
    check_callback_lengths(m)
    for row in m.inline_keyboard:
        for b in row:
            print(" ", b)
    cbs = [b.callback_data for row in m.inline_keyboard for b in row]
    assert cbs == ["s:v1", "s:v2", "s:v3", "s:v4", "s:v45", "back"]

    labels = {b.callback_data: b.text for row in m.inline_keyboard for b in row}
    assert labels["s:v4"].startswith("❌")
    assert labels["s:v45"].startswith("❌")
    assert labels["s:v1"].startswith("⚠️")  # default selectors.yaml: enabled=false


def test_kb_confirm_and_cancel():
    print("=== kb_confirm & kb_cancel_processing ===")
    m = bot.kb_confirm()
    check_callback_lengths(m)
    cbs = [b.callback_data for row in m.inline_keyboard for b in row]
    assert cbs == ["go", "back", "abort"]

    m2 = bot.kb_cancel_processing("abcd1234")
    check_callback_lengths(m2)
    assert m2.inline_keyboard[0][0].callback_data == "stop:abcd1234"


def test_method_display():
    print("=== method_display ===")
    assert bot.method_display("deepai", None) == "DeepAI Colorizer"
    assert "Vintage" in bot.method_display("palette_fm", "Vintage")
    s2p_label = bot.method_display("style2paints", "v1")
    print(" style2paints v1 ->", s2p_label)
    assert "Style2Paints" in s2p_label or "PaintsChainer" in s2p_label
    assert bot.method_display(None, None) == "-"


def test_get_colorizer():
    print("=== _get_colorizer ===")
    assert isinstance(bot._get_colorizer("palette_fm", "Vintage"), PaletteFMColorizer)
    dc = bot._get_colorizer("deepai", None)
    assert isinstance(dc, GenericColorizer)
    assert dc.name == "deepai"
    s2p = bot._get_colorizer("style2paints", "v45")
    assert isinstance(s2p, Style2PaintsColorizer)
    assert s2p.version_key == "v45"
    try:
        bot._get_colorizer("unknown", None)
        raise AssertionError("harus ValueError")
    except ValueError:
        pass


def test_factory_consistency():
    print("=== factory.style2paints_versions() ===")
    versions = factory.style2paints_versions()
    assert set(versions.keys()) == {"v1", "v2", "v3", "v4", "v45"}
    for k, v in versions.items():
        print(f"  {k}: enabled={v.get('enabled')} label={v.get('label')!r}")


def test_main_registration():
    print("=== main() handler registration (stub) ===")
    bot.main()
    print(" handlers terdaftar OK (stub run_polling dipanggil tanpa error)")


if __name__ == "__main__":
    test_kb_method()
    test_kb_filters_pagination()
    test_kb_style2paints()
    test_kb_confirm_and_cancel()
    test_method_display()
    test_get_colorizer()
    test_factory_consistency()
    test_main_registration()
    print("\nSEMUA TEST STRUKTUR bot.py LULUS ✅")
