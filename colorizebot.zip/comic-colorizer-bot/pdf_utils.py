"""
pdf_utils.py
============
Utility untuk:
1. Memecah file PDF (komik) menjadi gambar PNG per halaman.
2. Menggabungkan kembali kumpulan gambar menjadi satu file PDF.

Menggunakan:
- pypdfium2  -> render halaman PDF ke gambar (bundle PDFium, tidak perlu
                install poppler terpisah; sudah diuji jalan)
- Pillow (PIL) -> menggabungkan gambar menjadi PDF
"""

from __future__ import annotations

import logging
from pathlib import Path

import pypdfium2 as pdfium
from PIL import Image

log = logging.getLogger(__name__)


def pdf_to_images(pdf_path: Path, out_dir: Path, dpi: int = 160) -> list[Path]:
    """
    Pecah setiap halaman PDF menjadi file PNG terpisah.

    Args:
        pdf_path: path file PDF sumber.
        out_dir: folder tujuan, dibuat otomatis jika belum ada.
        dpi: resolusi render. 150-200 sudah cukup tajam untuk komik
             dan tidak membuat ukuran file membengkak.

    Returns:
        List path PNG, terurut sesuai urutan halaman (page_0001.png, ...).
    """
    out_dir.mkdir(parents=True, exist_ok=True)

    scale = dpi / 72.0  # 72 dpi = skala 1:1 di PDF

    pdf = pdfium.PdfDocument(str(pdf_path))
    paths: list[Path] = []
    try:
        for i in range(len(pdf)):
            page = pdf[i]
            try:
                bitmap = page.render(scale=scale)
                pil_image = bitmap.to_pil()
                out_path = out_dir / f"page_{i + 1:04d}.png"
                pil_image.save(out_path)
                paths.append(out_path)
                log.debug("Rendered %s (%dx%d)", out_path.name, *pil_image.size)
            finally:
                page.close()
    finally:
        pdf.close()

    log.info("pdf_to_images: %d halaman -> %s", len(paths), out_dir)
    return paths


def images_to_pdf(image_paths: list[Path], out_pdf: Path) -> Path:
    """
    Gabungkan beberapa gambar (urut) menjadi satu file PDF multi-halaman.

    Args:
        image_paths: list path gambar, akan diurutkan secara alfabetis
                     (gunakan penamaan page_0001.png, page_0002.png, dst).
        out_pdf: path file PDF output.

    Returns:
        Path file PDF yang dihasilkan.
    """
    if not image_paths:
        raise ValueError("Tidak ada gambar untuk digabung jadi PDF")

    out_pdf.parent.mkdir(parents=True, exist_ok=True)

    ordered = sorted(image_paths, key=lambda p: p.name)

    images: list[Image.Image] = []
    for p in ordered:
        img = Image.open(p)
        # PDF tidak mendukung mode RGBA / P (palette) dengan baik -> convert ke RGB
        if img.mode != "RGB":
            img = img.convert("RGB")
        images.append(img)

    first, rest = images[0], images[1:]
    first.save(out_pdf, "PDF", save_all=True, append_images=rest)

    log.info("images_to_pdf: %d gambar -> %s (%.2f MB)",
             len(images), out_pdf, out_pdf.stat().st_size / 1_000_000)
    return out_pdf


def get_page_count(pdf_path: Path) -> int:
    """Hitung jumlah halaman tanpa merender (cepat, untuk validasi awal)."""
    pdf = pdfium.PdfDocument(str(pdf_path))
    try:
        return len(pdf)
    finally:
        pdf.close()


def images_to_pdf_parts(
    image_paths: list[Path],
    out_dir: Path,
    max_bytes: int,
    base_name: str = "hasil_colorized",
) -> list[tuple[Path, int, int]]:
    """
    Gabungkan gambar menjadi SATU file PDF jika ukurannya <= max_bytes.
    Jika lebih besar, pecah jadi beberapa file PDF (part1, part2, ...)
    yang masing-masing <= max_bytes, supaya semua halaman tetap bisa
    dikirim lewat Telegram meski total ukurannya besar.

    Args:
        image_paths: gambar halaman (urutan diambil dari nama file).
        out_dir: folder output untuk file PDF.
        max_bytes: batas ukuran tiap file PDF (bytes).
        base_name: nama dasar file output.

    Returns:
        List of (path_pdf, halaman_awal, halaman_akhir) — nomor halaman
        1-indexed sesuai urutan image_paths setelah di-sort. Jika hasil
        muat dalam satu file, list ini hanya berisi 1 elemen.
    """
    if not image_paths:
        raise ValueError("Tidak ada gambar untuk digabung jadi PDF")

    out_dir.mkdir(parents=True, exist_ok=True)
    ordered = sorted(image_paths, key=lambda p: p.name)
    n = len(ordered)

    # 1) Coba sebagai satu file dulu — ini kasus paling umum.
    single_path = out_dir / f"{base_name}.pdf"
    images_to_pdf(ordered, single_path)
    if n == 1 or single_path.stat().st_size <= max_bytes:
        return [(single_path, 1, n)]

    single_path.unlink()

    # 2) Perkiraan awal jumlah halaman per bagian, berdasarkan rata-rata
    #    ukuran gambar sumber (proporsional dengan ukuran PDF per halaman).
    total_img_bytes = sum(p.stat().st_size for p in ordered)
    avg = max(total_img_bytes / n, 1)
    pages_per_part = max(1, int(max_bytes / avg * 0.85))

    parts: list[tuple[Path, int, int]] = []
    idx = 0
    part_num = 1
    while idx < n:
        chunk = ordered[idx: idx + pages_per_part]
        part_path = out_dir / f"{base_name}_part{part_num}.pdf"
        images_to_pdf(chunk, part_path)

        # 3) Kalau perkiraan masih kurang akurat & part ini ternyata
        #    masih > max_bytes, kurangi halaman satu-satu sampai pas.
        while part_path.stat().st_size > max_bytes and len(chunk) > 1:
            chunk = chunk[:-1]
            images_to_pdf(chunk, part_path)

        parts.append((part_path, idx + 1, idx + len(chunk)))
        idx += len(chunk)
        part_num += 1

    log.info("images_to_pdf_parts: %d halaman -> %d bagian", n, len(parts))
    return parts
