"""
config.py
=========
Memuat semua konfigurasi bot dari file `.env` (lihat .env.example).

Jangan hardcode token / ID di sini — selalu lewat .env supaya aman
saat project di-share / commit ke git.
"""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

# Cari .env di root project (folder tempat file ini berada)
BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _env_bool(name: str, default: bool) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    val = os.getenv(name)
    if val is None or val.strip() == "":
        return default
    try:
        return int(val)
    except ValueError:
        return default


# ---------------------------------------------------------------------------
# Telegram
# ---------------------------------------------------------------------------
TELEGRAM_BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()

# Daftar user ID Telegram yang diizinkan pakai bot (pisah dengan koma).
# Kosongkan untuk mengizinkan semua orang (TIDAK disarankan untuk bot ini
# karena proses automasi browser berat di CPU/RAM VPS kamu).
_raw_allowed = os.getenv("ALLOWED_USER_IDS", "").strip()
ALLOWED_USER_IDS: set[int] = {
    int(x) for x in _raw_allowed.split(",") if x.strip().isdigit()
}

# ---------------------------------------------------------------------------
# PDF rendering
# ---------------------------------------------------------------------------
PDF_RENDER_DPI: int = _env_int("PDF_RENDER_DPI", 160)

# ---------------------------------------------------------------------------
# Browser automation (Playwright)
# ---------------------------------------------------------------------------
BROWSER_HEADLESS: bool = _env_bool("BROWSER_HEADLESS", True)
BROWSER_TIMEOUT_MS: int = _env_int("BROWSER_TIMEOUT_MS", 180_000)

# Berapa halaman diproses paralel. 1 = paling stabil & paling "sopan"
# terhadap website target. Naikkan dengan hati-hati (risiko diblokir / rate-limit).
CONCURRENCY: int = max(1, _env_int("CONCURRENCY", 1))

# ---------------------------------------------------------------------------
# Pengiriman hasil
# ---------------------------------------------------------------------------
# Batas aman ukuran file utk send_document Bot API (limit resmi 50MB).
# Hasil PDF yang lebih besar dari ini akan otomatis dipecah jadi beberapa
# file (part1, part2, ...) supaya SEMUA halaman tetap terkirim.
MAX_TELEGRAM_FILE_MB: int = _env_int("MAX_TELEGRAM_FILE_MB", 49)

# Kirim preview foto tiap halaman selesai di-colorize (rolling preview).
SEND_PAGE_PREVIEWS: bool = _env_bool("SEND_PAGE_PREVIEWS", True)

# Ukuran maksimum sisi terpanjang utk gambar preview (di-resize, bukan
# gambar final -- gambar final tetap dipakai utuh untuk PDF hasil).
PREVIEW_MAX_DIM: int = _env_int("PREVIEW_MAX_DIM", 1280)

# ---------------------------------------------------------------------------
# Folder kerja
# ---------------------------------------------------------------------------
WORKDIR: Path = Path(os.getenv("WORKDIR", str(BASE_DIR / "data"))).resolve()
UPLOADS_DIR = WORKDIR / "uploads"
PAGES_DIR = WORKDIR / "pages"
OUTPUT_DIR = WORKDIR / "output"
SCREENSHOTS_DIR = WORKDIR / "debug_screenshots"

for d in (UPLOADS_DIR, PAGES_DIR, OUTPUT_DIR, SCREENSHOTS_DIR):
    d.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Selector config (lokasi file YAML untuk automasi website)
# ---------------------------------------------------------------------------
SELECTORS_FILE: Path = BASE_DIR / "selectors.yaml"


def validate() -> None:
    """Panggil sekali saat startup untuk memastikan konfigurasi minimal valid."""
    problems = []
    if not TELEGRAM_BOT_TOKEN:
        problems.append("TELEGRAM_BOT_TOKEN belum diisi di .env")
    if not ALLOWED_USER_IDS:
        problems.append(
            "ALLOWED_USER_IDS belum diisi di .env "
            "(isi dengan user ID Telegram kamu, pisah koma jika lebih dari satu)"
        )
    if problems:
        raise RuntimeError(
            "Konfigurasi belum lengkap:\n- " + "\n- ".join(problems)
        )
