"""
image_utils.py
===============
Helper kecil untuk membuat versi "preview" (resize + kompres JPEG) dari
gambar hasil colorize, supaya bisa langsung dikirim sebagai foto di
Telegram tanpa menunggu PDF final selesai digabung.

Gambar asli (PNG resolusi penuh) tetap dipakai utuh untuk penggabungan
PDF di akhir — fungsi di sini HANYA untuk preview yang dikirim selama
proses berjalan.
"""

from __future__ import annotations

import io
from pathlib import Path

from PIL import Image


def make_preview_bytes(image_path: Path, max_dim: int = 1280, quality: int = 85) -> bytes:
    """
    Buka gambar, resize jika sisi terpanjangnya > max_dim, lalu encode
    sebagai JPEG dan kembalikan sebagai bytes (siap dikirim via
    bot.send_photo tanpa perlu file sementara).
    """
    img = Image.open(image_path)
    if img.mode != "RGB":
        img = img.convert("RGB")

    w, h = img.size
    longest = max(w, h)
    if longest > max_dim:
        ratio = max_dim / longest
        new_size = (max(1, int(w * ratio)), max(1, int(h * ratio)))
        img = img.resize(new_size, Image.LANCZOS)

    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=quality, optimize=True)
    return buf.getvalue()
