# Comic Colorizer Telegram Bot

Bot Telegram untuk mewarnai komik PDF (hitam-putih) memakai AI colorizer
pihak ketiga, lewat **automasi browser asli (Playwright + Chromium)** —
**BUKAN API**. Tiap halaman komik di-upload satu per satu ke website
pilihanmu seperti seorang manusia membukanya di browser, hasilnya diunduh,
lalu semua halaman digabung lagi jadi satu PDF dan dikirim balik ke kamu.

---

## Daftar isi

1. [Fitur](#fitur)
2. [⚠️ Batasan penting — baca dulu](#-batasan-penting--baca-dulu)
3. [Struktur project](#struktur-project)
4. [Instalasi di VPS (step by step)](#instalasi-di-vps-step-by-step)
5. [Konfigurasi (.env)](#konfigurasi-env)
6. [Cara pakai bot](#cara-pakai-bot)
7. [Troubleshooting: selector berubah / bot gagal](#troubleshooting-selector-berubah--bot-gagal)
8. [Mengaktifkan Style2Paints v1/v2/v3](#mengaktifkan-style2paints-v1v2v3)
9. [Login / cookies untuk akun berbayar](#login--cookies-untuk-akun-berbayar)
10. [Testing tanpa Telegram (opsional)](#testing-tanpa-telegram-opsional)
11. [Etika & legalitas automasi](#etika--legalitas-automasi)

---

## Fitur

- **Input fleksibel**:
  - Kirim PDF langsung -> bot otomatis pecah jadi halaman & tampilkan menu.
  - Kirim PDF **atau foto/gambar**, lalu reply pesan itu dengan `/colorize`
    (cocok untuk 1 halaman tunggal, hasil dikirim balik sebagai gambar).
- **3 pilihan AI colorizer**:
  1. **Palette.fm** — daftar filter diambil **langsung dari website** dan
     ditampilkan sebagai tombol di Telegram.
  2. **Style2Paints** — pilih versi v1 / v2 / v3 / v4 / v4.5 (lihat batasan).
  3. **DeepAI Colorizer**.
- **Rolling preview** — begitu halaman N selesai di-colorize, fotonya
  langsung dikirim ke chat, sementara bot lanjut memproses halaman N+1.
- **Auto-split PDF** — jika hasil akhir > 49MB (limit Telegram bot),
  otomatis dipecah jadi `hasil_colorized_part1.pdf`, `part2.pdf`, dst,
  supaya **semua halaman tetap terkirim, tidak ada yang hilang/terpotong**.
- **Fallback aman** — kalau 1 halaman gagal diproses (setelah 2x percobaan),
  halaman ASLI (belum diwarnai) tetap dimasukkan ke PDF supaya hasilnya
  tetap lengkap, dan kamu diberi tahu halaman mana yang gagal.
- **Privat** — hanya user ID di `ALLOWED_USER_IDS` yang bisa pakai bot.
- `/status` dan `/cancel` untuk memantau/menghentikan job yang berjalan.

---

## ⚠️ Batasan penting — baca dulu

Bot ini mengotomasi website PIHAK KETIGA lewat browser. Artinya ada
beberapa keterbatasan yang **bukan bug**, tapi karakteristik bawaan
masing-masing website:

### 🎨 Palette.fm
Tanpa login / akun berbayar, hasil yang bisa diambil bot biasanya:
- mengandung **watermark**
- **resolusi dibatasi** (sekitar 500x500px untuk preview gratis)

Untuk komik, ini bisa cukup mengurangi kualitas. Kalau kamu punya akun
berbayar Palette.fm, lihat [Login / Cookies](#login--cookies-untuk-akun-berbayar)
agar bot login otomatis dan mendapat hasil resolusi penuh.

### 🖌 Style2Paints
| Versi | Status |
|---|---|
| **v4 & v4.5** | ❌ **HANYA aplikasi desktop Windows (.exe)**, didownload manual dari Google Drive/Baidu oleh pembuatnya. **Tidak ada versi web** -> tidak bisa dipakai di VPS Linux. |
| **v3** | ⚠️ Repo resminya menyebut versi ini "hanya untuk programmer" (perlu jalankan server sendiri dari source code). Default nonaktif. |
| **v1/v2** | ⚠️ Versi publiknya = **PaintsChainer** (Preferred Networks). Status online-nya **tidak dipastikan** masih aktif. Default nonaktif. |

Bot tetap menampilkan ke-5 versi di menu (transparan ke kamu):
- Pilih v4/v4.5 -> bot menjelaskan kenapa tidak didukung (tidak memproses).
- Pilih v1/v2/v3 yang belum dikonfigurasi -> bot menjelaskan cara
  mengaktifkannya kalau kamu menemukan URL yang masih hidup
  (lihat [bagian ini](#mengaktifkan-style2paints-v1v2v3)).

### 🤖 DeepAI Colorizer
Pemakaian gratis lewat web UI (tanpa login) biasanya **dibatasi** —
beberapa kali pakai per IP/sesi, lalu muncul permintaan login. Kalau bot
melaporkan *"diminta login / kuota habis"*, berarti limit gratis VPS kamu
sudah tercapai untuk saat itu.

### ⏱ Umum: PROSES BISA LAMA
Tiap halaman = 1 sesi browser penuh (buka situs, upload, **tunggu AI
selesai**, download). Tergantung kecepatan website target, ini bisa
**puluhan detik sampai beberapa menit PER HALAMAN**. Komik 20 halaman bisa
butuh 20-60+ menit total. Ini NORMAL — bukan bot hang. Gunakan `/status`
untuk cek progres, dan kamu akan dapat preview tiap halaman selesai.

### 🔧 Selector CSS bisa berubah
Cara bot "mengklik" tombol/elemen di website (CSS selector) disimpan di
`selectors.yaml`, **dipisah dari kode** supaya mudah diperbaiki kalau
tampilan website di-update sewaktu-waktu. Lihat
[Troubleshooting](#troubleshooting-selector-berubah--bot-gagal).

---

## Struktur project

```
comic-colorizer-bot/
├── bot.py                  # Bot Telegram utama (menu, orkestrasi job)
├── config.py               # Load konfigurasi dari .env
├── pdf_utils.py             # PDF <-> gambar per halaman, split PDF
├── image_utils.py            # Resize/kompres gambar utk preview
├── job_manager.py             # State per-chat (in-memory)
├── selectors.yaml              # CSS selector & URL tiap website (EDIT INI
│                                  kalau bot gagal karena tampilan web berubah)
├── colorizers/
│   ├── browser_manager.py        # Kelola 1 instance Chromium
│   ├── web_helpers.py             # upload, tunggu hasil, download, screenshot
│   ├── errors.py                   # Exception khusus
│   ├── generic.py                   # Flow umum: upload->submit->tunggu->download
│   ├── palette_fm.py                 # + logika daftar & pilih filter
│   ├── style2paints.py                # Pesan & guard utk v1-v4.5
│   └── factory.py                      # Bikin instance colorizer dari selectors.yaml
├── tools/
│   └── inspect_site.py     # Bantu cari selector baru kalau web berubah
├── mock_site/               # Halaman HTML tiruan utk testing offline
│   ├── palette_fm.html
│   └── deepai.html
├── test_pipeline.py           # Test automasi vs mock_site (lihat §10)
├── test_run_job_logic.py        # Test logika progress/preview/fallback/split
├── requirements.txt
├── .env.example
├── install.sh                # Installer otomatis (lihat §4)
└── comic-colorizer-bot.service  # Unit systemd
```

---

## Instalasi di VPS (step by step)

Asumsi: VPS DigitalOcean **Ubuntu 22.04/24.04**, akses root via SSH.
Semua perintah dijalankan **langsung di console VPS** (bukan panel
Pterodactyl).

### 1. Login ke VPS

```bash
ssh root@ALAMAT_IP_VPS
```

### 2. Update sistem (opsional tapi disarankan)

```bash
apt update && apt upgrade -y
apt install -y unzip
```

### 3. Upload file project ke VPS

Download dulu folder/zip project ini ke **komputer lokal** kamu, lalu
upload ke VPS. Dari **terminal komputer lokal** (bukan VPS):

```bash
scp comic-colorizer-bot.zip root@ALAMAT_IP_VPS:/root/
```

> Di Windows, bisa pakai WinSCP / FileZilla (drag & drop ke folder
> `/root/`), atau `scp` lewat WSL/PowerShell.

### 4. Extract & masuk folder project (di VPS)

```bash
cd /root
unzip comic-colorizer-bot.zip
cd comic-colorizer-bot
```

### 5. Jalankan installer

```bash
bash install.sh
```

Script ini otomatis akan:
- install `python3`, `venv`, `pip`
- bikin virtual environment `./venv`
- install semua dependency Python (`requirements.txt`)
- install Playwright **+ Chromium + dependency sistemnya** (`playwright
  install --with-deps chromium`) — ini langkah paling lama, mengunduh
  browser (~100-300MB)
- bikin file `.env` dari `.env.example`
- (opsional, disarankan **Y**) daftarkan bot sebagai **systemd service**
  supaya jalan terus & auto-restart kalau crash/reboot

### 6. Buat bot Telegram & ambil token

1. Di Telegram, chat ke **@BotFather** -> `/newbot` -> ikuti instruksi ->
   kamu akan dapat **token** seperti `123456789:ABCdefGhIJKlmnoPQRstuVWxyz`.
2. Cek **User ID** kamu sendiri: chat ke **@userinfobot** -> dia balas ID
   (angka) kamu.

### 7. Isi konfigurasi

```bash
nano .env
```

Isi minimal:

```ini
TELEGRAM_BOT_TOKEN=123456789:ABCdefGhIJKlmnoPQRstuVWxyz
ALLOWED_USER_IDS=111222333
```

Simpan: `Ctrl+O` lalu `Enter`, keluar: `Ctrl+X`.

### 8. Jalankan bot

**Jika tadi pilih systemd (langkah 5):**

```bash
sudo systemctl enable --now comic-colorizer-bot
sudo journalctl -u comic-colorizer-bot -f   # lihat log realtime, Ctrl+C utk keluar
```

**Jika manual (tanpa systemd)** — gunakan `tmux`/`screen` agar tetap
jalan setelah SSH ditutup:

```bash
apt install -y tmux
tmux new -s bot
source venv/bin/activate
python3 bot.py
# Lepas sesi tmux tanpa stop bot: tekan Ctrl+B lalu D
# Masuk lagi nanti: tmux attach -t bot
```

### 9. Tes di Telegram

Chat ke bot kamu -> `/start`. Kirim 1 file PDF komik -> **reply** pesan
itu dengan `/colorize` -> pilih metode -> tunggu hasilnya.

---

## Konfigurasi (.env)

| Variabel | Default | Keterangan |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | *(wajib)* | Token dari @BotFather |
| `ALLOWED_USER_IDS` | *(wajib)* | User ID Telegram yang boleh pakai bot, pisah koma |
| `PDF_RENDER_DPI` | `160` | Resolusi render halaman PDF -> PNG |
| `BROWSER_HEADLESS` | `true` | `false` hanya kalau VPS punya GUI/X server |
| `BROWSER_TIMEOUT_MS` | `180000` | Timeout (3 menit) menunggu 1 halaman selesai diproses website AI |
| `CONCURRENCY` | `1` | Halaman diproses bersamaan. **1 = direkomendasikan** (stabil, sopan ke server target) |
| `WORKDIR` | `./data` | Folder file sementara |
| `MAX_TELEGRAM_FILE_MB` | `49` | Batas ukuran/file sebelum PDF dipecah jadi beberapa bagian |
| `SEND_PAGE_PREVIEWS` | `true` | Kirim foto preview tiap halaman selesai |
| `PREVIEW_MAX_DIM` | `1280` | Resolusi maksimum foto preview (px) |

Setelah ubah `.env`, restart bot:

```bash
sudo systemctl restart comic-colorizer-bot
```

---

## Cara pakai bot

Semua proses **selalu dimulai lewat `/colorize` sebagai reply** — kirim
file dulu, baru reply dengan command. Ini berlaku untuk PDF maupun
foto/gambar, supaya bot tidak otomatis memproses file yang sekadar dikirim
(misal kalau kamu cuma mau simpan file di chat tanpa langsung diproses).

### Langkah-langkah

1. Kirim file **PDF** (sebagai File/Dokumen) **atau foto/gambar** ke bot.
   Bot hanya membalas konfirmasi penerimaan — **belum ada proses apapun**
   (PDF belum dipecah jadi halaman, dst).
2. **Reply** pesan file tersebut dengan `/colorize`.
3. Bot memecah PDF jadi halaman (atau menyiapkan 1 gambar), lalu
   menampilkan menu metode:
   - 🎨 Palette.fm (pilih filter)
   - 🖌 Style2Paints (v1 - v4.5)
   - 🤖 DeepAI Colorizer
4. **Palette.fm** -> bot mengambil daftar filter LANGSUNG dari website
   (perlu beberapa detik) -> pilih salah satu dari tombol yang muncul.
5. **Style2Paints** -> pilih versi. v4/v4.5 akan dijelaskan kenapa tidak
   bisa; v1/v2/v3 default akan dijelaskan cara mengaktifkan.
6. Konfirmasi "✅ Mulai proses".
7. Bot memproses tiap halaman satu-satu:
   - pesan progres: `🎨 Memproses halaman X/N...`
   - tiap selesai -> foto preview halaman itu dikirim
8. Setelah semua selesai:
   - **Input PDF** -> hasil digabung jadi PDF dan dikirim (atau beberapa
     bagian jika ukurannya besar).
   - **Input 1 foto/gambar** -> hasil dikirim balik sebagai **gambar**
     (bukan dibungkus PDF).

> 💡 Untuk gambar, kirim sebagai **File/Dokumen** (bukan "Foto") supaya
> Telegram tidak mengompresnya sebelum diproses.

### Perintah

| Command | Fungsi |
|---|---|
| `/start` | Info & cara pakai |
| `/colorize` | Mulai colorize (reply ke PDF/foto) |
| `/status` | Lihat progres job yang sedang berjalan |
| `/cancel` | Batalkan job yang berjalan/menunggu |

Selama proses berjalan, ada tombol inline **🛑 Batalkan proses** di pesan
progres.

---

## Troubleshooting: selector berubah / bot gagal

Kalau bot membalas error seperti:

```
❌ Gagal mengambil daftar filter dari Palette.fm:
[palette_fm] Gagal mengambil daftar filter: Hasil gambar tidak muncul ...
```

artinya **tampilan website berubah** dan CSS selector di `selectors.yaml`
sudah tidak cocok. Cara perbaiki:

### 1. Lihat screenshot debug

Setiap kali terjadi error, bot menyimpan screenshot halaman saat itu ke:

```
data/debug_screenshots/<nama>_<timestamp>.png
```

Download (scp) dan lihat — apakah ada popup cookie/consent yang menghalangi?
Apakah tombol/galeri pindah posisi? Apakah halaman gagal load sama sekali?

### 2. Jalankan `inspect_site.py`

Tool ini membuka halaman target, **mengupload gambar contoh** (opsional),
**mengklik elemen** (opsional), lalu mencetak daftar selector yang
ditemukan:

```bash
source venv/bin/activate

# Lihat elemen di halaman awal
python3 tools/inspect_site.py "https://palette.fm/color/filters"

# Upload gambar dulu -> lihat galeri filter yang muncul
python3 tools/inspect_site.py "https://palette.fm/color/filters" \
    --upload data/jobs/<folder_job_terakhir>/pages/page_0001.png

# Upload + klik salah satu filter -> lihat elemen hasil
python3 tools/inspect_site.py "https://palette.fm/color/filters" \
    --upload data/jobs/<folder_job_terakhir>/pages/page_0001.png \
    --click ".filter-card"
```

Outputnya berupa daftar `<input type="file">`, elemen `data-*` (kandidat
galeri filter), tombol/link, dan `<img>` beserta selector CSS-nya — plus
screenshot full-page.

### 3. Edit `selectors.yaml`

Update bagian yang sesuai (`palette_fm`, `deepai`, atau
`style2paints.vX`) dengan selector baru dari hasil `inspect_site.py`.
Tidak perlu restart bot — `selectors.yaml` dibaca ulang setiap kali
ada job baru.

**Tips memilih selector** (urutan preferensi):
1. `#id-unik` — paling stabil kalau ada.
2. `button:has-text('Run Model')` / `text=Download` — berbasis teks,
   tahan terhadap perubahan class CSS acak (umum di website modern,
   misal `class="btn_a8x91k"` yang berubah tiap deploy).
3. `.nama-class` — kalau class-nya deskriptif & stabil (`.filter-card`,
   bukan `.css-1a2b3c`).

---

## Mengaktifkan Style2Paints v1/v2/v3

Default semua nonaktif (`enabled: false`) karena status online-nya tidak
dipastikan. Kalau kamu cek dari VPS dan ternyata **masih hidup**:

1. Buka `selectors.yaml`, cari `style2paints.v1` (atau v2/v3).
2. Set `enabled: true` dan isi `url`.
3. Jalankan `inspect_site.py` ke URL itu (lihat §7) untuk dapat selector
   `file_input_selector`, `submit_button_selector`, dan
   `result_image_selector`.
4. Isi ketiga selector tersebut.
5. Coba lewat bot: `/colorize` -> pilih Style2Paints -> versi yang
   diaktifkan tadi.

`v4` dan `v4.5` **tidak bisa** diaktifkan dengan cara ini — keduanya
murni aplikasi `.exe` Windows tanpa versi web sama sekali.

---

## Login / cookies untuk akun berbayar

Beberapa website (terutama Palette.fm) memberi hasil lebih baik (resolusi
penuh, tanpa watermark) kalau login. Bot bisa "ikut login" dengan cara
load cookies dari sesi browser kamu:

1. Di **komputer/laptop** (bukan VPS), login ke website tersebut di
   Chrome/Edge.
2. Pakai extension seperti **"Get cookies.txt" / "Cookie-Editor"** untuk
   export cookies domain itu ke format JSON
   (`[{"name":..., "value":..., "domain":..., "path":..., ...}, ...]`).
3. Upload file JSON itu ke VPS, simpan misalnya di
   `comic-colorizer-bot/cookies/palette_fm.json`.
4. Di `selectors.yaml`, isi:
   ```yaml
   palette_fm:
     cookies_file: "cookies/palette_fm.json"
   ```

> ⚠️ File cookies = "kunci" akun kamu. Jangan share/commit ke git, dan
> pastikan permission filenya tidak bisa dibaca user lain (`chmod 600`).

---

## Testing tanpa Telegram (opsional)

Project ini menyertakan **mock website lokal** (`mock_site/`) yang
mensimulasikan flow upload->proses->hasil seperti Palette.fm & DeepAI,
supaya kamu bisa memastikan **Playwright + Chromium di VPS kamu berfungsi**
sebelum mencoba ke website asli:

```bash
source venv/bin/activate

# Jalankan mock server (terminal 1 / tmux pane 1)
cd mock_site && python3 -m http.server 8123 --bind 127.0.0.1

# Jalankan test (terminal 2 / tmux pane 2)
cd ..
python3 test_pipeline.py        # test upload, pilih filter, ambil hasil, error handling
python3 test_run_job_logic.py   # test progress, preview, retry/fallback, split-PDF
```

Kalau semua test ini lulus (`SEMUA TEST ... LULUS ✅`), berarti instalasi
browser/Playwright di VPS kamu sudah benar — kalau ada masalah selanjutnya
saat dipakai ke palette.fm/deepai/dll, kemungkinan besar memang karena
selector perlu disesuaikan (lihat Troubleshooting), bukan masalah instalasi.

---

## Etika & legalitas automasi

Bot ini mengakses website pihak ketiga **dengan cara yang sama seperti
pengguna biasa di browser** (bukan exploit/bypass keamanan), dengan
`CONCURRENCY=1` secara default agar tidak membebani server target. Tetap
perhatikan:

- Baca **Syarat & Ketentuan (ToS)** masing-masing website — beberapa
  platform melarang automasi untuk pemakaian komersial/skala besar.
- Gunakan untuk **keperluan pribadi** (mewarnai koleksi komik sendiri),
  bukan untuk layanan komersial ke pihak lain.
- Jangan menaikkan `CONCURRENCY` terlalu tinggi — selain berisiko
  diblokir, ini juga membebani server gratis milik orang lain.
