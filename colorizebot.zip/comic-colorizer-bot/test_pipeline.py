"""
test_pipeline.py
=================
Script verifikasi (BUKAN bagian dari bot) untuk memastikan modul-modul
colorizers/* benar-benar bisa: buka browser, upload gambar, baca daftar
filter, klik filter, tunggu hasil, dan download hasil — menggunakan
mock website lokal (mock_site/) sebagai pengganti palette.fm/deepai
yang tidak bisa diakses dari sandbox ini (tanpa internet).

Jalankan: python3 test_pipeline.py
"""

from __future__ import annotations

import asyncio
import shutil
from pathlib import Path

from PIL import Image

import config
from colorizers.browser_manager import browser_manager
from colorizers.errors import NotSupportedError, SelectorNotFoundError
from colorizers.generic import GenericColorizer
from colorizers.palette_fm import PaletteFMColorizer
from colorizers.style2paints import Style2PaintsColorizer

BASE = Path(__file__).resolve().parent
MOCK_URL = "http://127.0.0.1:8123"
SAMPLE = BASE / "test" / "pages" / "page_0001.png"
OUT_DIR = BASE / "test" / "colorized"


def avg_color(path: Path) -> tuple[float, float, float]:
    img = Image.open(path).convert("RGB")
    px = list(img.getdata())
    n = len(px)
    r = sum(p[0] for p in px) / n
    g = sum(p[1] for p in px) / n
    b = sum(p[2] for p in px) / n
    return (r, g, b)


async def test_palette_fm() -> None:
    print("\n=== Test PaletteFMColorizer (mock) ===")
    cfg = {
        "url": f"{MOCK_URL}/palette_fm.html",
        "file_input_selector": "input[type='file']",
        "upload_trigger_selector": "",
        "upload_ready_selector": "",
        "wait_after_upload_ms": 500,
        "filter_item_selector": "[data-filter-name], .filter-card, .filter-thumb",
        "filter_name_source": "text",
        "wait_after_filter_click_ms": 1200,
        "result_image_selector": "img.result, .preview-after img, .after img",
        "cookies_file": "",
    }
    colorizer = PaletteFMColorizer(cfg)

    names = await colorizer.list_filters(SAMPLE)
    print("Filter ditemukan:", names)
    assert names == ["Vintage", "Vibrant", "Noir", "Sepia Warm", "Cool Blue"], names

    out_path = OUT_DIR / "palette_vintage.png"
    await colorizer.colorize(SAMPLE, out_path, option="Vintage")
    assert out_path.exists()
    src_avg = avg_color(SAMPLE)
    out_avg = avg_color(out_path)
    print(f"Avg color asli={src_avg}  hasil(Vintage)={out_avg}")
    assert out_avg != src_avg, "Hasil harus berbeda dari gambar asli (filter Vintage)"

    # filter lain -> hasil harus beda lagi (memastikan klik filter yg BENAR)
    out_path2 = OUT_DIR / "palette_noir.png"
    await colorizer.colorize(SAMPLE, out_path2, option="Noir")
    out_avg2 = avg_color(out_path2)
    print(f"Avg color hasil(Noir)={out_avg2}")
    assert out_avg2 != out_avg, "Filter Vintage vs Noir harus beda hasil"

    print("PaletteFMColorizer: OK")


async def test_deepai() -> None:
    print("\n=== Test GenericColorizer sebagai DeepAI (mock) ===")
    cfg = {
        "url": f"{MOCK_URL}/deepai.html",
        "file_input_selector": "input[type='file']",
        "upload_trigger_selector": "",
        "wait_after_upload_ms": 300,
        "submit_button_selector": "button:has-text('Run Model')",
        "loading_indicator_selector": ".loader",
        "result_image_selector": ".try-it-result-area img, #colorizer-output img, .output-image img",
        "quota_blocked_selector": "",
        "cookies_file": "",
    }
    colorizer = GenericColorizer(cfg)
    colorizer.name = "deepai"

    out_path = OUT_DIR / "deepai_result.png"
    await colorizer.colorize(SAMPLE, out_path)
    assert out_path.exists()
    src_avg = avg_color(SAMPLE)
    out_avg = avg_color(out_path)
    print(f"Avg color asli={src_avg}  hasil(DeepAI)={out_avg}")
    assert out_avg != src_avg
    print("GenericColorizer (DeepAI mock): OK")


async def test_error_handling() -> None:
    print("\n=== Test error handling (selector salah) ===")
    cfg = {
        "url": f"{MOCK_URL}/deepai.html",
        "file_input_selector": "input[type='file']",
        "upload_trigger_selector": "",
        "wait_after_upload_ms": 300,
        "submit_button_selector": "button:has-text('Run Model')",
        "loading_indicator_selector": ".loader",
        # selector SENGAJA salah:
        "result_image_selector": "#tidak-ada-elemen-ini",
        "quota_blocked_selector": "",
        "cookies_file": "",
    }
    colorizer = GenericColorizer(cfg)
    colorizer.name = "deepai_broken"
    out_path = OUT_DIR / "should_not_exist.png"

    try:
        await colorizer.colorize(SAMPLE, out_path)
        raise AssertionError("Harus raise SelectorNotFoundError!")
    except SelectorNotFoundError as e:
        print("OK, error tertangkap dgn benar:", str(e)[:100], "...")

    # pastikan debug screenshot dibuat
    shots = list((BASE / "data" / "debug_screenshots").glob("deepai_broken_*.png"))
    print("Debug screenshot dibuat:", len(shots) > 0, shots)
    assert shots, "Screenshot debug harus tersimpan saat error"


async def test_style2paints_messages() -> None:
    print("\n=== Test Style2Paints v4/v4.5/v1 (tanpa browser) ===")

    cfg_v45 = {"label": "Style2Paints v4.5", "enabled": False, "url": ""}
    c = Style2PaintsColorizer(cfg_v45, "v45")
    try:
        await c.colorize(SAMPLE, OUT_DIR / "x.png")
        raise AssertionError("v4.5 harus NotSupportedError")
    except NotSupportedError as e:
        assert "APLIKASI DESKTOP WINDOWS" in str(e)
        print("v4.5 ->", str(e)[:70], "...")

    cfg_v1 = {"label": "Style2Paints v1 (PaintsChainer)", "enabled": False, "url": ""}
    c = Style2PaintsColorizer(cfg_v1, "v1")
    try:
        await c.colorize(SAMPLE, OUT_DIR / "x.png")
        raise AssertionError("v1 (disabled) harus NotSupportedError")
    except NotSupportedError as e:
        assert "belum aktif" in str(e)
        print("v1 (disabled) ->", str(e)[:70], "...")

    print("Style2Paints message checks: OK")


async def main() -> None:
    # Mock site merespon < 2 detik -> timeout kecil supaya skenario GAGAL
    # (test_error_handling) juga cepat, tidak menunggu default 180 detik.
    config.BROWSER_TIMEOUT_MS = 8000

    shutil.rmtree(OUT_DIR, ignore_errors=True)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    SAMPLE.parent.mkdir(parents=True, exist_ok=True)

    # Buat gambar contoh (grayscale gradient 400x500) kalau belum ada,
    # supaya script ini self-contained / bisa langsung dijalankan user.
    if not SAMPLE.exists():
        img = Image.new("RGB", (400, 500), (255, 255, 255))
        px = img.load()
        for y in range(500):
            g = int(255 * (y / 500))
            for x in range(400):
                px[x, y] = (g, g, g)
        img.save(SAMPLE)

    await browser_manager.start()
    try:
        await test_palette_fm()
        await test_deepai()
        await test_error_handling()
    finally:
        await browser_manager.stop()

    await test_style2paints_messages()

    print("\nSEMUA TEST PIPELINE LULUS ✅")


if __name__ == "__main__":
    asyncio.run(main())
