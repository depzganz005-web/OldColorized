"""
test_pipeline.py
=================
Script verifikasi (BUKAN bagian dari bot) untuk memastikan modul-modul
colorizers/* benar-benar bisa: buka browser, upload gambar, baca daftar
filter (skip "ORIGINAL"), klik filter / klik "Generate", deteksi hasil
baru via diffing <img src>, KLIK TOMBOL DOWNLOAD & tangkap file —
menggunakan mock website lokal (mock_site/) sebagai pengganti
palette.fm/deepai.org yang tidak bisa diakses dari sandbox ini (tanpa
internet).

PENTING: konfigurasi dipakai LANGSUNG dari selectors.yaml (hanya `url`
yang diarahkan ke mock & beberapa nilai wait_*_ms dipercepat) — jadi
test ini juga jadi pengaman: kalau selectors.yaml diedit dan jadi tidak
valid (selector typo dll), test ini akan gagal terhadap mock SEBELUM
dicoba ke website asli.

Jalankan: python3 test_pipeline.py
"""

from __future__ import annotations

import asyncio
import shutil
from pathlib import Path

import yaml
from PIL import Image, ImageChops

import config
from colorizers.browser_manager import browser_manager
from colorizers.errors import NotSupportedError, SelectorNotFoundError
from colorizers.generic import GenericColorizer
from colorizers.palette_fm import PaletteFMColorizer
from colorizers.style2paints import Style2PaintsColorizer
from colorizers import web_helpers as wh

BASE = Path(__file__).resolve().parent
MOCK_URL = "http://127.0.0.1:8123"
SAMPLE = BASE / "test" / "pages" / "page_0001.png"
OUT_DIR = BASE / "test" / "colorized"


def load_real_cfg(section: str) -> dict:
    """Ambil config ASLI dari selectors.yaml (deep-copy via yaml reload)."""
    with open(config.SELECTORS_FILE, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return dict(data[section])


def images_differ(path_a: Path, path_b: Path) -> bool:
    a = Image.open(path_a).convert("RGB")
    b = Image.open(path_b).convert("RGB")
    if a.size != b.size:
        return True
    diff = ImageChops.difference(a, b)
    return diff.getbbox() is not None


async def test_palette_fm() -> dict:
    print("\n=== Test PaletteFMColorizer (mock, config dari selectors.yaml) ===")
    cfg = load_real_cfg("palette_fm")
    cfg["url"] = f"{MOCK_URL}/palette_fm.html"
    # percepat hanya waktu tunggu, selector/skip_filter_names/dll TETAP asli
    cfg["wait_after_upload_ms"] = 500
    cfg["wait_after_filter_click_ms"] = 300

    colorizer = PaletteFMColorizer(cfg)

    names = await colorizer.list_filters(SAMPLE)
    print("Filter ditemukan:", names)
    assert "Original" not in names and "ORIGINAL" not in names, (
        f"'Original'/'ORIGINAL' harus di-skip (skip_filter_names), tapi ada di: {names}"
    )
    assert names == ["Vintage", "Vibrant", "Noir", "Sepia Warm", "Cool Blue"], names

    out_vintage = OUT_DIR / "palette_vintage.png"
    await colorizer.colorize(SAMPLE, out_vintage, option="Vintage")
    assert out_vintage.exists() and out_vintage.stat().st_size > 0
    assert images_differ(SAMPLE, out_vintage), "Hasil Vintage harus beda dari gambar asli"

    out_noir = OUT_DIR / "palette_noir.png"
    await colorizer.colorize(SAMPLE, out_noir, option="Noir")
    assert images_differ(out_vintage, out_noir), "Filter Vintage vs Noir harus beda hasil"

    print("PaletteFMColorizer (skip ORIGINAL, pilih filter, klik Download): OK")
    return {"cfg": cfg, "out_vintage": out_vintage}


async def test_palette_download_button_is_used(cfg: dict) -> None:
    """
    Pastikan hasil BENAR-BENAR datang dari KLIK TOMBOL "Download"
    (bukan cuma fallback <img src>) — bandingkan byte-for-byte dgn
    src <img> hasil pada saat tombol itu diklik.
    """
    print("\n=== Test: hasil Palette.fm identik dgn klik tombol Download ===")
    context = await browser_manager.new_context()
    page = await context.new_page()
    try:
        await page.goto(cfg["url"], wait_until="domcontentloaded")
        await wh.upload_image(page, SAMPLE, cfg["file_input_selector"])
        await page.wait_for_timeout(cfg["wait_after_upload_ms"])

        before = await wh.snapshot_image_srcs(page, cfg["result_image_selector"])

        items = await page.query_selector_all(cfg["filter_item_selector"])
        target = None
        for item in items:
            if (await item.inner_text()).strip() == "Sepia Warm":
                target = item
                break
        assert target is not None, "Filter 'Sepia Warm' tidak ditemukan di mock"
        await target.click()

        el, src = await wh.wait_for_new_image(page, before, cfg["result_image_selector"])
        assert src.startswith("data:image"), src

        import base64
        expected_bytes = base64.b64decode(src.split(",", 1)[1])

        out_path = OUT_DIR / "palette_via_download_button.png"
        ok = await wh.try_download_via_button(
            page, cfg["download_button_selector"], out_path, timeout_ms=cfg["download_timeout_ms"]
        )
        assert ok, "try_download_via_button harus berhasil (tombol 'Download' di mock memicu <a download>)"
        assert out_path.read_bytes() == expected_bytes, (
            "Isi file hasil klik 'Download' harus identik dgn src <img> hasil"
        )
        print("Klik tombol 'Download' -> file tersimpan & identik dgn <img> hasil: OK")
    finally:
        await context.close()


async def test_deepai() -> dict:
    print("\n=== Test GenericColorizer sebagai DeepAI (mock, config dari selectors.yaml) ===")
    cfg = load_real_cfg("deepai")
    cfg["url"] = f"{MOCK_URL}/deepai.html"
    cfg["wait_after_upload_ms"] = 300

    colorizer = GenericColorizer(cfg)
    colorizer.name = "deepai"

    out_path = OUT_DIR / "deepai_result.png"
    await colorizer.colorize(SAMPLE, out_path)
    assert out_path.exists() and out_path.stat().st_size > 0
    assert images_differ(SAMPLE, out_path), "Hasil DeepAI harus beda dari gambar asli (ada tint hijau)"

    print("GenericColorizer (DeepAI mock, tombol 'Generate'->'Generating...', img baru via diffing): OK")
    return {"cfg": cfg}


async def test_deepai_with_download_button(cfg: dict) -> None:
    """
    `download_button_selector` DeepAI default-nya kosong (lihat
    selectors.yaml). Tes ini memverifikasi bahwa JIKA seseorang mengisi
    selector tombol download ikon, jalur try_download_via_button() juga
    berfungsi untuk DeepAI (bukan hanya Palette.fm).
    """
    print("\n=== Test DeepAI dgn download_button_selector terisi (opsional) ===")
    cfg2 = dict(cfg)
    cfg2["download_button_selector"] = 'button[aria-label="Download"]'

    colorizer = GenericColorizer(cfg2)
    colorizer.name = "deepai_dlbtn"
    out_path = OUT_DIR / "deepai_via_download_btn.png"
    await colorizer.colorize(SAMPLE, out_path)
    assert out_path.exists() and out_path.stat().st_size > 0
    print("DeepAI + download_button_selector terisi -> klik tombol icon berhasil: OK")


async def test_error_handling() -> None:
    print("\n=== Test error handling (hasil baru tidak pernah muncul) ===")
    cfg = load_real_cfg("deepai")
    cfg["url"] = f"{MOCK_URL}/deepai.html"
    cfg["wait_after_upload_ms"] = 300
    # SENGAJA: scope ke gambar statis yg src-nya TIDAK PERNAH berubah,
    # jadi wait_for_new_image tidak akan pernah menemukan "src baru".
    cfg["result_image_selector"] = "#staticExample"

    colorizer = GenericColorizer(cfg)
    colorizer.name = "deepai_broken"
    out_path = OUT_DIR / "should_not_exist.png"

    try:
        await colorizer.colorize(SAMPLE, out_path)
        raise AssertionError("Harus raise SelectorNotFoundError!")
    except SelectorNotFoundError as e:
        print("OK, error tertangkap dgn benar:", str(e)[:100], "...")

    shots = list((BASE / "data" / "debug_screenshots").glob("deepai_broken_*.png"))
    print("Debug screenshot dibuat:", len(shots) > 0, shots)
    assert shots, "Screenshot debug harus tersimpan saat error"


async def test_style2paints_messages() -> None:
    print("\n=== Test Style2Paints v4/v4.5/v1 (tanpa browser) ===")

    cfg_v45 = {"label": "Style2Paints v4.5", "enabled": False, "url": ""}
    c = Style2PaintsColorizer(cfg_v45, "v45")
    try:
        await c.colorize(SAMPLE, OUT_DIR / "x.png")
        raise AssertionError("v4.5 harus NotSupportedError")
    except NotSupportedError as e:
        assert "APLIKASI DESKTOP WINDOWS" in str(e)
        print("v4.5 ->", str(e)[:70], "...")

    cfg_v1 = {"label": "Style2Paints v1 (PaintsChainer)", "enabled": False, "url": ""}
    c = Style2PaintsColorizer(cfg_v1, "v1")
    try:
        await c.colorize(SAMPLE, OUT_DIR / "x.png")
        raise AssertionError("v1 (disabled) harus NotSupportedError")
    except NotSupportedError as e:
        assert "belum aktif" in str(e)
        print("v1 (disabled) ->", str(e)[:70], "...")

    print("Style2Paints message checks: OK")


async def main() -> None:
    # Mock site merespon < 2 detik -> timeout kecil supaya skenario GAGAL
    # (test_error_handling) juga cepat, tidak menunggu default 180 detik.
    config.BROWSER_TIMEOUT_MS = 8000

    shutil.rmtree(OUT_DIR, ignore_errors=True)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    SAMPLE.parent.mkdir(parents=True, exist_ok=True)

    # Buat gambar contoh (grayscale gradient 400x500) kalau belum ada,
    # supaya script ini self-contained / bisa langsung dijalankan user.
    if not SAMPLE.exists():
        img = Image.new("RGB", (400, 500), (255, 255, 255))
        px = img.load()
        for y in range(500):
            g = int(255 * (y / 500))
            for x in range(400):
                px[x, y] = (g, g, g)
        img.save(SAMPLE)

    await browser_manager.start()
    try:
        palette_ctx = await test_palette_fm()
        await test_palette_download_button_is_used(palette_ctx["cfg"])

        deepai_ctx = await test_deepai()
        await test_deepai_with_download_button(deepai_ctx["cfg"])

        await test_error_handling()
    finally:
        await browser_manager.stop()

    await test_style2paints_messages()

    print("\nSEMUA TEST PIPELINE LULUS ✅")


if __name__ == "__main__":
    asyncio.run(main())
