"""
job_manager.py
===============
State management sederhana per-chat, disimpan di memori (dict).

Karena bot ini untuk pemakaian pribadi (dibatasi ALLOWED_USER_IDS) dan
satu chat hanya boleh punya satu job aktif, in-memory dict sudah cukup —
tidak perlu database. Kalau bot di-restart, job yang sedang berjalan
akan hilang (file sementara di WORKDIR/jobs/ tetap ada sampai dibersihkan
manual atau lewat /cancel pada job berikutnya).
"""

from __future__ import annotations

import enum
import shutil
from dataclasses import dataclass, field
from pathlib import Path


class JobStatus(enum.Enum):
    WAITING_METHOD = "menunggu pilihan metode"
    PROCESSING = "sedang diproses"
    DONE = "selesai"


@dataclass
class Job:
    chat_id: int
    job_id: str
    pdf_path: Path
    pages_dir: Path
    colorized_dir: Path
    output_pdf: Path
    page_paths: list[Path] = field(default_factory=list)

    method: str | None = None          # "palette_fm" | "deepai" | "style2paints"
    option: str | None = None          # nama filter (palette_fm) / version key (style2paints)

    status: JobStatus = JobStatus.WAITING_METHOD
    current_page: int = 0
    total_pages: int = 0
    cancel_requested: bool = False

    # True jika sumber input adalah 1 foto/gambar (bukan PDF) -> hasil
    # dikirim balik sebagai gambar, bukan PDF.
    is_single_image: bool = False

    filter_cache: list[str] | None = None  # cache hasil list_filters() Palette.fm


_JOBS: dict[int, Job] = {}


def create_job(chat_id: int, pdf_path: Path, page_paths: list[Path]) -> Job:
    """
    Buat job baru untuk sebuah chat. `pdf_path` diasumsikan berada di
    dalam folder kerja unik (lihat handle_document di bot.py):
        WORKDIR/jobs/<chat_id>_<random>/input.pdf
    sehingga seluruh folder itu bisa dihapus sekaligus saat job selesai.
    """
    job_dir = pdf_path.parent
    job_id = job_dir.name.rsplit("_", 1)[-1]

    colorized_dir = job_dir / "colorized"
    output_pdf = job_dir / "hasil_colorized.pdf"
    colorized_dir.mkdir(parents=True, exist_ok=True)

    job = Job(
        chat_id=chat_id,
        job_id=job_id,
        pdf_path=pdf_path,
        pages_dir=job_dir / "pages",
        colorized_dir=colorized_dir,
        output_pdf=output_pdf,
        page_paths=page_paths,
        total_pages=len(page_paths),
    )
    _JOBS[chat_id] = job
    return job


def get_job(chat_id: int) -> Job | None:
    return _JOBS.get(chat_id)


def clear_job(chat_id: int, remove_files: bool = True) -> None:
    """Hapus job dari memori, opsional sekalian hapus folder kerjanya di disk."""
    job = _JOBS.pop(chat_id, None)
    if job and remove_files:
        shutil.rmtree(job.pdf_path.parent, ignore_errors=True)
