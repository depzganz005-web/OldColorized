"""
preview.py
==========
RollingPreview: kelola SATU pesan foto preview yang DI-EDIT (ganti
gambar + caption) setiap kali halaman baru selesai di-colorize,
daripada mengirim pesan foto baru tiap halaman.

Kenapa?
- User minta: preview HANYA menampilkan halaman TERBARU yang sudah
  di-colorize, bukan semua halaman menumpuk sebagai pesan terpisah.
- Saat pindah dari halaman 1 -> 2, gambar pada pesan yang SAMA diganti
  (pakai Telegram Bot API `editMessageMedia`) — bukan kirim pesan baru.

Fallback: jika edit_message_media gagal (mis. pesan pertama belum
berupa foto, pesan terlalu lama utk diedit, dll), pesan lama dihapus
(best-effort) lalu foto baru dikirim sebagai pesan preview berikutnya.
"""

from __future__ import annotations

import logging
from typing import Any

from telegram import InputMediaPhoto

log = logging.getLogger(__name__)


class RollingPreview:
    """Satu pesan foto preview yang diganti (edit) tiap halaman selesai."""

    def __init__(self, bot: Any, chat_id: int):
        self.bot = bot
        self.chat_id = chat_id
        self.message_id: int | None = None

    async def update(self, photo: bytes, caption: str) -> None:
        """Tampilkan `photo` + `caption` sebagai preview TERBARU.

        - Panggilan pertama: kirim pesan foto baru, simpan message_id.
        - Panggilan berikutnya: EDIT pesan sebelumnya (ganti gambar &
          caption SEKALIGUS, jadi terasa seperti "loncat" dari
          halaman 1 -> 2 di pesan yang sama).
        - Jika edit gagal (exception apapun dari Bot API): hapus pesan
          lama (best-effort, boleh gagal jika sudah tidak ada) lalu
          kirim foto baru sebagai pesan preview berikutnya.
        """
        if self.message_id is None:
            msg = await self.bot.send_photo(self.chat_id, photo=photo, caption=caption)
            self.message_id = msg.message_id
            return

        try:
            await self.bot.edit_message_media(
                chat_id=self.chat_id,
                message_id=self.message_id,
                media=InputMediaPhoto(media=photo, caption=caption),
            )
            return
        except Exception:
            log.warning(
                "edit_message_media gagal (msg_id=%s) — fallback hapus & kirim ulang.",
                self.message_id,
                exc_info=True,
            )

        try:
            await self.bot.delete_message(self.chat_id, self.message_id)
        except Exception:
            log.debug(
                "Gagal hapus pesan preview lama (msg_id=%s) — lanjut kirim baru saja.",
                self.message_id,
                exc_info=True,
            )

        msg = await self.bot.send_photo(self.chat_id, photo=photo, caption=caption)
        self.message_id = msg.message_id
