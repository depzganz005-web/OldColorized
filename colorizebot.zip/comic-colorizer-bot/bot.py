"""
bot.py
======
Bot Telegram untuk colorize komik PDF lewat website AI (browser asli,
TANPA API).

Alur:
1. User kirim file PDF -> dipecah jadi gambar per halaman.
2. Bot tampilkan menu metode: Palette.fm / Style2Paints / DeepAI.
3. (Palette.fm) Bot ambil daftar filter langsung dari website, user pilih.
   (Style2Paints) User pilih versi v1-v4.5.
4. User konfirmasi -> bot proses tiap halaman satu-satu lewat Playwright
   (Chromium headless): upload gambar ke website, tunggu hasil, download.
5. Semua halaman hasil digabung jadi satu PDF, dikirim balik ke user.

Jalankan:  python3 bot.py
(Pastikan .env sudah diisi & `playwright install chromium` sudah dijalankan)
"""

from __future__ import annotations

import asyncio
import logging
import shutil
import uuid
from pathlib import Path

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.error import BadRequest
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)
from PIL import Image

import config
import image_utils
import job_manager
import pdf_utils
from colorizers import factory
from colorizers.browser_manager import browser_manager
from colorizers.errors import ColorizeError, NotSupportedError
from colorizers.style2paints import DESKTOP_ONLY_NOTE, NOT_CONFIGURED_NOTE
from job_manager import JobStatus
from preview import RollingPreview

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("bot")

FILTERS_PER_PAGE = 8

# Simpan referensi task background supaya tidak di-GC oleh asyncio
_background_tasks: set[asyncio.Task] = set()


# ---------------------------------------------------------------------------
# Helper: izin akses
# ---------------------------------------------------------------------------
def is_allowed(update: Update) -> bool:
    user = update.effective_user
    if not user:
        return False
    if not config.ALLOWED_USER_IDS:
        return True
    return user.id in config.ALLOWED_USER_IDS


async def deny(update: Update) -> None:
    if update.message:
        await update.message.reply_text(
            "🚫 Maaf, bot ini privat dan hanya untuk pemilik.\n"
            f"User ID kamu: {update.effective_user.id}\n"
            f"(tambahkan ke ALLOWED_USER_IDS di .env jika ini bot milikmu)"
        )
    elif update.callback_query:
        await update.callback_query.answer("🚫 Tidak diizinkan.", show_alert=True)


# ---------------------------------------------------------------------------
# Keyboard builders
# ---------------------------------------------------------------------------
def kb_method() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("🎨 Palette.fm (pilih filter)", callback_data="m:palette_fm")],
            [InlineKeyboardButton("🖌 Style2Paints (v1 - v4.5)", callback_data="m:style2paints")],
            [InlineKeyboardButton("🤖 DeepAI Colorizer", callback_data="m:deepai")],
        ]
    )


def kb_filters(names: list[str], page: int) -> InlineKeyboardMarkup:
    start = page * FILTERS_PER_PAGE
    end = start + FILTERS_PER_PAGE
    chunk = names[start:end]

    rows: list[list[InlineKeyboardButton]] = []
    for i in range(0, len(chunk), 2):
        row = []
        for j in (i, i + 1):
            if j < len(chunk):
                idx = start + j
                label = chunk[j]
                if len(label) > 24:
                    label = label[:23] + "…"
                row.append(InlineKeyboardButton(label, callback_data=f"f:{idx}"))
        rows.append(row)

    nav = []
    if start > 0:
        nav.append(InlineKeyboardButton("⬅️ Sebelumnya", callback_data=f"fp:{page - 1}"))
    if end < len(names):
        nav.append(InlineKeyboardButton("Selanjutnya ➡️", callback_data=f"fp:{page + 1}"))
    if nav:
        rows.append(nav)

    rows.append([InlineKeyboardButton("🔙 Pilih metode lain", callback_data="back")])
    return InlineKeyboardMarkup(rows)


def kb_style2paints() -> InlineKeyboardMarkup:
    versions = factory.style2paints_versions()
    rows = []
    for key in ("v1", "v2", "v3", "v4", "v45"):
        vcfg = versions.get(key, {})
        label = vcfg.get("label", key)
        if key in ("v4", "v45"):
            label = f"❌ {label}"
        elif not vcfg.get("enabled") or not vcfg.get("url"):
            label = f"⚠️ {label} (belum aktif)"
        else:
            label = f"✅ {label}"
        rows.append([InlineKeyboardButton(label, callback_data=f"s:{key}")])
    rows.append([InlineKeyboardButton("🔙 Pilih metode lain", callback_data="back")])
    return InlineKeyboardMarkup(rows)


def kb_confirm() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("✅ Mulai proses", callback_data="go")],
            [InlineKeyboardButton("🔙 Pilih metode lain", callback_data="back")],
            [InlineKeyboardButton("❌ Batal", callback_data="abort")],
        ]
    )


def kb_cancel_processing(job_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton("🛑 Batalkan proses", callback_data=f"stop:{job_id}")]]
    )


def method_display(method: str | None, option: str | None) -> str:
    if method == "palette_fm":
        return f"Palette.fm — filter: {option}"
    if method == "deepai":
        return "DeepAI Colorizer"
    if method == "style2paints":
        versions = factory.style2paints_versions()
        return versions.get(option or "", {}).get("label", f"Style2Paints {option}")
    return method or "-"


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed(update):
        await deny(update)
        return
    await update.message.reply_text(
        "👋 Halo! Aku bot pewarna komik PDF.\n\n"
        "Cara pakai:\n"
        "1️⃣ Kirim file PDF komik (hitam-putih) ATAU foto/gambar ke chat ini.\n"
        "   (Bot hanya akan konfirmasi terima — BELUM diproses.)\n"
        "2️⃣ REPLY pesan file tersebut dengan /colorize untuk mulai.\n"
        "3️⃣ Pilih metode AI colorizer (Palette.fm / Style2Paints / DeepAI).\n\n"
        "Setelah itu:\n"
        "• Bot membuka tiap halaman di browser asli (bukan API), upload ke "
        "website pilihanmu, lalu mengunduh hasilnya.\n"
        "• Setiap halaman yang SELESAI di-colorize akan langsung dikirim "
        "sebagai preview foto, sambil bot melanjutkan ke halaman berikutnya.\n"
        "• Setelah semua halaman selesai, hasilnya digabung jadi PDF dan "
        "dikirim ke sini (jika ukurannya besar, otomatis dipecah jadi "
        "beberapa file PDF). Kalau sumbernya 1 foto/gambar, hasil dikirim "
        "balik sebagai gambar.\n\n"
        "⚠️ Proses bisa LAMA — tergantung jumlah halaman dan kecepatan "
        "website AI (bisa puluhan detik s/d beberapa menit PER HALAMAN).\n\n"
        "Perintah lain:\n"
        "/colorize — mulai colorize (WAJIB reply ke PDF/foto)\n"
        "/status — cek progres job yang sedang berjalan\n"
        "/cancel — batalkan job yang sedang berjalan"
    )


async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed(update):
        await deny(update)
        return
    chat_id = update.effective_chat.id
    job = job_manager.get_job(chat_id)
    if not job:
        await update.message.reply_text("Tidak ada job yang berjalan.")
        return
    job.cancel_requested = True
    if job.status == JobStatus.PROCESSING:
        await update.message.reply_text(
            "🛑 Membatalkan... menunggu halaman yang sedang diproses selesai."
        )
    else:
        job_manager.clear_job(chat_id, remove_files=True)
        await update.message.reply_text("❌ Job dibatalkan & dibersihkan.")


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed(update):
        await deny(update)
        return
    chat_id = update.effective_chat.id
    job = job_manager.get_job(chat_id)
    if not job:
        await update.message.reply_text("Tidak ada job aktif. Kirim PDF untuk mulai.")
        return
    await update.message.reply_text(
        f"Status   : {job.status.value}\n"
        f"Metode   : {method_display(job.method, job.option)}\n"
        f"Progress : {job.current_page}/{job.total_pages} halaman"
    )


# ---------------------------------------------------------------------------
# Helper: siapkan job dari file PDF / dari satu gambar
# ---------------------------------------------------------------------------
async def _job_from_pdf(chat_id: int, tg_file, status_msg) -> bool:
    """Download PDF, pecah jadi halaman, buat job. Return True jika sukses."""
    job_dir = config.WORKDIR / "jobs" / f"{chat_id}_{uuid.uuid4().hex[:8]}"
    job_dir.mkdir(parents=True, exist_ok=True)
    pdf_path = job_dir / "input.pdf"

    await tg_file.download_to_drive(custom_path=str(pdf_path))

    try:
        pages = await asyncio.to_thread(
            pdf_utils.pdf_to_images, pdf_path, job_dir / "pages", config.PDF_RENDER_DPI
        )
    except Exception as e:
        log.exception("Gagal konversi PDF")
        await status_msg.edit_text(f"❌ Gagal membaca PDF: {e}")
        shutil.rmtree(job_dir, ignore_errors=True)
        return False

    if not pages:
        await status_msg.edit_text("❌ PDF tidak punya halaman / gagal dibaca.")
        shutil.rmtree(job_dir, ignore_errors=True)
        return False

    job_manager.create_job(chat_id, pdf_path, pages)
    await status_msg.edit_text(
        f"✅ PDF siap: {len(pages)} halaman.\n\nPilih metode colorizing:",
        reply_markup=kb_method(),
    )
    return True


async def _job_from_image(chat_id: int, tg_file, status_msg) -> bool:
    """Download satu gambar/foto, buat job 1-halaman (is_single_image)."""
    job_dir = config.WORKDIR / "jobs" / f"{chat_id}_{uuid.uuid4().hex[:8]}"
    pages_dir = job_dir / "pages"
    pages_dir.mkdir(parents=True, exist_ok=True)

    raw_path = job_dir / "input_raw"
    await tg_file.download_to_drive(custom_path=str(raw_path))

    page_path = pages_dir / "page_0001.png"

    def _convert() -> None:
        img = Image.open(raw_path)
        if img.mode != "RGB":
            img = img.convert("RGB")
        img.save(page_path)

    try:
        await asyncio.to_thread(_convert)
    except Exception as e:
        log.exception("Gagal membaca gambar")
        await status_msg.edit_text(f"❌ Gagal membaca gambar: {e}")
        shutil.rmtree(job_dir, ignore_errors=True)
        return False

    # pdf_path di sini "virtual" (tidak dibuat fisik) — job_manager hanya
    # memakai folder induknya (job_dir) sebagai folder kerja job ini.
    job = job_manager.create_job(chat_id, job_dir / "input.pdf", [page_path])
    job.is_single_image = True

    await status_msg.edit_text(
        "✅ Gambar siap (1 halaman).\n\nPilih metode colorizing:",
        reply_markup=kb_method(),
    )
    return True


# ---------------------------------------------------------------------------
# Terima file PDF / gambar dikirim langsung -> HANYA acknowledge,
# proses sesungguhnya baru jalan lewat /colorize (reply).
# ---------------------------------------------------------------------------
async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed(update):
        await deny(update)
        return

    doc = update.message.document
    file_name = (doc.file_name or "").lower()
    mime = doc.mime_type or ""

    is_pdf = mime == "application/pdf" or file_name.endswith(".pdf")
    is_image = mime.startswith("image/")

    if not is_pdf and not is_image:
        await update.message.reply_text("⚠️ Kirim file PDF atau gambar.")
        return

    if is_pdf:
        await update.message.reply_text(
            "📄 PDF diterima. Belum diproses.\n"
            "Reply pesan ini dengan /colorize untuk mulai colorize."
        )
    else:
        await update.message.reply_text(
            "🖼 Gambar diterima. Belum diproses.\n"
            "Reply pesan ini dengan /colorize untuk mulai colorize "
            "(diproses sebagai 1 halaman)."
        )


async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Foto dikirim langsung (bukan sebagai file/dokumen) -> HANYA acknowledge."""
    if not is_allowed(update):
        await deny(update)
        return

    await update.message.reply_text(
        "🖼 Foto diterima. Belum diproses.\n"
        "Reply pesan ini dengan /colorize untuk mulai colorize "
        "(diproses sebagai 1 halaman).\n"
        "💡 Untuk kualitas terbaik, kirim gambar sebagai File/Dokumen — "
        "Telegram mengompres foto yang dikirim biasa."
    )


# ---------------------------------------------------------------------------
# /colorize — reply ke pesan berisi PDF atau foto/gambar
# (satu-satunya cara untuk memulai proses colorize)
# ---------------------------------------------------------------------------
async def cmd_colorize(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed(update):
        await deny(update)
        return

    chat_id = update.effective_chat.id
    msg = update.message

    if job_manager.get_job(chat_id):
        await msg.reply_text(
            "⚠️ Masih ada job berjalan/menunggu untuk chat ini. "
            "Kirim /cancel dulu sebelum mulai job baru."
        )
        return

    target = msg.reply_to_message
    if not target:
        await msg.reply_text(
            "↩️ Reply pesan yang berisi file PDF atau foto/gambar dengan "
            "/colorize untuk mulai."
        )
        return

    pdf_file_obj = None
    image_file_id: str | None = None

    if target.document:
        d_mime = target.document.mime_type or ""
        d_name = (target.document.file_name or "").lower()
        if d_mime == "application/pdf" or d_name.endswith(".pdf"):
            pdf_file_obj = await target.document.get_file()
        elif d_mime.startswith("image/"):
            image_file_id = target.document.file_id

    if pdf_file_obj is None and image_file_id is None and target.photo:
        image_file_id = target.photo[-1].file_id

    if pdf_file_obj is None and image_file_id is None:
        await msg.reply_text(
            "⚠️ Pesan yang di-reply harus berisi file PDF atau foto/gambar."
        )
        return

    status_msg = await msg.reply_text("⏳ Menyiapkan file...")

    if pdf_file_obj is not None:
        await _job_from_pdf(chat_id, pdf_file_obj, status_msg)
    else:
        tg_file = await context.bot.get_file(image_file_id)
        await _job_from_image(chat_id, tg_file, status_msg)


# ---------------------------------------------------------------------------
# Callback query: semua tombol inline
# ---------------------------------------------------------------------------
async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not is_allowed(update):
        await deny(update)
        return

    chat_id = update.effective_chat.id
    data = query.data or ""
    job = job_manager.get_job(chat_id)

    # ---- tombol batal selagi proses berjalan ----
    if data.startswith("stop:"):
        if job and job.job_id == data.split(":", 1)[1]:
            job.cancel_requested = True
            await query.answer("Membatalkan...")
        else:
            await query.answer("Job ini sudah tidak aktif.")
        return

    if not job:
        await query.answer()
        await query.edit_message_text("Sesi sudah tidak berlaku. Kirim ulang PDF untuk mulai lagi.")
        return

    await query.answer()

    # ---- batal sebelum proses dimulai ----
    if data == "abort":
        job_manager.clear_job(chat_id, remove_files=True)
        await query.edit_message_text("❌ Dibatalkan. Kirim PDF baru kapan saja.")
        return

    # ---- kembali ke menu metode ----
    if data == "back":
        job.method = None
        job.option = None
        await query.edit_message_text(
            f"PDF: {job.total_pages} halaman.\nPilih metode colorizing:",
            reply_markup=kb_method(),
        )
        return

    # ---- pilih metode utama ----
    if data.startswith("m:"):
        method = data.split(":", 1)[1]
        job.method = method
        job.option = None

        if method == "palette_fm":
            await query.edit_message_text("⏳ Mengambil daftar filter dari Palette.fm...")
            try:
                colorizer = factory.get_palette_fm()
                names = await colorizer.list_filters(job.page_paths[0])
                job.filter_cache = names
            except ColorizeError as e:
                await query.edit_message_text(
                    f"❌ Gagal mengambil daftar filter dari Palette.fm:\n{e}\n\n"
                    f"Pilih metode lain, atau cek selectors.yaml.",
                    reply_markup=kb_method(),
                )
                return
            await query.edit_message_text(
                f"Pilih filter Palette.fm ({len(names)} tersedia):",
                reply_markup=kb_filters(names, 0),
            )
            return

        if method == "style2paints":
            await query.edit_message_text(
                "Pilih versi Style2Paints:\n"
                "✅ = aktif & dikonfigurasi   ⚠️ = belum dikonfigurasi   "
                "❌ = aplikasi desktop (tidak didukung)",
                reply_markup=kb_style2paints(),
            )
            return

        if method == "deepai":
            await query.edit_message_text(
                f"Metode : DeepAI Colorizer\nHalaman: {job.total_pages}\n\nLanjutkan?",
                reply_markup=kb_confirm(),
            )
            return

    # ---- pagination daftar filter palette.fm ----
    if data.startswith("fp:"):
        page = int(data.split(":", 1)[1])
        names = job.filter_cache or []
        await query.edit_message_text(
            f"Pilih filter Palette.fm ({len(names)} tersedia):",
            reply_markup=kb_filters(names, page),
        )
        return

    # ---- pilih filter palette.fm ----
    if data.startswith("f:"):
        idx = int(data.split(":", 1)[1])
        names = job.filter_cache or []
        if idx >= len(names):
            await query.answer("Pilihan tidak valid", show_alert=True)
            return
        job.option = names[idx]
        await query.edit_message_text(
            f"Metode : Palette.fm\n"
            f"Filter : {job.option}\n"
            f"Halaman: {job.total_pages}\n\nLanjutkan?",
            reply_markup=kb_confirm(),
        )
        return

    # ---- pilih versi style2paints ----
    if data.startswith("s:"):
        version_key = data.split(":", 1)[1]
        versions = factory.style2paints_versions()
        vcfg = versions.get(version_key, {})
        label = vcfg.get("label", version_key)

        if version_key in ("v4", "v45"):
            await query.edit_message_text(
                DESKTOP_ONLY_NOTE.format(label=label) + "\n\nPilih metode lain:",
                reply_markup=kb_method(),
            )
            job.method = None
            job.option = None
            return

        if not vcfg.get("enabled") or not vcfg.get("url"):
            await query.edit_message_text(
                NOT_CONFIGURED_NOTE.format(label=label, key=version_key)
                + "\n\nPilih metode lain:",
                reply_markup=kb_method(),
            )
            job.method = None
            job.option = None
            return

        job.option = version_key
        await query.edit_message_text(
            f"Metode : {label}\nHalaman: {job.total_pages}\n\nLanjutkan?",
            reply_markup=kb_confirm(),
        )
        return

    # ---- mulai proses ----
    if data == "go":
        if not job.method:
            await query.edit_message_text("Pilih metode dulu.", reply_markup=kb_method())
            return
        job.status = JobStatus.PROCESSING
        await query.edit_message_text(
            f"🎨 Memulai: {method_display(job.method, job.option)}\n"
            f"Total halaman: {job.total_pages}"
        )
        task = asyncio.create_task(run_job(chat_id, context))
        _background_tasks.add(task)
        task.add_done_callback(_background_tasks.discard)
        return


# ---------------------------------------------------------------------------
# Proses utama: colorize semua halaman -> gabung PDF -> kirim
# ---------------------------------------------------------------------------
def _get_colorizer(method: str, option: str | None):
    if method == "palette_fm":
        return factory.get_palette_fm()
    if method == "deepai":
        return factory.get_deepai()
    if method == "style2paints":
        return factory.get_style2paints(option or "")
    raise ValueError(f"Metode tidak dikenal: {method}")


async def run_job(chat_id: int, context: ContextTypes.DEFAULT_TYPE) -> None:
    job = job_manager.get_job(chat_id)
    if not job:
        return

    try:
        colorizer = _get_colorizer(job.method or "", job.option)
    except Exception as e:
        await context.bot.send_message(chat_id, f"❌ Error internal: {e}")
        job_manager.clear_job(chat_id)
        return

    total = job.total_pages
    progress_msg = await context.bot.send_message(
        chat_id,
        f"🎨 Memproses halaman 1/{total}...",
        reply_markup=kb_cancel_processing(job.job_id),
    )

    completed = 0
    failed_pages: list[str] = []
    not_supported: NotSupportedError | None = None
    lock = asyncio.Lock()
    preview_lock = asyncio.Lock()
    rolling_preview = RollingPreview(context.bot, chat_id)

    sem = asyncio.Semaphore(config.CONCURRENCY)

    async def update_progress(current_page: int | None) -> None:
        """current_page = halaman yang SEDANG diproses (None = semua selesai)."""
        job.current_page = completed
        lines = []
        if current_page is not None and current_page <= total:
            lines.append(f"🎨 Memproses halaman {current_page}/{total}...")
        lines.append(f"✅ Selesai: {completed}/{total}")
        if failed_pages:
            lines.append(f"⚠️ Gagal: {len(failed_pages)} (pakai gambar asli)")
        try:
            await progress_msg.edit_text(
                "\n".join(lines), reply_markup=kb_cancel_processing(job.job_id)
            )
        except BadRequest:
            pass

    async def send_preview(page_num: int, out_path: Path, ok: bool) -> None:
        """
        Tampilkan foto preview halaman yang baru selesai di-colorize.

        HANYA SATU pesan preview yang ada di chat — setiap halaman baru
        akan MENGGANTI gambar+caption pesan itu (edit_message_media),
        bukan mengirim pesan baru. Lihat preview.RollingPreview.
        """
        if not config.SEND_PAGE_PREVIEWS:
            return
        try:
            data = await asyncio.to_thread(
                image_utils.make_preview_bytes, out_path, config.PREVIEW_MAX_DIM
            )
            if ok:
                caption = f"✅ Halaman {page_num}/{total} selesai di-colorize"
            else:
                caption = (
                    f"⚠️ Halaman {page_num}/{total} gagal di-colorize "
                    f"— memakai gambar asli"
                )
            async with preview_lock:
                await rolling_preview.update(data, caption)
        except Exception:
            log.exception("Gagal update preview halaman %s", page_num)

    async def process_one(page_num: int, src_path: Path) -> None:
        nonlocal completed, not_supported
        if job.cancel_requested or not_supported:
            return

        out_path = job.colorized_dir / src_path.name

        async with sem:
            if job.cancel_requested or not_supported:
                return

            # Beri tahu user halaman mana yang sedang dikerjakan SEKARANG.
            await update_progress(current_page=page_num)

            last_err: Exception | None = None
            for attempt in range(2):
                try:
                    await colorizer.colorize(src_path, out_path, job.option)
                    last_err = None
                    break
                except NotSupportedError as e:
                    async with lock:
                        not_supported = e
                    return
                except ColorizeError as e:
                    last_err = e
                    log.warning(
                        "Job %s halaman %s percobaan %d gagal: %s",
                        job.job_id, src_path.name, attempt + 1, e,
                    )
                    await asyncio.sleep(2)

            ok = last_err is None
            if not ok:
                # fallback: pakai gambar asli supaya PDF tetap lengkap
                shutil.copy(src_path, out_path)
                async with lock:
                    failed_pages.append(src_path.name)

        async with lock:
            completed += 1

        # Halaman ini selesai -> kirim preview-nya, lalu update progress
        # supaya menunjukkan halaman berikutnya yang akan diproses.
        await send_preview(page_num, out_path, ok)
        await update_progress(current_page=page_num + 1)

    tasks = [
        asyncio.create_task(process_one(i + 1, p))
        for i, p in enumerate(job.page_paths)
    ]
    try:
        await asyncio.gather(*tasks)
    except Exception:
        log.exception("run_job: error tak terduga saat gather")
        for t in tasks:
            t.cancel()
        await progress_msg.edit_text("❌ Terjadi error tak terduga. Cek log server.")
        job_manager.clear_job(chat_id)
        return

    if not_supported is not None:
        await progress_msg.edit_text(f"❌ {not_supported}")
        job_manager.clear_job(chat_id)
        return

    if job.cancel_requested:
        await progress_msg.edit_text(
            f"🛑 Dibatalkan ({completed}/{total} halaman sempat selesai)."
        )
        job_manager.clear_job(chat_id)
        return

    # ------------------------------------------------------------------
    # Semua halaman selesai -> kirim hasil akhir
    # ------------------------------------------------------------------
    caption = f"✅ Selesai! {total} halaman — {method_display(job.method, job.option)}."
    if failed_pages:
        caption += f"\n⚠️ {len(failed_pages)} halaman gagal diwarnai (memakai versi asli)."

    if job.is_single_image:
        # Input berupa 1 foto/gambar -> kirim balik sebagai gambar
        # (bukan dibungkus PDF).
        try:
            await progress_msg.edit_text("🎨 Selesai. Mengirim hasil...")
        except BadRequest:
            pass

        out_path = job.colorized_dir / job.page_paths[0].name
        try:
            with out_path.open("rb") as f:
                await context.bot.send_document(
                    chat_id=chat_id,
                    document=f,
                    filename="hasil_colorized.png",
                    caption=caption,
                )
        except Exception as e:
            log.exception("Gagal kirim gambar hasil")
            await context.bot.send_message(
                chat_id,
                f"❌ Gagal mengirim hasil: {e}\nFile masih ada di server: {out_path}",
            )
    else:
        try:
            await progress_msg.edit_text(
                f"🎨 {completed}/{total} selesai. Menggabungkan jadi PDF..."
            )
        except BadRequest:
            pass

        colorized_paths = sorted(job.colorized_dir.glob("page_*.png"))
        max_bytes = config.MAX_TELEGRAM_FILE_MB * 1_000_000
        try:
            parts = await asyncio.to_thread(
                pdf_utils.images_to_pdf_parts,
                colorized_paths,
                job.output_pdf.parent,
                max_bytes,
                "hasil_colorized",
            )
        except Exception as e:
            log.exception("Gagal gabung PDF")
            await progress_msg.edit_text(f"❌ Gagal menggabungkan PDF: {e}")
            job_manager.clear_job(chat_id)
            return

        # PDF kebesaran -> dipecah jadi beberapa file, beri tahu user dulu.
        if len(parts) > 1:
            total_size_mb = sum(p.stat().st_size for p, _, _ in parts) / 1_000_000
            await context.bot.send_message(
                chat_id,
                f"⚠️ Total ukuran hasil ±{total_size_mb:.1f} MB, melebihi limit "
                f"Telegram (±{config.MAX_TELEGRAM_FILE_MB}MB per file). "
                f"PDF akan dikirim dalam {len(parts)} bagian terpisah — "
                f"semua {total} halaman tetap lengkap, tidak ada yang dipotong.",
            )

        for i, (part_path, start_pg, end_pg) in enumerate(parts, start=1):
            part_caption = caption
            if len(parts) > 1:
                part_caption += f"\nBagian {i}/{len(parts)} — halaman {start_pg}-{end_pg}"
            filename = (
                "hasil_colorized.pdf" if len(parts) == 1 else f"hasil_colorized_part{i}.pdf"
            )
            try:
                with part_path.open("rb") as f:
                    await context.bot.send_document(
                        chat_id=chat_id,
                        document=f,
                        filename=filename,
                        caption=part_caption,
                    )
            except Exception as e:
                log.exception("Gagal kirim dokumen bagian %d/%d", i, len(parts))
                await context.bot.send_message(
                    chat_id,
                    f"❌ Gagal mengirim bagian {i}/{len(parts)}: {e}\n"
                    f"File masih ada di server: {part_path}",
                )

    try:
        await progress_msg.delete()
    except BadRequest:
        pass
    job_manager.clear_job(chat_id)


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------
async def post_init(application: Application) -> None:
    await browser_manager.start()
    log.info("Browser Chromium siap.")


async def post_shutdown(application: Application) -> None:
    await browser_manager.stop()


def main() -> None:
    config.validate()

    app = (
        Application.builder()
        .token(config.TELEGRAM_BOT_TOKEN)
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .build()
    )

    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("cancel", cmd_cancel))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("colorize", cmd_colorize))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(CallbackQueryHandler(on_callback))

    log.info("Bot mulai polling...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
