// ─────────────────────────────────────────────────────────────────────────────
//  COMIC COLORIZER BOT v1.0
//  Telegram bot untuk mewarnai komik PDF menggunakan website colorizer
//  Run di: DigitalOcean VPS (Ubuntu 22.04)
// ─────────────────────────────────────────────────────────────────────────────

require('dotenv').config();

const TelegramBot  = require('node-telegram-bot-api');
const puppeteer    = require('puppeteer-extra');
const Stealth      = require('puppeteer-extra-plugin-stealth');
const fse          = require('fs-extra');
const path         = require('path');
const { exec }     = require('child_process');
const { promisify} = require('util');
const axios        = require('axios');
const { PDFDocument } = require('pdf-lib');

puppeteer.use(Stealth());
const execAsync = promisify(exec);

// ─── VALIDASI ENV ────────────────────────────────────────────────────────────

const BOT_TOKEN = process.env.BOT_TOKEN;
if (!BOT_TOKEN) {
  console.error('❌  BOT_TOKEN tidak ada di file .env !');
  process.exit(1);
}

// ─── INIT ─────────────────────────────────────────────────────────────────────

const bot      = new TelegramBot(BOT_TOKEN, { polling: true });
const TEMP_DIR = path.join(__dirname, 'temp');
fse.ensureDirSync(TEMP_DIR);

// Session: chatId → { fileId, fileName, fileSize, processing, cancelFn }
const sessions = new Map();

// ─── DAFTAR COLORIZER ─────────────────────────────────────────────────────────

const COLORIZERS = {
  deepai: {
    id: 'deepai',
    name: '🎨 DeepAI Colorizer',
    desc: 'Neural network AI — kualitas terbaik',
    url:  'https://deepai.org/machine-learning-model/colorizer'
  },
  imgcolorizer: {
    id: 'imgcolorizer',
    name: '🖌️ Image Colorizer',
    desc: 'Cepat & simpel — imagecolorizer.com',
    url:  'https://imagecolorizer.com'
  }
};

// ─── BROWSER HELPER ───────────────────────────────────────────────────────────

async function launchBrowser() {
  return puppeteer.launch({
    headless: 'new',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',  // penting di VPS RAM terbatas
      '--disable-gpu',
      '--no-zygote',
      '--single-process',
      '--disable-extensions',
      '--disable-background-networking',
      '--disable-sync',
      '--mute-audio',
      '--window-size=1366,768'
    ],
    timeout: 30000
  });
}

// Delay helper
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// ─── PDF UTILITIES ────────────────────────────────────────────────────────────

/**
 * Download file dari Telegram ke Buffer
 */
async function downloadTelegramFile(fileId) {
  const url      = await bot.getFileLink(fileId);
  const response = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 180000   // 3 menit
  });
  return Buffer.from(response.data);
}

/**
 * Konversi PDF → array path PNG menggunakan pdftoppm
 * Butuh: apt install poppler-utils
 */
async function pdfToImages(pdfPath, outDir) {
  await fse.ensureDir(outDir);

  // pdftoppm: -r 200 = 200 DPI, -png = format PNG
  const cmd = `pdftoppm -r 200 -png "${pdfPath}" "${outDir}/page"`;

  try {
    await execAsync(cmd);
  } catch (err) {
    throw new Error(
      `Konversi PDF gagal!\n` +
      `Pesan: ${err.message}\n` +
      `Pastikan poppler-utils terinstall: sudo apt install -y poppler-utils`
    );
  }

  // Baca dan urutkan file gambar
  const files = (await fse.readdir(outDir))
    .filter(f => /\d+\.png$/i.test(f))
    .sort((a, b) => {
      const nA = parseInt(a.match(/(\d+)\.png$/i)?.[1] ?? '0');
      const nB = parseInt(b.match(/(\d+)\.png$/i)?.[1] ?? '0');
      return nA - nB;
    })
    .map(f => path.join(outDir, f));

  if (files.length === 0) {
    throw new Error('Tidak ada gambar yang dihasilkan. File PDF mungkin rusak atau kosong.');
  }

  return files;
}

/**
 * Gabungkan array gambar → PDF tunggal
 */
async function imagesToPdf(imagePaths, outPdfPath) {
  const pdfDoc = await PDFDocument.create();

  for (const imgPath of imagePaths) {
    try {
      const bytes = await fse.readFile(imgPath);
      let img;

      const ext = path.extname(imgPath).toLowerCase();
      if (ext === '.png') {
        img = await pdfDoc.embedPng(bytes);
      } else {
        // jpg/jpeg/webp — coba embed sebagai jpg
        img = await pdfDoc.embedJpg(bytes);
      }

      const page = pdfDoc.addPage([img.width, img.height]);
      page.drawImage(img, { x: 0, y: 0, width: img.width, height: img.height });

    } catch (err) {
      console.warn(`⚠️  Skip gambar ${path.basename(imgPath)}: ${err.message}`);
    }
  }

  const pdfBytes = await pdfDoc.save();
  await fse.writeFile(outPdfPath, pdfBytes);
  return outPdfPath;
}

// ─── COLORIZER: DEEPAI ────────────────────────────────────────────────────────

/**
 * Upload gambar ke deepai.org via Puppeteer.
 * Strategi: intersep respons JSON dari api.deepai.org yang berisi output_url
 */
async function colorizeDeepAI(imagePath, outputPath) {
  const browser = await launchBrowser();

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1366, height: 768 });
    await page.setExtraHTTPHeaders({ 'Accept-Language': 'en-US,en;q=0.9' });

    // Siapkan promise untuk menangkap URL hasil colorisasi
    let resolveUrl, rejectUrl;
    const urlPromise = new Promise((res, rej) => {
      resolveUrl = res;
      rejectUrl  = rej;
    });

    // Timeout 2 menit
    const tOut = setTimeout(
      () => rejectUrl(new Error('Timeout DeepAI (2 menit)')),
      120000
    );

    // Intersep semua respons network
    page.on('response', async (resp) => {
      try {
        const url    = resp.url();
        const status = resp.status();
        if (status !== 200) return;

        // DeepAI API response mengandung output_url
        if (url.includes('api.deepai.org') || url.includes('/api/colorizer')) {
          const text = await resp.text().catch(() => '');
          if (text.includes('output_url')) {
            const json = JSON.parse(text);
            if (json.output_url) {
              clearTimeout(tOut);
              resolveUrl(json.output_url);
            }
          }
        }
      } catch (_) {}
    });

    // Buka halaman colorizer
    await page.goto('https://deepai.org/machine-learning-model/colorizer', {
      waitUntil: 'networkidle2',
      timeout:   30000
    });

    // Tutup popup / modal kalau ada
    try {
      await page.waitForSelector('[class*="modal-close"],[data-dismiss="modal"],button.close', { timeout: 3000 });
      await page.click('[class*="modal-close"],[data-dismiss="modal"],button.close');
      await sleep(1000);
    } catch (_) {}

    // Tunggu file input (sering hidden)
    await page.waitForSelector('input[type="file"]', { timeout: 15000 });
    const fileInput = await page.$('input[type="file"]');
    if (!fileInput) throw new Error('File input tidak ditemukan di halaman DeepAI');

    // Upload gambar
    await fileInput.uploadFile(imagePath);

    // Tunggu hasil dari intersep network
    const resultUrl = await urlPromise;

    // Download gambar hasil
    const imgResp = await axios.get(resultUrl, {
      responseType: 'arraybuffer',
      timeout: 60000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer':    'https://deepai.org/'
      }
    });

    await fse.writeFile(outputPath, Buffer.from(imgResp.data));
    return outputPath;

  } finally {
    await browser.close();
  }
}

// ─── COLORIZER: IMAGECOLORIZER.COM ───────────────────────────────────────────

/**
 * Upload gambar ke imagecolorizer.com via Puppeteer.
 * Strategi: intersep JSON atau cek DOM untuk gambar hasil
 */
async function colorizeImageColorizer(imagePath, outputPath) {
  const browser = await launchBrowser();

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1366, height: 768 });

    // Promise untuk menangkap URL hasil
    let resolveUrl, rejectUrl;
    const urlPromise = new Promise((res, rej) => {
      resolveUrl = res;
      rejectUrl  = rej;
    });

    const tOut = setTimeout(
      () => rejectUrl(new Error('Timeout Image Colorizer (2 menit)')),
      120000
    );

    page.on('response', async (resp) => {
      try {
        const url         = resp.url();
        const contentType = resp.headers()['content-type'] ?? '';
        const status      = resp.status();

        if (status !== 200) return;

        if (url.includes('imagecolorizer') && contentType.includes('json')) {
          const json = await resp.json().catch(() => null);
          if (!json) return;
          const found = json.url || json.output_url || json.image || json.result;
          if (found) {
            clearTimeout(tOut);
            resolveUrl(found);
          }
        }
      } catch (_) {}
    });

    await page.goto('https://imagecolorizer.com', {
      waitUntil: 'networkidle2',
      timeout:   30000
    });

    await page.waitForSelector('input[type="file"]', { timeout: 15000 });
    const fileInput = await page.$('input[type="file"]');
    if (!fileInput) throw new Error('File input tidak ditemukan di imagecolorizer.com');
    await fileInput.uploadFile(imagePath);

    // Coba intersep network dulu (30 dtk), lalu fallback ke DOM
    let resultSrc = null;
    try {
      resultSrc = await Promise.race([
        urlPromise,
        sleep(30000).then(() => Promise.reject(new Error('fallback_to_dom')))
      ]);
    } catch (_) {
      clearTimeout(tOut);

      // Fallback: tunggu gambar muncul di DOM
      await page.waitForFunction(
        () => {
          const sels = [
            '#result-image',
            '.result-image img',
            '.colorized-image',
            '.output img',
            'img[src*="coloriz"]',
            'img[src*="result"]'
          ];
          for (const s of sels) {
            const el = document.querySelector(s);
            if (el?.src && !el.src.includes('placeholder') && !el.src.includes('loading')) {
              return true;
            }
          }
          return false;
        },
        { timeout: 90000, polling: 2000 }
      );

      resultSrc = await page.evaluate(() => {
        const sels = ['#result-image','img[src*="coloriz"]','img[src*="result"]','.output img','.result img'];
        for (const s of sels) {
          const el = document.querySelector(s);
          if (el?.src) return el.src;
        }
        // Coba canvas
        const canvas = document.querySelector('canvas');
        return canvas ? canvas.toDataURL('image/jpeg', 0.9) : null;
      });
    }

    if (!resultSrc) throw new Error('Tidak mendapat hasil dari Image Colorizer');

    // Simpan hasil
    if (resultSrc.startsWith('data:')) {
      // Base64 data URL
      const b64 = resultSrc.split(',')[1];
      await fse.writeFile(outputPath, Buffer.from(b64, 'base64'));
    } else {
      const imgResp = await axios.get(resultSrc, {
        responseType: 'arraybuffer',
        timeout: 60000,
        headers: { 'Referer': 'https://imagecolorizer.com/' }
      });
      await fse.writeFile(outputPath, Buffer.from(imgResp.data));
    }

    return outputPath;

  } finally {
    await browser.close();
  }
}

// Map ID → fungsi colorizer
const COLORIZER_FN = {
  deepai:       colorizeDeepAI,
  imgcolorizer: colorizeImageColorizer
};

// ─── PROSES UTAMA ─────────────────────────────────────────────────────────────

async function processColorization(chatId, session, colorizerId) {
  const colorizer = COLORIZERS[colorizerId];
  const jobId     = `${chatId}_${Date.now()}`;
  const jobDir    = path.join(TEMP_DIR, jobId);
  const pdfIn     = path.join(jobDir, 'input.pdf');
  const pagesDir  = path.join(jobDir, 'pages');
  const colorDir  = path.join(jobDir, 'colored');
  const pdfOut    = path.join(jobDir, 'output.pdf');

  await fse.ensureDir(jobDir);

  let statusMsgId = null;
  let cancelled   = false;

  // Simpan fungsi cancel ke session
  session.cancelFn = () => { cancelled = true; };

  // Helper update pesan status Telegram
  const updateStatus = async (text, opts = {}) => {
    try {
      if (statusMsgId) {
        await bot.editMessageText(text, {
          chat_id:    chatId,
          message_id: statusMsgId,
          parse_mode: 'Markdown',
          ...opts
        });
      } else {
        const msg = await bot.sendMessage(chatId, text, {
          parse_mode: 'Markdown',
          ...opts
        });
        statusMsgId = msg.message_id;
      }
    } catch (_) {}
  };

  try {
    // ── 1. Download PDF ──
    await updateStatus('⬇️ Mengunduh file PDF dari Telegram...');
    const pdfBuf = await downloadTelegramFile(session.fileId);
    await fse.writeFile(pdfIn, pdfBuf);

    // ── 2. PDF → Gambar ──
    await updateStatus('🔄 Mengkonversi PDF ke gambar halaman...');
    const pages      = await pdfToImages(pdfIn, pagesDir);
    const totalPages = pages.length;

    const estMins = Math.ceil((totalPages * 50) / 60);
    await updateStatus(
      `📄 Ditemukan *${totalPages} halaman*\n` +
      `🎨 Colorizer: *${colorizer.name}*\n` +
      `⏱ Estimasi: ~${estMins} menit\n\n` +
      `_Memulai proses..._`
    );

    // ── 3. Colorize setiap halaman ──
    await fse.ensureDir(colorDir);
    const colorizedPaths = [];
    let   success = 0, failed = 0;
    const colorizerFn = COLORIZER_FN[colorizerId];

    for (let i = 0; i < pages.length; i++) {
      if (cancelled) {
        await bot.sendMessage(chatId, '🛑 Proses dibatalkan oleh user.');
        break;
      }

      const pageNum = i + 1;
      const inImg   = pages[i];
      const outImg  = path.join(colorDir, `page_${String(pageNum).padStart(4,'0')}.jpg`);

      // Progress bar
      const pct    = Math.floor((i / totalPages) * 100);
      const filled = Math.floor(pct / 10);
      const bar    = '▓'.repeat(filled) + '░'.repeat(10 - filled);

      await updateStatus(
        `🎨 *Mewarnai halaman ${pageNum} / ${totalPages}*\n\n` +
        `[${bar}] ${pct}%\n\n` +
        `✅ Berhasil: ${success}   ❌ Gagal: ${failed}`
      );

      // Coba colorize, max 2 kali percobaan
      let ok = false;
      for (let attempt = 1; attempt <= 2 && !ok; attempt++) {
        try {
          await colorizerFn(inImg, outImg);
          ok = true;
          success++;
          colorizedPaths.push(outImg);
        } catch (err) {
          console.error(`[${chatId}] Hal. ${pageNum} attempt ${attempt}: ${err.message}`);
          if (attempt < 2) await sleep(5000);
        }
      }

      if (!ok) {
        // Fallback: gunakan gambar asli
        const fallback = path.join(colorDir, `page_${String(pageNum).padStart(4,'0')}_orig.png`);
        await fse.copy(inImg, fallback);
        colorizedPaths.push(fallback);
        failed++;
      }

      // Jeda antar halaman supaya tidak kena rate-limit
      if (i < pages.length - 1) await sleep(3000);
    }

    if (cancelled) return;

    // ── 4. Gabungkan ke PDF ──
    await updateStatus(
      `📝 Menggabungkan *${colorizedPaths.length} gambar* menjadi PDF...\n\n` +
      `✅ Diwarnai: ${success}   ❌ Pakai asli: ${failed}`
    );

    await imagesToPdf(colorizedPaths, pdfOut);

    // ── 5. Kirim PDF ──
    const stat     = await fse.stat(pdfOut);
    const sizeMB   = (stat.size / 1024 / 1024).toFixed(2);
    const outName  = session.fileName.replace(/\.pdf$/i, '') + '_colored.pdf';

    // Cek ukuran (limit Telegram 50MB)
    if (stat.size > 49 * 1024 * 1024) {
      await bot.sendMessage(chatId,
        `⚠️ *File terlalu besar (${sizeMB} MB)*\n\n` +
        `Telegram hanya mendukung file ≤ 50 MB.\n` +
        `Coba kurangi halaman PDF atau gunakan gambar dengan resolusi lebih rendah.`,
        { parse_mode: 'Markdown' }
      );
      return;
    }

    await updateStatus('📤 Mengirim PDF berwarna ke Telegram...');

    await bot.sendDocument(chatId, pdfOut, {
      caption:
        `✅ *Selesai!*\n\n` +
        `📄 \`${outName}\`\n` +
        `📊 Total halaman: ${totalPages}\n` +
        `✅ Diwarnai: ${success}\n` +
        `⬜ Halaman asli: ${failed}\n` +
        `📦 Ukuran: ${sizeMB} MB\n` +
        `🎨 ${colorizer.name}`,
      parse_mode: 'Markdown',
      filename:   outName
    });

    await bot.editMessageText('✅ *Selesai! PDF berwarna sudah dikirim.*', {
      chat_id:    chatId,
      message_id: statusMsgId,
      parse_mode: 'Markdown'
    });

    console.log(`[${chatId}] Job selesai: ${success}/${totalPages} halaman diwarnai`);

  } catch (err) {
    console.error(`[${chatId}] Error:`, err);
    const msg = err.message?.slice(0, 300) ?? 'Unknown error';
    await bot.sendMessage(chatId,
      `❌ *Terjadi Error:*\n\`\`\`\n${msg}\n\`\`\`\nSilakan coba lagi atau ganti colorizer.`,
      { parse_mode: 'Markdown' }
    );

  } finally {
    // Cleanup file temp setelah 5 menit
    setTimeout(async () => {
      try { await fse.remove(jobDir); } catch (_) {}
    }, 300000);

    sessions.delete(chatId);
  }
}

// ─── BOT EVENT HANDLERS ───────────────────────────────────────────────────────

// /start
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const list   = Object.values(COLORIZERS)
    .map((c, i) => `${i + 1}. *${c.name}*\n    ${c.desc}`)
    .join('\n');

  bot.sendMessage(chatId,
    `🎨 *Comic Colorizer Bot*\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Warnai halaman komik hitam-putih PDF secara otomatis!\n\n` +
    `*📌 Colorizer tersedia:*\n${list}\n\n` +
    `*🚀 Cara pakai:*\n` +
    `1️⃣ Kirim file PDF komik kamu\n` +
    `2️⃣ Pilih website colorizer\n` +
    `3️⃣ Tunggu proses (tiap halaman ±45 dtk)\n` +
    `4️⃣ Terima PDF berwarna!\n\n` +
    `*📋 Perintah:*\n` +
    `/start — Tampilkan menu ini\n` +
    `/status — Cek status proses\n` +
    `/cancel — Batalkan proses\n\n` +
    `📤 *Kirim PDF sekarang untuk mulai!*`,
    { parse_mode: 'Markdown' }
  );
});

// /status
bot.onText(/\/status/, (msg) => {
  const session = sessions.get(msg.chat.id);
  const text    = session?.processing
    ? '⏳ Sedang proses... Mohon tunggu atau /cancel untuk membatalkan.'
    : '✅ Tidak ada proses aktif. Kirim PDF untuk mulai!';
  bot.sendMessage(msg.chat.id, text);
});

// /cancel
bot.onText(/\/cancel/, (msg) => {
  const chatId  = msg.chat.id;
  const session = sessions.get(chatId);
  if (session) {
    if (session.cancelFn) session.cancelFn();
    sessions.delete(chatId);
    bot.sendMessage(chatId, '🛑 Proses dibatalkan.');
  } else {
    bot.sendMessage(chatId, '⚠️ Tidak ada proses yang sedang berjalan.');
  }
});

// Terima dokumen PDF
bot.on('document', async (msg) => {
  const chatId = msg.chat.id;
  const doc    = msg.document;

  const isPDF = doc.mime_type === 'application/pdf' ||
                doc.file_name?.toLowerCase().endsWith('.pdf');

  if (!isPDF) {
    return bot.sendMessage(chatId,
      '❌ *Hanya menerima file PDF!*\n\nKirim file komik dalam format .pdf',
      { parse_mode: 'Markdown' }
    );
  }

  if (sessions.get(chatId)?.processing) {
    return bot.sendMessage(chatId,
      '⚠️ Masih ada proses berjalan!\nTunggu selesai atau /cancel untuk batalkan.',
      { parse_mode: 'Markdown' }
    );
  }

  // Simpan info file ke session
  sessions.set(chatId, {
    fileId:     doc.file_id,
    fileName:   doc.file_name ?? 'comic.pdf',
    fileSize:   doc.file_size ?? 0,
    processing: false
  });

  const sizeMB = ((doc.file_size ?? 0) / 1024 / 1024).toFixed(1);

  // Tampilkan pilihan colorizer sebagai inline keyboard
  const keyboard = Object.values(COLORIZERS).map(c => [{
    text:          c.name,
    callback_data: `clrz_${c.id}`
  }]);

  await bot.sendMessage(chatId,
    `📄 *File diterima!*\n\n` +
    `📋 Nama: \`${doc.file_name}\`\n` +
    `📦 Ukuran: ${sizeMB} MB\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `🎨 *Pilih website colorizer:*`,
    {
      parse_mode:   'Markdown',
      reply_markup: { inline_keyboard: keyboard }
    }
  );
});

// Tangani pilihan colorizer dari inline keyboard
bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  const data   = query.data;

  await bot.answerCallbackQuery(query.id);

  if (!data.startsWith('clrz_')) return;

  const colorizerId = data.replace('clrz_', '');
  const session     = sessions.get(chatId);
  const colorizer   = COLORIZERS[colorizerId];

  if (!session) {
    return bot.sendMessage(chatId, '❌ Session expired. Kirim ulang file PDF kamu.');
  }

  if (session.processing) {
    return bot.sendMessage(chatId, '⚠️ Sudah dalam proses!');
  }

  if (!colorizer) {
    return bot.sendMessage(chatId, '❌ Colorizer tidak valid.');
  }

  session.processing = true;
  sessions.set(chatId, session);

  await bot.sendMessage(chatId,
    `🚀 *Memulai Colorization!*\n\n` +
    `🎨 Website: *${colorizer.name}*\n` +
    `📄 File: \`${session.fileName}\`\n\n` +
    `_Proses dimulai, mohon jangan kirim PDF lain..._`,
    { parse_mode: 'Markdown' }
  );

  // Jalankan proses di background
  processColorization(chatId, session, colorizerId).catch(err => {
    console.error('Top-level error:', err);
    bot.sendMessage(chatId, `❌ Error: ${err.message}`);
    sessions.delete(chatId);
  });
});

// ─── ERROR HANDLING ───────────────────────────────────────────────────────────

bot.on('polling_error', (err) => {
  console.error('Polling error:', err.code, '-', err.message);
});

process.on('unhandledRejection', (reason) => {
  console.error('UnhandledRejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.error('UncaughtException:', err.message);
  // Jangan exit — biar PM2 yang handle restart
});

// ─── START ────────────────────────────────────────────────────────────────────

console.log('═══════════════════════════════════════════');
console.log('  🎨  Comic Colorizer Bot  v1.0');
console.log('═══════════════════════════════════════════');
console.log(`📁  Temp : ${TEMP_DIR}`);
console.log(`🤖  Token: ${BOT_TOKEN.slice(0, 12)}...`);
console.log('✅  Bot aktif dan siap!');
console.log('═══════════════════════════════════════════');
