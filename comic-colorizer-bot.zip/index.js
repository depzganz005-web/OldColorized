// ─────────────────────────────────────────────────────────────────────────────
//  COMIC COLORIZER BOT v1.0
//  Telegram bot untuk mewarnai komik PDF menggunakan website colorizer
//  Run di: DigitalOcean VPS (Ubuntu 22.04)
// ─────────────────────────────────────────────────────────────────────────────

require('dotenv').config();

const TelegramBot  = require('node-telegram-bot-api');
const puppeteer    = require('puppeteer-extra');
const Stealth      = require('puppeteer-extra-plugin-stealth');
const fse          = require('fs-extra');
const path         = require('path');
const { exec }     = require('child_process');
const { promisify} = require('util');
const axios        = require('axios');
const { PDFDocument } = require('pdf-lib');

puppeteer.use(Stealth());
const execAsync = promisify(exec);

// ─── VALIDASI ENV ────────────────────────────────────────────────────────────

const BOT_TOKEN = process.env.BOT_TOKEN;
if (!BOT_TOKEN) {
  console.error('❌  BOT_TOKEN tidak ada di file .env !');
  process.exit(1);
}

// ─── INIT ─────────────────────────────────────────────────────────────────────

const bot      = new TelegramBot(BOT_TOKEN, { polling: true });
const TEMP_DIR = path.join(__dirname, 'temp');
fse.ensureDirSync(TEMP_DIR);

// Session: chatId → { fileId, fileName, fileSize, processing, cancelFn }
const sessions = new Map();

// ─── DAFTAR COLORIZER ─────────────────────────────────────────────────────────

const COLORIZERS = {
  deepai: {
    id: 'deepai',
    name: '🎨 DeepAI Colorizer',
    desc: 'Neural network AI — kualitas terbaik',
    url:  'https://deepai.org/machine-learning-model/colorizer'
  },
  imgcolorizer: {
    id: 'imgcolorizer',
    name: '🖌️ Image Colorizer',
    desc: 'Cepat & simpel — imagecolorizer.com',
    url:  'https://imagecolorizer.com'
  }
};

// ─── BROWSER HELPER ───────────────────────────────────────────────────────────

async function launchBrowser() {
  return puppeteer.launch({
    headless: 'new',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',  // penting di VPS RAM terbatas
      '--disable-gpu',
      '--no-zygote',
      '--single-process',
      '--disable-extensions',
      '--disable-background-networking',
      '--disable-sync',
      '--mute-audio',
      '--window-size=1366,768'
    ],
    timeout: 30000
  });
}

// Delay helper
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// ─── PDF UTILITIES ────────────────────────────────────────────────────────────

/**
 * Download file dari Telegram ke Buffer
 */
async function downloadTelegramFile(fileId) {
  const url      = await bot.getFileLink(fileId);
  const response = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 180000   // 3 menit
  });
  return Buffer.from(response.data);
}

/**
 * Konversi PDF → array path PNG menggunakan pdftoppm
 * Butuh: apt install poppler-utils
 */
async function pdfToImages(pdfPath, outDir) {
  await fse.ensureDir(outDir);

  // pdftoppm: -r 120 DPI, -jpeg = JPEG (jauh lebih kecil dari PNG)
  // quality 85 = kualitas bagus tapi ukuran kecil
  const cmd = `pdftoppm -r 120 -jpeg -jpegopt quality=85 "${pdfPath}" "${outDir}/page"`;

  try {
    await execAsync(cmd);
  } catch (err) {
    throw new Error(
      `Konversi PDF gagal!\n` +
      `Pesan: ${err.message}\n` +
      `Pastikan poppler-utils terinstall: sudo apt install -y poppler-utils`
    );
  }

  // Baca dan urutkan file gambar (.jpg dari pdftoppm -jpeg)
  const files = (await fse.readdir(outDir))
    .filter(f => /\d+\.jpg$/i.test(f))
    .sort((a, b) => {
      const nA = parseInt(a.match(/(\d+)\.jpg$/i)?.[1] ?? '0');
      const nB = parseInt(b.match(/(\d+)\.jpg$/i)?.[1] ?? '0');
      return nA - nB;
    })
    .map(f => path.join(outDir, f));

  if (files.length === 0) {
    throw new Error('Tidak ada gambar yang dihasilkan. File PDF mungkin rusak atau kosong.');
  }

  return files;
}

/**
 * Gabungkan array gambar → PDF tunggal
 */
async function imagesToPdf(imagePaths, outPdfPath) {
  const pdfDoc = await PDFDocument.create();

  for (const imgPath of imagePaths) {
    try {
      const bytes = await fse.readFile(imgPath);
      let img;

      const ext = path.extname(imgPath).toLowerCase();
      if (ext === '.png') {
        img = await pdfDoc.embedPng(bytes);
      } else {
        // jpg/jpeg/webp — coba embed sebagai jpg
        img = await pdfDoc.embedJpg(bytes);
      }

      const page = pdfDoc.addPage([img.width, img.height]);
      page.drawImage(img, { x: 0, y: 0, width: img.width, height: img.height });

    } catch (err) {
      console.warn(`⚠️  Skip gambar ${path.basename(imgPath)}: ${err.message}`);
    }
  }

  const pdfBytes = await pdfDoc.save();
  await fse.writeFile(outPdfPath, pdfBytes);
  return outPdfPath;
}

// ─── COLORIZER: DEEPAI ────────────────────────────────────────────────────────

/**
 * Upload gambar ke deepai.org via Puppeteer.
 * Strategi berlapis:
 *  1. Intercept SEMUA respons JSON yang mengandung output_url
 *  2. Klik tombol submit setelah upload
 *  3. Polling DOM untuk gambar hasil
 */
async function colorizeDeepAI(imagePath, outputPath) {
  const browser = await launchBrowser();

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 800 });
    await page.setUserAgent(
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
      '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    );

    // ── Tangkap SEMUA JSON response yang mengandung output_url ──
    let capturedUrl = null;
    page.on('response', async (resp) => {
      try {
        if (resp.status() !== 200) return;
        const ct = resp.headers()['content-type'] ?? '';
        if (!ct.includes('json')) return;
        const text = await resp.text().catch(() => '');
        if (!text.includes('output_url')) return;
        const json = JSON.parse(text);
        if (json.output_url && !capturedUrl) {
          capturedUrl = json.output_url;
          console.log('[DeepAI] output_url captured:', capturedUrl.slice(0, 60));
        }
      } catch (_) {}
    });

    // ── Buka halaman ──
    await page.goto('https://deepai.org/machine-learning-model/colorizer', {
      waitUntil: 'domcontentloaded',
      timeout:   40000
    });
    await sleep(2000);

    // ── Tutup popup kalau ada ──
    await page.evaluate(() => {
      document.querySelectorAll(
        '[class*="modal"] [class*="close"], [data-dismiss="modal"], ' +
        '.cookie-notice button, .popup-close, button[aria-label="Close"]'
      ).forEach(el => el.click && el.click());
    }).catch(() => {});
    await sleep(500);

    // ── Paksa semua file input agar bisa diakses ──
    await page.evaluate(() => {
      document.querySelectorAll('input[type="file"]').forEach(el => {
        el.style.cssText =
          'display:block!important;visibility:visible!important;' +
          'opacity:1!important;position:fixed!important;' +
          'top:0;left:0;width:1px;height:1px;z-index:99999';
      });
    });

    // ── Upload file ──
    await page.waitForSelector('input[type="file"]', { timeout: 15000 });
    const fileInput = await page.$('input[type="file"]');
    if (!fileInput) throw new Error('Input file tidak ditemukan di DeepAI');

    await fileInput.uploadFile(imagePath);
    console.log('[DeepAI] File uploaded:', path.basename(imagePath));
    await sleep(1500);

    // ── Cari dan klik tombol submit / colorize ──
    const clicked = await page.evaluate(() => {
      // Coba berbagai selector tombol
      const candidates = Array.from(document.querySelectorAll(
        'button, input[type="submit"], a.btn, .model-input-submit, ' +
        '[class*="submit"], [class*="colorize"], [class*="generate"]'
      ));
      const keywords = ['submit', 'colorize', 'generate', 'run', 'process', 'convert', 'go'];
      for (const el of candidates) {
        const txt = (el.textContent || el.value || el.getAttribute('aria-label') || '').toLowerCase();
        if (keywords.some(k => txt.includes(k))) {
          el.click();
          return txt;
        }
      }
      // Fallback: klik button pertama di area form / model
      const formBtn = document.querySelector(
        'form button[type="submit"], .model-input button, .demo button'
      );
      if (formBtn) { formBtn.click(); return 'form-submit'; }
      return null;
    });
    if (clicked) console.log('[DeepAI] Clicked button:', clicked);

    // ── Tunggu hasil: network intercept + DOM polling ──
    const TIMEOUT_MS = 150000; // 2.5 menit
    const startAt   = Date.now();

    while (Date.now() - startAt < TIMEOUT_MS) {
      // Prioritas 1: dapat dari network intercept
      if (capturedUrl) break;

      // Prioritas 2: cek DOM untuk gambar hasil
      const domUrl = await page.evaluate(() => {
        const sels = [
          '.model-output-image img',
          '.result-image img',
          '#model-output img',
          '.output img',
          'img[src*="api.deepai.org"]',
          'img[src*="output"]',
          'img[src*="result"]'
        ];
        for (const s of sels) {
          const el = document.querySelector(s);
          if (el && el.src && el.src.startsWith('http') &&
              !el.src.includes('placeholder') && !el.src.includes('loading')) {
            return el.src;
          }
        }
        return null;
      }).catch(() => null);

      if (domUrl) { capturedUrl = domUrl; break; }

      await sleep(3000);
    }

    if (!capturedUrl) {
      // Last resort: screenshot area output
      throw new Error('DeepAI tidak menghasilkan output dalam 2.5 menit. Coba lagi.');
    }

    // ── Download gambar hasil ──
    console.log('[DeepAI] Downloading result:', capturedUrl.slice(0, 80));
    const imgResp = await axios.get(capturedUrl, {
      responseType: 'arraybuffer',
      timeout: 60000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        'Referer':    'https://deepai.org/'
      }
    });

    await fse.writeFile(outputPath, Buffer.from(imgResp.data));
    console.log('[DeepAI] Saved to:', outputPath);
    return outputPath;

  } finally {
    await browser.close();
  }
}

// ─── COLORIZER: IMAGECOLORIZER.COM ───────────────────────────────────────────

/**
 * Upload gambar ke imagecolorizer.com via Puppeteer.
 * Strategi: intersep JSON atau cek DOM untuk gambar hasil
 */
async function colorizeImageColorizer(imagePath, outputPath) {
  const browser = await launchBrowser();

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1366, height: 768 });

    // Promise untuk menangkap URL hasil
    let resolveUrl, rejectUrl;
    const urlPromise = new Promise((res, rej) => {
      resolveUrl = res;
      rejectUrl  = rej;
    });

    const tOut = setTimeout(
      () => rejectUrl(new Error('Timeout Image Colorizer (2 menit)')),
      120000
    );

    page.on('response', async (resp) => {
      try {
        const url         = resp.url();
        const contentType = resp.headers()['content-type'] ?? '';
        const status      = resp.status();

        if (status !== 200) return;

        if (url.includes('imagecolorizer') && contentType.includes('json')) {
          const json = await resp.json().catch(() => null);
          if (!json) return;
          const found = json.url || json.output_url || json.image || json.result;
          if (found) {
            clearTimeout(tOut);
            resolveUrl(found);
          }
        }
      } catch (_) {}
    });

    await page.goto('https://imagecolorizer.com', {
      waitUntil: 'networkidle2',
      timeout:   30000
    });

    await page.waitForSelector('input[type="file"]', { timeout: 15000 });
    const fileInput = await page.$('input[type="file"]');
    if (!fileInput) throw new Error('File input tidak ditemukan di imagecolorizer.com');
    await fileInput.uploadFile(imagePath);

    // Coba intersep network dulu (30 dtk), lalu fallback ke DOM
    let resultSrc = null;
    try {
      resultSrc = await Promise.race([
        urlPromise,
        sleep(30000).then(() => Promise.reject(new Error('fallback_to_dom')))
      ]);
    } catch (_) {
      clearTimeout(tOut);

      // Fallback: tunggu gambar muncul di DOM
      await page.waitForFunction(
        () => {
          const sels = [
            '#result-image',
            '.result-image img',
            '.colorized-image',
            '.output img',
            'img[src*="coloriz"]',
            'img[src*="result"]'
          ];
          for (const s of sels) {
            const el = document.querySelector(s);
            if (el?.src && !el.src.includes('placeholder') && !el.src.includes('loading')) {
              return true;
            }
          }
          return false;
        },
        { timeout: 90000, polling: 2000 }
      );

      resultSrc = await page.evaluate(() => {
        const sels = ['#result-image','img[src*="coloriz"]','img[src*="result"]','.output img','.result img'];
        for (const s of sels) {
          const el = document.querySelector(s);
          if (el?.src) return el.src;
        }
        // Coba canvas
        const canvas = document.querySelector('canvas');
        return canvas ? canvas.toDataURL('image/jpeg', 0.9) : null;
      });
    }

    if (!resultSrc) throw new Error('Tidak mendapat hasil dari Image Colorizer');

    // Simpan hasil
    if (resultSrc.startsWith('data:')) {
      // Base64 data URL
      const b64 = resultSrc.split(',')[1];
      await fse.writeFile(outputPath, Buffer.from(b64, 'base64'));
    } else {
      const imgResp = await axios.get(resultSrc, {
        responseType: 'arraybuffer',
        timeout: 60000,
        headers: { 'Referer': 'https://imagecolorizer.com/' }
      });
      await fse.writeFile(outputPath, Buffer.from(imgResp.data));
    }

    return outputPath;

  } finally {
    await browser.close();
  }
}

// Map ID → fungsi colorizer
const COLORIZER_FN = {
  deepai:       colorizeDeepAI,
  imgcolorizer: colorizeImageColorizer
};

// ─── PROSES UTAMA ─────────────────────────────────────────────────────────────

async function processColorization(chatId, session, colorizerId) {
  const colorizer = COLORIZERS[colorizerId];
  const jobId     = `${chatId}_${Date.now()}`;
  const jobDir    = path.join(TEMP_DIR, jobId);
  const pdfIn     = path.join(jobDir, 'input.pdf');
  const pagesDir  = path.join(jobDir, 'pages');
  const colorDir  = path.join(jobDir, 'colored');
  const pdfOut    = path.join(jobDir, 'output.pdf');

  await fse.ensureDir(jobDir);

  let statusMsgId = null;
  let cancelled   = false;

  // Simpan fungsi cancel ke session
  session.cancelFn = () => { cancelled = true; };

  // Helper update pesan status Telegram
  const updateStatus = async (text, opts = {}) => {
    try {
      if (statusMsgId) {
        await bot.editMessageText(text, {
          chat_id:    chatId,
          message_id: statusMsgId,
          parse_mode: 'Markdown',
          ...opts
        });
      } else {
        const msg = await bot.sendMessage(chatId, text, {
          parse_mode: 'Markdown',
          ...opts
        });
        statusMsgId = msg.message_id;
      }
    } catch (_) {}
  };

  try {
    // ── 1. Download PDF ──
    await updateStatus('⬇️ Mengunduh file PDF dari Telegram...');
    const pdfBuf = await downloadTelegramFile(session.fileId);
    await fse.writeFile(pdfIn, pdfBuf);

    // ── 2. PDF → Gambar ──
    await updateStatus('🔄 Mengkonversi PDF ke gambar halaman...');
    const pages      = await pdfToImages(pdfIn, pagesDir);
    const totalPages = pages.length;

    const estMins = Math.ceil((totalPages * 50) / 60);
    await updateStatus(
      `📄 Ditemukan *${totalPages} halaman*\n` +
      `🎨 Colorizer: *${colorizer.name}*\n` +
      `⏱ Estimasi: ~${estMins} menit\n\n` +
      `_Memulai proses..._`
    );

    // ── 3. Colorize setiap halaman ──
    await fse.ensureDir(colorDir);
    const colorizedPaths = [];
    let   success = 0, failed = 0;
    const colorizerFn = COLORIZER_FN[colorizerId];

    for (let i = 0; i < pages.length; i++) {
      if (cancelled) {
        await bot.sendMessage(chatId, '🛑 Proses dibatalkan oleh user.');
        break;
      }

      const pageNum = i + 1;
      const inImg   = pages[i];
      const outImg  = path.join(colorDir, `page_${String(pageNum).padStart(4,'0')}_colored.jpg`);

      // Progress bar
      const pct    = Math.floor((i / totalPages) * 100);
      const filled = Math.floor(pct / 10);
      const bar    = '▓'.repeat(filled) + '░'.repeat(10 - filled);

      await updateStatus(
        `🎨 *Mewarnai halaman ${pageNum} / ${totalPages}*\n\n` +
        `[${bar}] ${pct}%\n\n` +
        `✅ Berhasil: ${success}   ❌ Gagal: ${failed}`
      );

      // Coba colorize, max 2 kali percobaan
      let ok = false;
      for (let attempt = 1; attempt <= 2 && !ok; attempt++) {
        try {
          await colorizerFn(inImg, outImg);
          ok = true;
          success++;
          colorizedPaths.push(outImg);
        } catch (err) {
          console.error(`[${chatId}] Hal. ${pageNum} attempt ${attempt}: ${err.message}`);
          if (attempt < 2) await sleep(5000);
        }
      }

      if (!ok) {
        // Fallback: gunakan gambar asli (sudah JPEG dari pdftoppm)
        // Langsung pakai file asli - sudah JPEG, tidak perlu copy lagi
        colorizedPaths.push(inImg);
        failed++;
      }

      // Jeda antar halaman supaya tidak kena rate-limit
      if (i < pages.length - 1) await sleep(3000);
    }

    if (cancelled) return;

    // ── 4. Gabungkan ke PDF ──
    await updateStatus(
      `📝 Menggabungkan *${colorizedPaths.length} gambar* menjadi PDF...\n\n` +
      `✅ Diwarnai: ${success}   ❌ Pakai asli: ${failed}`
    );

    await imagesToPdf(colorizedPaths, pdfOut);

    // ── 5. Kirim PDF ──
    const stat     = await fse.stat(pdfOut);
    const sizeMB   = (stat.size / 1024 / 1024).toFixed(2);
    const outName  = session.fileName.replace(/\.pdf$/i, '') + '_colored.pdf';

    // Cek ukuran (limit Telegram 50MB)
    if (stat.size > 49 * 1024 * 1024) {
      await bot.sendMessage(chatId,
        `⚠️ *File terlalu besar (${sizeMB} MB)*\n\n` +
        `Telegram hanya mendukung file ≤ 50 MB.\n` +
        `Coba kurangi halaman PDF atau gunakan gambar dengan resolusi lebih rendah.`,
        { parse_mode: 'Markdown' }
      );
      return;
    }

    await updateStatus('📤 Mengirim PDF berwarna ke Telegram...');

    await bot.sendDocument(chatId, pdfOut, {
      caption:
        `✅ *Selesai!*\n\n` +
        `📄 \`${outName}\`\n` +
        `📊 Total halaman: ${totalPages}\n` +
        `✅ Diwarnai: ${success}\n` +
        `⬜ Halaman asli: ${failed}\n` +
        `📦 Ukuran: ${sizeMB} MB\n` +
        `🎨 ${colorizer.name}`,
      parse_mode: 'Markdown',
      filename:   outName
    });

    await bot.editMessageText('✅ *Selesai! PDF berwarna sudah dikirim.*', {
      chat_id:    chatId,
      message_id: statusMsgId,
      parse_mode: 'Markdown'
    });

    console.log(`[${chatId}] Job selesai: ${success}/${totalPages} halaman diwarnai`);

  } catch (err) {
    console.error(`[${chatId}] Error:`, err);
    const msg = err.message?.slice(0, 300) ?? 'Unknown error';
    await bot.sendMessage(chatId,
      `❌ *Terjadi Error:*\n\`\`\`\n${msg}\n\`\`\`\nSilakan coba lagi atau ganti colorizer.`,
      { parse_mode: 'Markdown' }
    );

  } finally {
    // Cleanup file temp setelah 5 menit
    setTimeout(async () => {
      try { await fse.remove(jobDir); } catch (_) {}
    }, 300000);

    sessions.delete(chatId);
  }
}

// ─── BOT EVENT HANDLERS ───────────────────────────────────────────────────────

// /start
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const list   = Object.values(COLORIZERS)
    .map((c, i) => `${i + 1}. *${c.name}*\n    ${c.desc}`)
    .join('\n');

  bot.sendMessage(chatId,
    `🎨 *Comic Colorizer Bot*\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Warnai halaman komik hitam-putih PDF secara otomatis!\n\n` +
    `*📌 Colorizer tersedia:*\n${list}\n\n` +
    `*🚀 Cara pakai:*\n` +
    `1️⃣ Kirim file PDF komik kamu\n` +
    `2️⃣ Pilih website colorizer\n` +
    `3️⃣ Tunggu proses (tiap halaman ±45 dtk)\n` +
    `4️⃣ Terima PDF berwarna!\n\n` +
    `*📋 Perintah:*\n` +
    `/start — Tampilkan menu ini\n` +
    `/status — Cek status proses\n` +
    `/cancel — Batalkan proses\n\n` +
    `📤 *Kirim PDF sekarang untuk mulai!*`,
    { parse_mode: 'Markdown' }
  );
});

// /status
bot.onText(/\/status/, (msg) => {
  const session = sessions.get(msg.chat.id);
  const text    = session?.processing
    ? '⏳ Sedang proses... Mohon tunggu atau /cancel untuk membatalkan.'
    : '✅ Tidak ada proses aktif. Kirim PDF untuk mulai!';
  bot.sendMessage(msg.chat.id, text);
});

// /cancel
bot.onText(/\/cancel/, (msg) => {
  const chatId  = msg.chat.id;
  const session = sessions.get(chatId);
  if (session) {
    if (session.cancelFn) session.cancelFn();
    sessions.delete(chatId);
    bot.sendMessage(chatId, '🛑 Proses dibatalkan.');
  } else {
    bot.sendMessage(chatId, '⚠️ Tidak ada proses yang sedang berjalan.');
  }
});

// Terima dokumen PDF
bot.on('document', async (msg) => {
  const chatId = msg.chat.id;
  const doc    = msg.document;

  const isPDF = doc.mime_type === 'application/pdf' ||
                doc.file_name?.toLowerCase().endsWith('.pdf');

  if (!isPDF) {
    return bot.sendMessage(chatId,
      '❌ *Hanya menerima file PDF!*\n\nKirim file komik dalam format .pdf',
      { parse_mode: 'Markdown' }
    );
  }

  if (sessions.get(chatId)?.processing) {
    return bot.sendMessage(chatId,
      '⚠️ Masih ada proses berjalan!\nTunggu selesai atau /cancel untuk batalkan.',
      { parse_mode: 'Markdown' }
    );
  }

  // Simpan info file ke session
  sessions.set(chatId, {
    fileId:     doc.file_id,
    fileName:   doc.file_name ?? 'comic.pdf',
    fileSize:   doc.file_size ?? 0,
    processing: false
  });

  const sizeMB = ((doc.file_size ?? 0) / 1024 / 1024).toFixed(1);

  // Tampilkan pilihan colorizer sebagai inline keyboard
  const keyboard = Object.values(COLORIZERS).map(c => [{
    text:          c.name,
    callback_data: `clrz_${c.id}`
  }]);

  await bot.sendMessage(chatId,
    `📄 *File diterima!*\n\n` +
    `📋 Nama: \`${doc.file_name}\`\n` +
    `📦 Ukuran: ${sizeMB} MB\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `🎨 *Pilih website colorizer:*`,
    {
      parse_mode:   'Markdown',
      reply_markup: { inline_keyboard: keyboard }
    }
  );
});

// Tangani pilihan colorizer dari inline keyboard
bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  const data   = query.data;

  await bot.answerCallbackQuery(query.id);

  if (!data.startsWith('clrz_')) return;

  const colorizerId = data.replace('clrz_', '');
  const session     = sessions.get(chatId);
  const colorizer   = COLORIZERS[colorizerId];

  if (!session) {
    return bot.sendMessage(chatId, '❌ Session expired. Kirim ulang file PDF kamu.');
  }

  if (session.processing) {
    return bot.sendMessage(chatId, '⚠️ Sudah dalam proses!');
  }

  if (!colorizer) {
    return bot.sendMessage(chatId, '❌ Colorizer tidak valid.');
  }

  session.processing = true;
  sessions.set(chatId, session);

  await bot.sendMessage(chatId,
    `🚀 *Memulai Colorization!*\n\n` +
    `🎨 Website: *${colorizer.name}*\n` +
    `📄 File: \`${session.fileName}\`\n\n` +
    `_Proses dimulai, mohon jangan kirim PDF lain..._`,
    { parse_mode: 'Markdown' }
  );

  // Jalankan proses di background
  processColorization(chatId, session, colorizerId).catch(err => {
    console.error('Top-level error:', err);
    bot.sendMessage(chatId, `❌ Error: ${err.message}`);
    sessions.delete(chatId);
  });
});

// ─── ERROR HANDLING ───────────────────────────────────────────────────────────

bot.on('polling_error', (err) => {
  console.error('Polling error:', err.code, '-', err.message);
});

process.on('unhandledRejection', (reason) => {
  console.error('UnhandledRejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.error('UncaughtException:', err.message);
  // Jangan exit — biar PM2 yang handle restart
});

// ─── START ────────────────────────────────────────────────────────────────────

console.log('═══════════════════════════════════════════');
console.log('  🎨  Comic Colorizer Bot  v1.0');
console.log('═══════════════════════════════════════════');
console.log(`📁  Temp : ${TEMP_DIR}`);
console.log(`🤖  Token: ${BOT_TOKEN.slice(0, 12)}...`);
console.log('✅  Bot aktif dan siap!');
console.log('═══════════════════════════════════════════');
