#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
#  COMIC COLORIZER BOT — SETUP SCRIPT
#  Jalankan sekali saja di VPS baru:  bash setup.sh
#  Ubuntu 22.04 LTS (DigitalOcean Droplet)
# ═══════════════════════════════════════════════════════════════════

set -e   # Berhenti jika ada error

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

ok()   { echo -e "${GREEN}✅ $1${NC}"; }
info() { echo -e "${YELLOW}➡️  $1${NC}"; }
err()  { echo -e "${RED}❌ $1${NC}"; exit 1; }

echo ""
echo "════════════════════════════════════════════════"
echo "  🎨  Comic Colorizer Bot — Auto Setup"
echo "════════════════════════════════════════════════"
echo ""

# ── 1. Update sistem ────────────────────────────────
info "Update sistem..."
apt update -y && apt upgrade -y
ok "Sistem sudah update"

# ── 2. Install package dasar ────────────────────────
info "Install dependencies sistem..."
apt install -y \
  curl wget git unzip build-essential \
  poppler-utils \
  ca-certificates gnupg lsb-release \
  libnss3 libnspr4 libdbus-1-3 \
  libatk1.0-0 libatk-bridge2.0-0 \
  libcups2 libdrm2 libxkbcommon0 \
  libxcomposite1 libxdamage1 libxfixes3 \
  libxrandr2 libgbm1 libasound2 \
  libpango-1.0-0 libpangocairo-1.0-0 \
  libcairo2 libgdk-pixbuf2.0-0 \
  fonts-liberation fonts-noto-cjk
ok "Dependencies sistem terinstall"

# ── 3. Swap space (penting untuk RAM 1GB) ───────────
if [ ! -f /swapfile ]; then
  info "Membuat swap 2GB..."
  fallocate -l 2G /swapfile
  chmod 600 /swapfile
  mkswap /swapfile
  swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
  ok "Swap 2GB aktif"
else
  ok "Swap sudah ada, skip"
fi

# ── 4. Install Node.js 20 LTS ───────────────────────
if ! command -v node &> /dev/null; then
  info "Install Node.js 20 LTS..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt install -y nodejs
  ok "Node.js $(node -v) terinstall"
else
  ok "Node.js sudah ada: $(node -v)"
fi

# ── 5. Install PM2 ──────────────────────────────────
if ! command -v pm2 &> /dev/null; then
  info "Install PM2..."
  npm install -g pm2
  ok "PM2 $(pm2 -v) terinstall"
else
  ok "PM2 sudah ada: $(pm2 -v)"
fi

# ── 6. Buat direktori project ───────────────────────
info "Setup direktori project..."
mkdir -p /root/comic-colorizer-bot/logs
mkdir -p /root/comic-colorizer-bot/temp
ok "Direktori siap"

# ── 7. Install npm packages ─────────────────────────
info "Install npm packages (sabar ya, Puppeteer download Chromium ~200MB)..."
cd /root/comic-colorizer-bot
npm install
ok "npm packages terinstall"

# ── 8. Download Chromium untuk Puppeteer ────────────
info "Download Chromium untuk Puppeteer..."
npx puppeteer browsers install chrome 2>/dev/null || true
ok "Chromium siap"

# ── 9. Cek file .env ────────────────────────────────
if [ ! -f /root/comic-colorizer-bot/.env ]; then
  cp /root/comic-colorizer-bot/.env.example /root/comic-colorizer-bot/.env
  echo ""
  echo "════════════════════════════════════════════════"
  echo -e "${YELLOW}  ⚠️  PENTING: Edit file .env sekarang!${NC}"
  echo "════════════════════════════════════════════════"
  echo ""
  echo "  Jalankan:"
  echo "  nano /root/comic-colorizer-bot/.env"
  echo ""
  echo "  Isi BOT_TOKEN dengan token dari @BotFather"
  echo ""
else
  ok ".env sudah ada"
fi

# ── 10. PM2 startup ─────────────────────────────────
info "Setup PM2 auto-start saat VPS reboot..."
pm2 startup systemd -u root --hp /root 2>/dev/null | tail -1 | bash 2>/dev/null || true
ok "PM2 startup dikonfigurasi"

echo ""
echo "════════════════════════════════════════════════"
echo -e "${GREEN}  ✅  Setup selesai!${NC}"
echo "════════════════════════════════════════════════"
echo ""
echo "  Langkah selanjutnya:"
echo ""
echo "  1. Edit file .env:"
echo "     nano /root/comic-colorizer-bot/.env"
echo ""
echo "  2. Jalankan bot:"
echo "     cd /root/comic-colorizer-bot"
echo "     pm2 start ecosystem.config.js"
echo "     pm2 save"
echo ""
echo "  3. Cek status:"
echo "     pm2 status"
echo "     pm2 logs comic-colorizer-bot"
echo ""
echo "════════════════════════════════════════════════"
