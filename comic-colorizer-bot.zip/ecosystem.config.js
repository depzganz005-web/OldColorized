// PM2 Ecosystem Config — Comic Colorizer Bot
// Jalankan: pm2 start ecosystem.config.js

module.exports = {
  apps: [
    {
      name:              'comic-colorizer-bot',
      script:            'index.js',
      instances:         1,
      autorestart:       true,
      watch:             false,
      max_memory_restart: '900M',   // restart otomatis jika RAM > 900MB
      restart_delay:     5000,      // tunggu 5 detik sebelum restart
      env: {
        NODE_ENV: 'production'
      },
      // Log output
      out_file:  './logs/out.log',
      error_file:'./logs/error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      merge_logs: true
    }
  ]
};
