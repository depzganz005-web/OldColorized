# 🎨 Comic Colorizer Bot

Telegram bot untuk mewarnai halaman komik PDF hitam-putih secara otomatis menggunakan website colorizer (DeepAI, Image Colorizer).

---

## 📱 BAGIAN 1 — Setup Termius di iPhone

### Install & Konfigurasi Termius
1. Download **Termius** dari App Store (gratis)
2. Buka Termius → tap **+** (New Host)
3. Isi form:
   - **Label**: `VPS Comic Bot` (nama bebas)
   - **Hostname**: `IP_VPS_KAMU` (contoh: `178.62.45.123`)
   - **Port**: `22`
   - **Username**: `root`
   - **Password**: password dari DigitalOcean
4. Tap **Save** lalu tap hostnya untuk connect
5. Muncul terminal — kamu sudah masuk ke VPS! ✅

---

## 💧 BAGIAN 2 — Buat Droplet DigitalOcean

1. Buka [digitalocean.com](https://digitalocean.com) → Log in
2. Klik **Create** → **Droplets**
3. Pilih pengaturan berikut:

   | Setting | Nilai |
   |---------|-------|
   | Region | Singapore / Frankfurt (pilih yang dekat) |
   | OS | **Ubuntu 22.04 LTS** |
   | Size | **Basic — Regular — $12/mo (2GB RAM)** ⭐ |
   | Auth | Password (masukkan password kuat) |

4. Klik **Create Droplet**
5. Tunggu ~1 menit, catat **IP Address** yang muncul

> 💡 **Kenapa 2GB RAM?** Puppeteer (Chrome headless) butuh ~500MB per proses. 2GB lebih aman. Kalau mau hemat bisa 1GB + akan dibuatkan swap 2GB otomatis oleh setup script.

---

## 🚀 BAGIAN 3 — Instalasi di VPS

### Langkah 1 — Connect ke VPS via Termius
Buka Termius → connect ke host yang sudah dibuat.

### Langkah 2 — Upload semua file project ke VPS

Cara termudah: copy-paste langsung via terminal.

```bash
# Buat folder project
mkdir -p /root/comic-colorizer-bot
cd /root/comic-colorizer-bot
```

Kemudian buat tiap file dengan cara:
```bash
nano index.js
# Paste isi file, tekan Ctrl+X → Y → Enter untuk save
```

Lakukan hal yang sama untuk: `package.json`, `.env.example`, `ecosystem.config.js`, `setup.sh`

**ATAU** cara lebih cepat — upload via GitHub:
```bash
# Kalau sudah ada di repo git
git clone https://github.com/USERKAMU/comic-colorizer-bot.git /root/comic-colorizer-bot
```

### Langkah 3 — Jalankan setup script

```bash
cd /root/comic-colorizer-bot
chmod +x setup.sh
bash setup.sh
```

Script ini otomatis:
- ✅ Update sistem Ubuntu
- ✅ Install `poppler-utils` (konversi PDF)
- ✅ Buat swap 2GB (jika RAM ≤ 1GB)
- ✅ Install Node.js 20 LTS
- ✅ Install PM2
- ✅ Install semua npm packages
- ✅ Download Chromium untuk Puppeteer
- ✅ Setup PM2 auto-start saat reboot

> ⏳ Proses download Chromium bisa memakan ~5-10 menit tergantung koneksi VPS.

### Langkah 4 — Buat Telegram Bot & dapatkan token

1. Buka Telegram → cari **@BotFather**
2. Ketik `/newbot`
3. Ikuti instruksi (beri nama bot)
4. Copy **token** yang diberikan (format: `1234567890:ABCDef...`)

### Langkah 5 — Isi file .env

```bash
nano /root/comic-colorizer-bot/.env
```

Isi:
```
BOT_TOKEN=1234567890:ABCDefGHIJklmNOPQrstUVwxYZ
```

Tekan `Ctrl+X` → `Y` → `Enter` untuk save.

### Langkah 6 — Jalankan Bot

```bash
cd /root/comic-colorizer-bot

# Buat folder logs
mkdir -p logs

# Start bot dengan PM2
pm2 start ecosystem.config.js

# Simpan konfigurasi PM2 (auto-start saat reboot)
pm2 save

# Lihat status
pm2 status
```

Output yang benar:
```
┌─────────────────────────┬────┬──────┬───────┬────────┐
│ name                    │ id │ mode │ pid   │ status │
├─────────────────────────┼────┼──────┼───────┼────────┤
│ comic-colorizer-bot     │ 0  │ fork │ 12345 │ online │
└─────────────────────────┴────┴──────┴───────┴────────┘
```

---

## 📋 BAGIAN 4 — Perintah PM2 Penting

```bash
# Lihat status semua bot
pm2 status

# Lihat log real-time
pm2 logs comic-colorizer-bot

# Lihat log terakhir 50 baris
pm2 logs comic-colorizer-bot --lines 50

# Restart bot
pm2 restart comic-colorizer-bot

# Stop bot
pm2 stop comic-colorizer-bot

# Hapus dari PM2
pm2 delete comic-colorizer-bot

# Monitor CPU & RAM
pm2 monit
```

---

## 🤖 BAGIAN 5 — Cara Pakai Bot

1. Buka Telegram → cari bot kamu (dari nama yang didaftarkan di BotFather)
2. Ketik `/start`
3. Kirim file PDF komik hitam-putih
4. Pilih colorizer dari tombol yang muncul:
   - **🎨 DeepAI Colorizer** — kualitas lebih baik, sedikit lebih lambat
   - **🖌️ Image Colorizer** — cepat dan simpel
5. Tunggu proses (tiap halaman ±45-60 detik)
6. Download PDF berwarna yang dikirim bot

### Estimasi waktu:
| Jumlah Halaman | Estimasi |
|----------------|----------|
| 10 halaman | ~8-10 menit |
| 25 halaman | ~20-25 menit |
| 50 halaman | ~40-50 menit |

---

## 🔧 BAGIAN 6 — Troubleshooting

### ❌ Error: "poppler-utils not found"
```bash
sudo apt install -y poppler-utils
```

### ❌ Error: "Chrome failed to launch"
```bash
# Install ulang dependencies Chrome
apt install -y libnss3 libnspr4 libdbus-1-3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libasound2

# Re-download Chromium
cd /root/comic-colorizer-bot
npx puppeteer browsers install chrome
```

### ❌ Error: "ENOMEM" atau bot crash karena RAM
```bash
# Cek RAM & swap
free -h

# Tambah swap jika belum ada
fallocate -l 2G /swapfile
chmod 600 /swapfile
mkswap /swapfile
swapon /swapfile
echo '/swapfile none swap sw 0 0' >> /etc/fstab
```

### ❌ Bot tidak merespons sama sekali
```bash
# Cek apakah bot running
pm2 status

# Cek log error
pm2 logs comic-colorizer-bot --err

# Cek token di .env
cat /root/comic-colorizer-bot/.env
```

### ❌ DeepAI timeout / tidak merespons
- Coba colorizer lain (Image Colorizer)
- Cek koneksi VPS: `ping deepai.org`
- Mungkin IP VPS di-block → coba ganti droplet region

### ❌ File PDF output terlalu besar (> 50MB)
Telegram membatasi file upload 50MB. Coba:
```bash
# Compress PDF dengan ghostscript
apt install -y ghostscript
gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dPDFSETTINGS=/ebook \
   -dNOPAUSE -dQUIET -dBATCH \
   -sOutputFile=output_compressed.pdf output.pdf
```

---

## 📁 Struktur File

```
/root/comic-colorizer-bot/
├── index.js              ← Kode utama bot
├── package.json          ← Dependencies npm
├── .env                  ← Token bot (jangan share!)
├── .env.example          ← Template .env
├── ecosystem.config.js   ← Konfigurasi PM2
├── setup.sh              ← Script instalasi otomatis
├── logs/
│   ├── out.log           ← Log output
│   └── error.log         ← Log error
└── temp/                 ← File sementara (auto-cleanup)
```

---

## ➕ Cara Tambah Colorizer Baru

Di `index.js`, tambahkan ke objek `COLORIZERS`:
```js
newsite: {
  id:   'newsite',
  name: '🖍️ New Colorizer',
  desc: 'Website baru untuk colorize',
  url:  'https://example-colorizer.com'
}
```

Lalu buat fungsi `colorizeNewSite(imagePath, outputPath)` dan tambahkan ke `COLORIZER_FN`:
```js
const COLORIZER_FN = {
  deepai:       colorizeDeepAI,
  imgcolorizer: colorizeImageColorizer,
  newsite:      colorizeNewSite   // ← tambahkan ini
};
```
